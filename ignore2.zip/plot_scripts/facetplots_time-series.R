################################# CREATE FACETPLOTS ######################################
############################
## LOAD REQUIRED PACKAGES
############################
library(tidyverse)

############################
## LOAD DATASETS
############################
# Load datasets and standardize temporal columns (year and month)

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite-derived vegetation indices: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite-derived vegetation indices: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 

NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite-derived vegetation indices: NIRv (Near Infrared Reflectance of Vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means per plot)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: convert datetime to year/month and assign regional labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Crop yield and cultivated area datasets
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset ds21969 (already filtered)
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters into numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun letters to numeric months
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Map letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable

############################
## SETTINGS
############################
YEAR_MIN <- 2008
YEAR_MAX <- 2019

FIG_DIR <- "./plots/facetplots"
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)


############################
## RENAME COLUMNS TO INCLUDE UNITS
############################

new_names <- names(weather)

# Precipitation
new_names <- gsub("^precipitation_radolan_rain_days$", 
                  "precipitation_radolan_rain_days [days]", new_names)
new_names <- gsub("^precipitation_radolan$", 
                  "precipitation_radolan [mm]", new_names)

# Relative humidity
new_names <- gsub("^rH_200$", "rH_200 [%]", new_names)
new_names <- gsub("^rH_200_max$", "rH_200_max [%]", new_names)
new_names <- gsub("^rH_200_min$", "rH_200_min [%]", new_names)

# Soil moisture
new_names <- gsub("^SM_10$", "SM_10 [%]", new_names)
new_names <- gsub("^SM_20$", "SM_20 [%]", new_names)

# Air temperature
new_names <- gsub("^Ta_10$", "Ta_10 [°C]", new_names)
new_names <- gsub("^Ta_10_max$", "Ta_10_max [°C]", new_names)
new_names <- gsub("^Ta_10_min$", "Ta_10_min [°C]", new_names)
new_names <- gsub("^Ta_200$", "Ta_200 [°C]", new_names)
new_names <- gsub("^Ta_200_max$", "Ta_200_max [°C]", new_names)
new_names <- gsub("^Ta_200_min$", "Ta_200_min [°C]", new_names)

# Soil temperature
new_names <- gsub("^Ts_05$", "Ts_05 [°C]", new_names)
new_names <- gsub("^Ts_05_max$", "Ts_05_max [°C]", new_names)
new_names <- gsub("^Ts_05_min$", "Ts_05_min [°C]", new_names)
new_names <- gsub("^Ts_10$", "Ts_10 [°C]", new_names)
new_names <- gsub("^Ts_10_max$", "Ts_10_max [°C]", new_names)
new_names <- gsub("^Ts_10_min$", "Ts_10_min [°C]", new_names)
new_names <- gsub("^Ts_20$", "Ts_20 [°C]", new_names)
new_names <- gsub("^Ts_20_max$", "Ts_20_max [°C]", new_names)
new_names <- gsub("^Ts_20_min$", "Ts_20_min [°C]", new_names)
new_names <- gsub("^Ts_50$", "Ts_50 [°C]", new_names)
new_names <- gsub("^Ts_50_max$", "Ts_50_max [°C]", new_names)
new_names <- gsub("^Ts_50_min$", "Ts_50_min [°C]", new_names)

names(weather) <- new_names

# Mosaic dataset
new_names <- names(mosaic)
new_names <- gsub("normal", "normal [–]", new_names)
new_names <- gsub("cellsize", "cellsize [ha]", new_names)
new_names <- gsub("dendrites", "dendrites [–]", new_names)
new_names <- gsub("relation", "relation [–]", new_names)
names(mosaic) <- new_names

# Fertilization: include units for fertilizer column
Fertilization$Fertilizer <- paste0(Fertilization$Fertilizer, " [kg/ha]")

# Function to adjust measure column for crop datasets
adjust_measure <- function(df) {
  df$measure <- ifelse(df$measure == "area", "area [ha]",
                       ifelse(df$measure == "yield", "yield [t/ha]", df$measure))
  return(df)
}

ALB_crop <- adjust_measure(ALB_crop)
HAI_crop <- adjust_measure(HAI_crop)
SCH_crop <- adjust_measure(SCH_crop)


############################
## CREATE ENVIRONMENTAL DATA IN LONG FORMAT (INCLUDING MOSAIC)
############################
make_env_yearly <- function() {
  
  env <- bind_rows(
    
    ## ---- SMI ----
    SMI_total %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      dplyr::select(year, ALB, HAI, SCH) %>%
      pivot_longer(-year, names_to="region", values_to="value") %>%
      mutate(dataset="SMI", variable="SMI total [–]"),
    
    SMI_upsoil %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      dplyr::select(year, ALB, HAI, SCH) %>%
      pivot_longer(-year, names_to="region", values_to="value") %>%
      mutate(dataset="SMI", variable="SMI topsoil [–]"),
    
    ## ---- NDVI / NDMI / NIRv ----
    NDVI_ALB %>% transmute(year, region="ALB", value=mean_NDVI, dataset="Satellite", variable="NDVI [–]"),
    NDVI_HAI %>% transmute(year, region="HAI", value=mean_NDVI, dataset="Satellite", variable="NDVI [–]"),
    NDVI_SCH %>% transmute(year, region="SCH", value=mean_NDVI, dataset="Satellite", variable="NDVI [–]"),
    
    NDMI_ALB %>% transmute(year, region="ALB", value=mean_NDMI, dataset="Satellite", variable="NDMI [–]"),
    NDMI_HAI %>% transmute(year, region="HAI", value=mean_NDMI, dataset="Satellite", variable="NDMI [–]"),
    NDMI_SCH %>% transmute(year, region="SCH", value=mean_NDMI, dataset="Satellite", variable="NDMI [–]"),
    
    NIRv_ALB %>% transmute(year, region="ALB", value=mean_NIRv, dataset="Satellite", variable="NIRv [–]"),
    NIRv_HAI %>% transmute(year, region="HAI", value=mean_NIRv, dataset="Satellite", variable="NIRv [–]"),
    NIRv_SCH %>% transmute(year, region="SCH", value=mean_NIRv, dataset="Satellite", variable="NIRv [–]"),
    
    ## ---- WEATHER (aggregated annually) ----
    {
      weather_long <- weather %>%
        filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
        group_by(year, region) %>%
        summarise(across(where(is.numeric), mean, na.rm=TRUE), .groups="drop") %>%
        dplyr::select(-month) %>%
        pivot_longer(-c(year, region), names_to="variable", values_to="value") %>%
        mutate(dataset="Weather")    

    },
    
    ## ---- MOSAIC ----
    {
      mosaic_long <- mosaic %>%
        filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
        pivot_longer(cols = c("normal [–]", "cellsize [ha]", "dendrites [–]", "relation [–]"),
                     names_to = "variable",
                     values_to = "value") %>%
        mutate(dataset="Mosaic")
      mosaic_long
    },
    
    ## ---- CROPS ----
    bind_rows(
      ALB_crop %>% mutate(region="ALB"),
      HAI_crop %>% mutate(region="HAI"),
      SCH_crop %>% mutate(region="SCH")
    ) %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year, region, var, measure) %>%
      summarise(value=mean(weighted_value_sum, na.rm=TRUE), .groups="drop") %>%
      mutate(dataset="Crops",
             variable=paste(var, measure, sep=" – "))
  )
  
  # Set dataset factor to control facet order (insects on top)
  env$dataset <- factor(env$dataset,
                        levels=c("ds21969","ds22007","SMI","Satellite","Weather","Mosaic","Crops","Fertilization"))
  
  env
}

env_yearly <- make_env_yearly()


############################
## FERTILIZATION DATA (SEPARATE)
############################
fert_yearly <- Fertilization %>%
  filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
  pivot_longer(cols=c(ALB,HAI,SCH), names_to="region", values_to="value") %>%
  mutate(
    dataset="Fertilization",
    variable = paste(Croptype, Fertilizer, sep=" – "),
    variable = factor(variable, levels = unique(variable)) # Force factor
  )


############################
## INSECT DATA PREPARATION
############################
prepare_insects <- function(df, name) {
  df %>%
    filter(year >= YEAR_MIN, year <= YEAR_MAX,
           Order != "Araneae") %>%
    group_by(year, Exploratory, Order) %>%
    summarise(value=sum(NumberAdults, na.rm=TRUE), .groups="drop") %>%
    rename(region=Exploratory, variable=Order) %>%
    mutate(dataset=name,
           variable=paste0(variable, " [NumberAdults]"))
}


############################
## PLOTTING FUNCTION
############################
plot_a4 <- function(df, region, dataset_name) {
  
  # Control dataset factor to place insects on top
  df$dataset <- factor(df$dataset,
                       levels=c("ds21969","ds22007","SMI","Satellite","Weather","Mosaic","Crops","Fertilization"))
  
  p <- ggplot(df %>% filter(region==!!region),
              aes(x=year, y=value)) +
    geom_line() +
    facet_wrap(~dataset + variable, scales="free_y", ncol=4) +
    theme_bw() +
    theme(
      strip.text = element_text(size=6),
      axis.text = element_text(size=6),
      axis.title = element_blank()
    ) +
    scale_x_continuous(
      breaks = seq(YEAR_MIN, YEAR_MAX, 2)
    ) +
    scale_y_continuous(
      breaks = scales::pretty_breaks(n = 3)   
    )
  
  ggsave(
    filename = file.path(FIG_DIR, paste0("A4_", dataset_name, "_", region, ".png")),
    plot = p,
    width = 8.27,
    height = 11.69,
    dpi = 300
  )
}


############################
## FINAL EXECUTION
############################
for (reg in c("ALB","HAI","SCH")) {
  
  ## ds21969 insects + environment
  df_21969 <- bind_rows(
    prepare_insects(ds21969, "ds21969"),
    env_yearly
  )
  plot_a4(df_21969, reg, "ds21969")
  
  # ds21969 + fertilization
  plot_a4(
    bind_rows(prepare_insects(ds21969, "ds21969"), fert_yearly),
    reg,
    "ds21969_fertilization"
  )
  
  ## ds22007 insects + environment
  df_22007 <- bind_rows(
    prepare_insects(ds22007, "ds22007"),
    env_yearly
  )
  plot_a4(df_22007, reg, "ds22007")
  
  # ds22007 + fertilization
  plot_a4(
    bind_rows(prepare_insects(ds22007, "ds22007"), fert_yearly),
    reg,
    "ds22007_fertilization"
  )
}

