###############PLOTTING GRANGER RESULTS AS HEATMAPS##########################
#load packages
library(tidyverse)
library(vars)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(ggplot2)
library(cowplot)

##############################LOAD DATA###########################################

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


#results from granger test
granger_results_ds21969_ALB <- read.csv("./tables/granger_test/results_ds21969_ALB.csv", sep=",")
granger_results_ds21969_HAI <- read.csv("./tables/granger_test/results_ds21969_HAI.csv", sep=",")
granger_results_ds21969_SCH <- read.csv("./tables/granger_test/results_ds21969_SCH.csv", sep=",")

granger_results_ds22007_ALB <- read.csv("./tables/granger_test/results_ds22007_ALB.csv", sep=",")
granger_results_ds22007_HAI <- read.csv("./tables/granger_test/results_ds22007_HAI.csv", sep=",")
granger_results_ds22007_SCH <- read.csv("./tables/granger_test/results_ds22007_SCH.csv", sep=",")

granger_results_ds22007_ALB_monthly <- read.csv("./tables/granger_test/results_ds22007_monthly_ALB.csv", sep=",")
granger_results_ds22007_HAI_monthly <- read.csv("./tables/granger_test/results_ds22007_monthly_HAI.csv", sep=",")
granger_results_ds22007_SCH_monthly <- read.csv("./tables/granger_test/results_ds22007_monthly_SCH.csv", sep=",")

##########results 2nd round######################################
#results from granger test
granger_results_ds21969_ALB_2nd_round <- read.csv("./tables/granger_test/results_ds21969_ALB_2nd_round.csv", sep=",")
granger_results_ds21969_HAI_2nd_round <- read.csv("./tables/granger_test/results_ds21969_HAI_2nd_round.csv", sep=",")
granger_results_ds21969_SCH_2nd_round <- read.csv("./tables/granger_test/results_ds21969_SCH_2nd_round.csv", sep=",")

granger_results_ds22007_ALB_2nd_round <- read.csv("./tables/granger_test/results_ds22007_ALB_2nd_round.csv", sep=",")
granger_results_ds22007_HAI_2nd_round <- read.csv("./tables/granger_test/results_ds22007_HAI_2nd_round.csv", sep=",")
granger_results_ds22007_SCH_2nd_round <- read.csv("./tables/granger_test/results_ds22007_SCH_2nd_round.csv", sep=",")

granger_results_ds21969_ALB_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_ALB_2nd_round.csv", sep=",")
granger_results_ds21969_HAI_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_HAI_2nd_round.csv", sep=",")
granger_results_ds21969_SCH_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_SCH_2nd_round.csv", sep=",")

granger_results_ds22007_ALB_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_ALB_monthly_2nd_round.csv", sep=",")
granger_results_ds22007_HAI_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_HAI_monthly_2nd_round.csv", sep=",")
granger_results_ds22007_SCH_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_SCH_monthly_2nd_round.csv", sep=",")


##############################BUILD HEATMAPS################################

############################# DS21969_YEARLY ###############################

# ------------------- Remove spider families -------------------
spider_families <- c(
  "Araneidae","Dictynidae","Linyphiidae","Lycosidae",
  "Philodromidae","Salticidae","Tetragnathidae","Theridiidae","Thomisidae"
)
remove_families <- c(spider_families, "Fam.")

granger_results_ds21969_ALB_clean <- subset(granger_results_ds21969_ALB_2nd_round, !Family %in% remove_families)
granger_results_ds21969_HAI_clean <- subset(granger_results_ds21969_HAI_2nd_round, !Family %in% remove_families)
granger_results_ds21969_SCH_clean <- subset(granger_results_ds21969_SCH_2nd_round, !Family %in% remove_families)

# ------------------- Variable labels -------------------
variable_labels <- c(
  # Weather
  "SM_10" = "SoilMoist_10cm [Weather]",
  "SM_20" = "SoilMoist_20cm [Weather]",
  "Ta_10" = "Temp_10cm [Weather]",
  "Ta_10_max" = "Temp_10cm_max [Weather]",
  "Ta_10_min" = "Temp_10cm_min [Weather]",
  "Ta_200" = "Temp_2m [Weather]",
  "Ta_200_min" = "Temp_2m_min [Weather]",
  "Ta_200_max" = "Temp_2m_max [Weather]",
  "rH_200" = "RelHum_2m [Weather]",
  "rH_200_min" = "RelHum_min [Weather]",
  "rH_200_max" = "RelHum_max [Weather]",
  "Ts_05" = "SoilTemp_5cm [Weather]",
  "Ts_05_min" = "SoilTemp_5cm_min [Weather]",
  "Ts_05_max" = "SoilTemp_5cm_max [Weather]",
  "Ts_10" = "SoilTemp_10cm [Weather]",
  "Ts_10_min" = "SoilTemp_10cm_min [Weather]",
  "Ts_10_max" = "SoilTemp_10cm_max [Weather]",
  "Ts_20" = "SoilTemp_20cm [Weather]",
  "Ts_20_min" = "SoilTemp_20cm_min [Weather]",
  "Ts_20_max" = "SoilTemp_20cm_max [Weather]",
  "Ts_50" = "SoilTemp_50cm [Weather]",
  "Ts_50_min" = "SoilTemp_50cm_min [Weather]",
  "Ts_50_max" = "SoilTemp_50cm_max [Weather]",
  "precipitation_radolan" = "Precipitation [Weather]",
  "precipitation_radolan_rain_days" = "RainDays [Weather]",
  
  # Crops
  "ww_area" = "WinterWheat area [Crop]",
  "ww_yield" = "WinterWheat yield [Crop]",
  "wb_area" = "WheatBarley area [Crop]",
  "wb_yield" = "WheatBarley yield [Crop]",
  "grain_maize_area" = "Maize area [Crop]",
  "grain_maize_yield" = "Maize yield [Crop]",
  "oats_area" = "Oats area [Crop]",
  "oats_yield" = "Oats yield [Crop]",
  "potat_tot_area" = "Potato area [Crop]",
  "potat_tot_yield" = "Potato yield [Crop]",
  "rye_area" = "Rye area [Crop]",
  "rye_yield" = "Rye yield [Crop]",
  "sb_area" = "SugarBeet area [Crop]",
  "sb_yield" = "SugarBeet yield [Crop]",
  "sugarbeet_area" = "SugarBeet area [Crop]",
  "sugarbeet_yield" = "SugarBeet yield [Crop]",
  "silage_maize_area" = "SilageMaize area [Crop]",
  "silage_maize_yield" = "SilageMaize yield [Crop]",
  "triticale_area" = "Triticale area [Crop]",
  "triticale_yield" = "Triticale yield [Crop]",
  "wrape_area" = "WinterRape area [Crop]",
  "wrape_yield" = "WinterRape yield [Crop]",
  "district_area" = "District area [Crop]",
  "district_yield" = "District yield [Crop]",
  "ArabLand_yield" = "ArableLand yield [Crop]",
  "ArabLand_area" = "ArableLand area [Crop]",  
  
  # NDVI/NDMI/NIRv
  "mean_NDVI" = "NDVI [NDVI]",
  "mean_NDMI" = "NDMI [NDMI]",
  "mean_NIRv" = "NIRv [NIRv]",
  
  # Mosaic
  "cellsize" = "CellSize [Mosaic]", 
  "cellsize_detrended" = "CellSize [Mosaic]", 
  "dendrites" = "Dendrites [Mosaic]", 
  "dendrites_detrended" = "Dendrites [Mosaic]", 
  "normal" = "Normal [Mosaic]", 
  "normal_detrended" = "Normal [Mosaic]", 
  "relation" = "Relation [Mosaic]"
)


# ------------------- Weather variable selection: detrended > .x > .y -------------------
select_weather_var <- function(var){
  if(grepl("_detrended$", var)) return(str_replace(var, "_detrended$", ""))
  if(grepl("\\.x$", var)) return(str_replace(var, "\\.x$", ""))
  if(grepl("\\.y$", var)) return(str_replace(var, "\\.y$", ""))
  return(var)
}

# ------------------- SMI label helper -------------------
get_smi_label_region <- function(var, region){
  if(tolower(var) == "smi_upsoil") return("SMI_upsoil [SMI]")
  if(tolower(var) == "smi_total") return("SMI_total [SMI]")
  return(NA)
}

# ------------------- Prepare all combinations -------------------
prepare_all_combinations <- function(df, region){
  
  df <- df %>%
    rowwise() %>%
    mutate(
      # --- 1) SMI ---
      Label_smi = get_smi_label_region(EnvDataset, region),
      
      # --- 2) Weather ---
      EnvColumn_clean = if(is.na(Label_smi) & EnvDataset=="weather") select_weather_var(EnvColumn) else EnvColumn,
      
      # --- 3) Fertilization ---
      Label_orig = case_when(
        !is.na(Label_smi) ~ Label_smi,
        EnvDataset == "Fertilization" & !is.na(Croptype) & !is.na(Fertilizer) ~
          paste0(Croptype,"_",Fertilizer," [Fertilization]"),
        TRUE ~ EnvColumn_clean
      ),
      
      # Remove detrended/.x/.y suffixes for display
      Label = str_replace_all(Label_orig, "_detrended|\\.x|\\.y","")
    ) %>%
    ungroup()
  
  # --- All Family × Label combinations ---
  all_combinations <- expand.grid(
    Family = unique(df$Family),
    Label  = unique(df$Label),
    stringsAsFactors = FALSE
  )
  
  # --- Aggregate ---
  df_agg <- df %>%
    group_by(Family, Label) %>%
    summarise(
      p_value = if(all(is.na(p_value))) NA_real_ else max(p_value, na.rm=TRUE),
      causality = { tmp <- causality; tmp[is.na(tmp)] <- "no_test"; if(all(tmp=="no_test")) "no_test" else tmp[which.max(p_value)] },
      .groups="drop"
    )
  
  # --- Fill missing combinations ---
  df_filled <- all_combinations %>%
    left_join(df_agg, by=c("Family","Label")) %>%
    replace_na(list(p_value=NA_real_, causality="no_test"))
  
  return(df_filled)
}

# ------------------- Plot function -------------------
plot_ds21969_region_heatmap <- function(df, region, out_dir){
  
  df_selected <- prepare_all_combinations(df, region)
  
  # Replace with readable labels if available
  df_selected$Label <- ifelse(df_selected$Label %in% names(variable_labels),
                              variable_labels[df_selected$Label],
                              df_selected$Label)
  
  # Dataset factor levels
  df_selected <- df_selected %>%
    mutate(dataset = str_extract(Label,"\\[.*\\]") %>% gsub("\\[|\\]","",.),
           Label = str_trim(Label))
  
  label_levels <- df_selected %>%
    arrange(tolower(dataset), tolower(Label)) %>%
    pull(Label) %>% unique()
  
  df_selected$Label <- factor(df_selected$Label, levels=label_levels)
  
  # Dataset separation lines
  dataset_breaks <- df_selected %>%
    group_by(dataset) %>%
    summarise(max_y = max(as.numeric(Label))) %>%
    ungroup() %>%
    slice(-n())
  
  df_selected$causality <- factor(df_selected$causality,
                                  levels=c("causal","non-causal","no_test"))
  
  # Heatmap
  p <- ggplot(df_selected, aes(x=Family, y=Label, fill=causality)) +
    geom_tile(color="white", width=0.9, height=0.9) +
    geom_hline(data=dataset_breaks, aes(yintercept=max_y+0.5), size=0.3) +
    scale_fill_manual(values=c("causal"="#0072B2","non-causal"="#D55E00","no_test"="grey80"),
                      name="Granger causality") +
    theme_minimal(base_size=10) +
    theme(
      axis.text.x = element_text(angle=90,hjust=1,vjust=1,size=7),
      axis.text.y = element_text(size=7),
      axis.title.x = element_text(margin=margin(t=10),size=9),
      axis.title.y = element_text(margin=margin(r=10),size=9),
      panel.grid=element_blank(),
      legend.position="top"
    ) +
    labs(title="Granger test results – ds21969",
         subtitle=paste("Region:",region),
         x="Insect Families",
         y="Environmental Variable [Dataset]") +
    coord_fixed(ratio=1)
  
  file_name <- paste0(out_dir,"/ds21969_yearly_",region,"_heatmap.png")
  ggsave(file_name,p,width=8.27,height=11.7,units="in",bg="white")
  message("✔ Plot saved: ", file_name)
}

# ------------------- Datasets -------------------
ds21969_list <- list(
  ALB = granger_results_ds21969_ALB_clean,
  HAI = granger_results_ds21969_HAI_clean,
  SCH = granger_results_ds21969_SCH_clean
)

out_dir <- "./plots/granger_heatmaps/ds21969_yearly"
if(!dir.exists(out_dir)) dir.create(out_dir, recursive=TRUE)

# ------------------- Generate heatmaps -------------------
for(region in names(ds21969_list)){
  plot_ds21969_region_heatmap(ds21969_list[[region]], region, out_dir)
}


############################## DS22007 YEARLY #############################

# ------------------- Variable labels -------------------
variable_labels <- c(
  # Weather
  "SM_10" = "SoilMoist_10cm [Weather]",
  "SM_20" = "SoilMoist_20cm [Weather]",
  "Ta_10" = "Temp_10cm [Weather]",
  "Ta_10_max" = "Temp_10cm_max [Weather]",
  "Ta_10_min" = "Temp_10cm_min [Weather]",
  "Ta_200" = "Temp_2m [Weather]",
  "Ta_200_min" = "Temp_2m_min [Weather]",
  "Ta_200_max" = "Temp_2m_max [Weather]",
  "rH_200" = "RelHum_2m [Weather]",
  "rH_200_min" = "RelHum_min [Weather]",
  "rH_200_max" = "RelHum_max [Weather]",
  "Ts_05" = "SoilTemp_5cm [Weather]",
  "Ts_05_min" = "SoilTemp_5cm_min [Weather]",
  "Ts_05_max" = "SoilTemp_5cm_max [Weather]",
  "Ts_10" = "SoilTemp_10cm [Weather]",
  "Ts_10_min" = "SoilTemp_10cm_min [Weather]",
  "Ts_10_max" = "SoilTemp_10cm_max [Weather]",
  "Ts_20" = "SoilTemp_20cm [Weather]",
  "Ts_20_min" = "SoilTemp_20cm_min [Weather]",
  "Ts_20_max" = "SoilTemp_20cm_max [Weather]",
  "Ts_50" = "SoilTemp_50cm [Weather]",
  "Ts_50_min" = "SoilTemp_50cm_min [Weather]",
  "Ts_50_max" = "SoilTemp_50cm_max [Weather]",
  "precipitation_radolan" = "Precipitation [Weather]",
  "precipitation_radolan_rain_days" = "RainDays [Weather]",
  
  # Crops
  "ArabLand_area" = "ArabLand area [Crop]",
  "ArabLand_yield" = "ArabLand yield [Crop]",
  "grain_maize_area" = "Maize area [Crop]",
  "grain_maize_yield" = "Maize yield [Crop]",
  "oats_area" = "Oats area [Crop]",
  "oats_yield" = "Oats yield [Crop]",
  "potat_tot_area" = "Potato area [Crop]",
  "potat_tot_yield" = "Potato yield [Crop]",
  "rye_area" = "Rye area [Crop]",
  "rye_yield" = "Rye yield [Crop]",
  "sb_area" = "SugarBeet area [Crop]",
  "sb_yield" = "SugarBeet yield [Crop]",
  "silage_maize_area" = "SilageMaize area [Crop]",
  "silage_maize_yield" = "SilageMaize yield [Crop]",
  "sugarbeet_area" = "SugarBeet area [Crop]",
  "sugarbeet_yield" = "SugarBeet yield [Crop]",
  "triticale_area" = "Triticale area [Crop]",
  "triticale_yield" = "Triticale yield [Crop]",
  "wb_area" = "WheatBarley area [Crop]",
  "wb_yield" = "WheatBarley yield [Crop]",
  "wrape_area" = "WinterRape area [Crop]",
  "wrape_yield" = "WinterRape yield [Crop]",
  "ww_area" = "WinterWheat area [Crop]",
  "ww_yield" = "WinterWheat yield [Crop]",
  "district_area" = "District area [Crop]",
  "district_yield" = "District yield [Crop]",
  
  # NDVI/NDMI/NIRv
  "mean_NDVI" = "NDVI [NDVI]",
  "mean_NDMI" = "NDMI [NDVI]",
  "mean_NIRv" = "NIRv [NIRv]",
  
  # Mosaic
  "cellsize" = "CellSize [Mosaic]", 
  "cellsize_detrended" = "CellSize [Mosaic]", 
  "dendrites" = "Dendrites [Mosaic]", 
  "dendrites_detrended" = "Dendrites [Mosaic]", 
  "normal" = "Normal [Mosaic]", 
  "normal_detrended" = "Normal [Mosaic]", 
  "relation" = "Relation [Mosaic]" 
)

# ------------------- Choose correct variable for weather: detrended > .x > .y -------------------
select_weather_var <- function(var){
  if(grepl("_detrended$", var)) return(str_replace(var, "_detrended$", ""))
  if(grepl("\\.x$", var)) return(str_replace(var, "\\.x$", ""))
  if(grepl("\\.y$", var)) return(str_replace(var, "\\.y$", ""))
  return(var)
}

# ------------------- Helper function for SMI ----------------------------------------------------
get_smi_label_region <- function(var, region){
  if(region == "ALB"){
    if(tolower(var) == "smi_upsoil") return("SMI_upsoil [SMI]")
    if(tolower(var) == "smi_total") return("SMI_total [SMI]")
  }
  if(region == "HAI"){
    if(tolower(var) == "smi_upsoil") return("SMI_upsoil [SMI]")
    if(tolower(var) == "smi_total") return("SMI_total [SMI]")
  }
  if(region == "SCH"){
    if(tolower(var) == "smi_upsoil") return("SMI_upsoil [SMI]")
    if(tolower(var) == "smi_total") return("SMI_total [SMI]")
  }
  return(NA)
}

# ------------------- Prepare all combinations -------------------
prepare_all_combinations <- function(df, region){
  
  df <- df %>%
    rowwise() %>%
    mutate(
      # --- 1) SMI: immer korrekt Label zurückgeben ---
      Label_smi = get_smi_label_region(EnvDataset, region),
      
      # --- 2) Weather: detrended > .x > .y ---
      EnvColumn_clean = if(is.na(Label_smi) & EnvDataset == "weather") select_weather_var(EnvColumn) else EnvColumn,
      
      # --- 3) Fertilization ---
      Label_orig = case_when(
        !is.na(Label_smi) ~ Label_smi,
        EnvDataset == "Fertilization" & !is.na(Croptype) & !is.na(Fertilizer) ~
          paste0(Croptype, "_", Fertilizer, " [Fertilization]"),
        TRUE ~ EnvColumn_clean
      ),
      
      # Remove _detrended / .x / .y only for display
      Label = str_replace_all(Label_orig, "_detrended|\\.x|\\.y", "")
    ) %>%
    ungroup()
  
  # --- All Family × Label combinations ---
  all_combinations <- expand.grid(
    Family = unique(df$Family),
    Label = unique(df$Label),
    stringsAsFactors = FALSE
  )
  
  # --- Aggregate p_value & causality ---
  df_agg <- df %>%
    group_by(Family, Label) %>%
    summarise(
      p_value = if(all(is.na(p_value))) NA_real_ else max(p_value, na.rm = TRUE),
      causality = {
        tmp <- causality
        tmp[is.na(tmp)] <- "no_test"
        if(all(tmp == "no_test")) "no_test" else tmp[which.max(p_value)]
      },
      .groups = "drop"
    )
  
  # --- Fill missing combinations ---
  df_filled <- all_combinations %>%
    left_join(df_agg, by = c("Family","Label")) %>%
    replace_na(list(p_value=NA_real_, causality="no_test"))
  
  return(df_filled)
}

# ------------------- Plot function -------------------
plot_ds22007_region_heatmap <- function(df, region, out_dir){
  
  df_selected <- prepare_all_combinations(df, region)
  
  # Label with proper dataset/categorization
  df_selected$Label <- ifelse(df_selected$Label %in% names(variable_labels),
                              variable_labels[df_selected$Label],
                              df_selected$Label)
  
  # Factor levels for y-axis
  df_selected <- df_selected %>%
    mutate(dataset = str_extract(Label,"\\[.*\\]") %>% gsub("\\[|\\]","",.),
           Label = str_trim(Label))
  
  label_levels <- df_selected %>%
    arrange(tolower(dataset), tolower(Label)) %>%
    pull(Label) %>% unique()
  
  df_selected$Label <- factor(df_selected$Label, levels = label_levels)
  
  # Dataset separation lines
  dataset_breaks <- df_selected %>%
    group_by(dataset) %>%
    summarise(max_y = max(as.numeric(Label))) %>%
    ungroup() %>%
    slice(-n())
  
  df_selected$causality <- factor(df_selected$causality,
                                  levels=c("causal","non-causal","no_test"))
  
  p <- ggplot(df_selected, aes(x=Family, y=Label, fill=causality)) +
    geom_tile(color="white", width=0.9, height=0.9) +
    geom_hline(data=dataset_breaks, aes(yintercept=max_y+0.5), color="black", size=0.3) +
    scale_fill_manual(
      values=c("causal"="#0072B2","non-causal"="#D55E00","no_test"="grey80"),
      name="Granger causality result",
      labels=c("causal","non-causal","no test")
    ) +
    theme_minimal(base_size=10) +
    theme(
      axis.text.x = element_text(angle=90,hjust=1,vjust=1,size=7),
      axis.text.y = element_text(size=7),
      axis.title.x = element_text(margin=margin(t=10),size=9),
      axis.title.y = element_text(margin=margin(r=10),size=9),
      panel.grid=element_blank(),
      plot.background=element_rect(fill="white", color=NA),
      legend.position="top",
      legend.title=element_text(size=10),
      legend.text=element_text(size=9)
    ) +
    labs(
      title=paste0("Granger test results – ds22007"),
      subtitle=paste0("Region: ",region),
      x="Insect Families",
      y="Environmental Variable [Dataset]"
    ) +
    coord_fixed(ratio=1)
  
  file_name <- paste0(out_dir,"/ds22007_",region,"_heatmap.png")
  ggsave(file_name,p,width=8.27,height=11.7,units="in",bg="white")
  message("✔ Plot saved: ", file_name)
}

# ------------------- Datasets -------------------
ds22007_list <- list(
  "ALB" = granger_results_ds22007_ALB_2nd_round_clean,
  "HAI" = granger_results_ds22007_HAI_2nd_round_clean,
  "SCH" = granger_results_ds22007_SCH_2nd_round_clean
)

out_dir <- "./plots/granger_heatmaps/ds22007_yearly"
if(!dir.exists(out_dir)) dir.create(out_dir, recursive=TRUE)

# ------------------- Generate heatmaps -------------------
for(region in names(ds22007_list)){
  plot_ds22007_region_heatmap(ds22007_list[[region]], region, out_dir)
}

################## HEATMAPS FOR DS21969 MONTHLY #########################

# REMOVE SPIDERS FROM DATA
spider_families <- c(
  "Araneidae",
  "Dictynidae",
  "Linyphiidae",
  "Lycosidae",
  "Philodromidae",
  "Salticidae",
  "Tetragnathidae",
  "Theridiidae",
  "Thomisidae"
)

remove_families <- c(spider_families, "Fam.")

granger_results_ds21969_ALB_monthly_2nd_round_clean <-
  subset(granger_results_ds21969_ALB_monthly_2nd_round,
         !Family %in% remove_families)

granger_results_ds21969_HAI_monthly_2nd_round_clean <-
  subset(granger_results_ds21969_HAI_monthly_2nd_round,
         !Family %in% remove_families)

granger_results_ds21969_SCH_monthly_2nd_round_clean <-
  subset(granger_results_ds21969_SCH_monthly_2nd_round,
         !Family %in% remove_families)


# CHECK UNIQUE FAMILIES AFTER REMOVAL
unique(granger_results_ds21969_ALB_monthly_2nd_round_clean$Family)
unique(granger_results_ds21969_HAI_monthly_2nd_round_clean$Family)
unique(granger_results_ds21969_SCH_monthly_2nd_round_clean$Family)


############ MONTHLY HEATMAPS ds21969 (CLEAN LABELS) #######################

# ------------------- Auxiliary table for variable labels -------------------
variable_labels <- c(
  # Weather variables
  "SM_10" = "SoilMoist_10cm [Weather]",
  "SM_20" = "SoilMoist_20cm [Weather]",
  "Ta_10" = "Temp_10cm [Weather]",
  "Ta_10_max" = "Temp_10cm_max [Weather]",
  "Ta_10_min" = "Temp_10cm_min [Weather]",
  "Ta_200" = "Temp_2m [Weather]",
  "Ta_200_min" = "Temp_2m_min [Weather]",
  "Ta_200_max" = "Temp_2m_max [Weather]",
  "rH_200" = "RelHum_2m [Weather]",
  "rH_200_min" = "RelHum_min [Weather]",
  "rH_200_max" = "RelHum_max [Weather]",
  "Ts_05" = "SoilTemp_5cm [Weather]",
  "Ts_05_min" = "SoilTemp_5cm_min [Weather]",
  "Ts_05_max" = "SoilTemp_5cm_max [Weather]",
  "Ts_10" = "SoilTemp_10cm [Weather]",
  "Ts_10_min" = "SoilTemp_10cm_min [Weather]",
  "Ts_10_max" = "SoilTemp_10cm_max [Weather]",
  "Ts_20" = "SoilTemp_20cm [Weather]",
  "Ts_20_min" = "SoilTemp_20cm_min [Weather]",
  "Ts_20_max" = "SoilTemp_20cm_max [Weather]",
  "Ts_50" = "SoilTemp_50cm [Weather]",
  "Ts_50_min" = "SoilTemp_50cm_min [Weather]",
  "Ts_50_max" = "SoilTemp_50cm_max [Weather]",
  "precipitation_radolan" = "Precipitation [Weather]",
  "precipitation_radolan_rain_days" = "RainDays [Weather]",
  
  # Vegetation indices
  "mean_NDVI" = "NDVI [NDVI]",
  "mean_NDMI" = "NDMI [NDMI]",
  "mean_NIRv" = "NIRv [NIRv]",
  
  # Soil Moisture Index (SMI)
  "SMI_total [SMI_total]" = "SMI_total [SMI]",
  "SMI_upsoil [SMI_upsoil]" = "SMI_upsoil [SMI]"
)

# ------------------- Preparation of all combinations -------------------
prepare_monthly_combinations <- function(df){
  
  df <- df %>%
    # Remove month_num column
    filter(EnvColumn != "month_num") %>%
    
    mutate(
      Label_raw = case_when(
        # --- SMI variables: ignore EnvColumn ---
        str_to_lower(EnvDataset) == "smi_upsoil" ~ "SMI_upsoil [SMI_upsoil]",
        str_to_lower(EnvDataset) == "smi_total"  ~ "SMI_total [SMI_total]",
        
        # --- All other variables ---
        TRUE ~ EnvColumn
      ),
      
      # Do not show detrended/differenced in label
      Label = str_remove(
        Label_raw,
        "_detrended|_diffed|_diffed_detrended"
      )
    )
  
  # All Family × Label combinations
  all_combinations <- expand.grid(
    Family = unique(df$Family),
    Label  = unique(df$Label),
    stringsAsFactors = FALSE
  )
  
  # Aggregation
  df_agg <- df %>%
    group_by(Family, Label) %>%
    summarise(
      p_value = if (all(is.na(p_value))) NA_real_ else max(p_value, na.rm = TRUE),
      causality = {
        caus_clean <- causality
        caus_clean[is.na(caus_clean)] <- "no_test"
        if (all(caus_clean == "no_test")) "no_test"
        else caus_clean[which.max(p_value)]
      },
      .groups = "drop"
    )
  
  # Fill missing combinations
  all_combinations %>%
    left_join(df_agg, by = c("Family", "Label")) %>%
    mutate(causality = replace_na(causality, "no_test"))
}

# ------------------- Heatmap plotting function -------------------
plot_ds21969_monthly_region <- function(df, region, out_dir){
  
  df_selected <- prepare_monthly_combinations(df)
  
  # Format labels for readability
  df_selected$Label <- ifelse(
    df_selected$Label %in% names(variable_labels),
    variable_labels[df_selected$Label],
    df_selected$Label
  )
  
  # Extract dataset and sort alphabetically
  df_selected <- df_selected %>%
    mutate(
      dataset = str_extract(Label, "\\[.*\\]") %>%
        str_remove_all("\\[|\\]") %>%
        str_trim(),
      Label = str_trim(Label)
    )
  
  label_levels <- df_selected %>%
    arrange(tolower(dataset), tolower(Label)) %>%
    pull(Label) %>%
    unique()
  
  df_selected$Label <- factor(df_selected$Label, levels = label_levels)
  
  # Dataset separation lines
  dataset_breaks <- df_selected %>%
    arrange(factor(Label, levels = label_levels)) %>%
    group_by(dataset) %>%
    summarise(max_y = max(as.numeric(Label))) %>%
    slice(-n())
  
  df_selected$causality <- factor(
    df_selected$causality,
    levels = c("causal", "non-causal", "no_test")
  )
  
  # Plot
  p <- ggplot(df_selected, aes(x = Family, y = Label, fill = causality)) +
    geom_tile(color = "white", width = 0.9, height = 0.9) +
    geom_hline(
      data = dataset_breaks,
      aes(yintercept = max_y + 0.5),
      size = 0.3
    ) +
    scale_fill_manual(
      values = c(
        "causal" = "#0072B2",
        "non-causal" = "#D55E00",
        "no_test" = "grey80"
      ),
      name = "Granger causality"
    ) +
    theme_minimal(base_size = 10) +
    theme(
      axis.text.x = element_text(angle = 90, hjust = 1, size = 9),
      axis.text.y = element_text(size = 9),
      axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0), size = 10), # Right margin for y-axis title
      panel.grid = element_blank(),
      legend.position = "top"
    )+
    labs(
      title = "Granger test results – ds21969 (monthly)",
      subtitle = paste("Region:", region),
      x = "Insect Families",
      y = "Environmental Variable [Dataset]"
    ) +
    coord_fixed(ratio = 1)
  
  file_name <- file.path(out_dir, paste0("ds21969_monthly_", region, "_heatmap.png"))
  ggsave(file_name, p, width = 11.7, height = 8.27, units = "in", bg = "white")
  
  message("✔ Plot saved: ", file_name)
}

# ------------------- Datasets -------------------
ds21969_monthly_list <- list(
  ALB = granger_results_ds21969_ALB_monthly_2nd_round_clean,
  HAI = granger_results_ds21969_HAI_monthly_2nd_round_clean,
  SCH = granger_results_ds21969_SCH_monthly_2nd_round_clean
)

out_dir <- "./plots/granger_heatmaps/ds21969_monthly"
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)

# ------------------- Generate plots -------------------
for (region in names(ds21969_monthly_list)) {
  plot_ds21969_monthly_region(ds21969_monthly_list[[region]], region, out_dir)
}


################### DS22007_MONTHLY ###############################
# Remove placeholder families
granger_results_ds22007_ALB_monthly_2nd_round_clean <-
  subset(granger_results_ds22007_ALB_monthly_2nd_round, Family != "Fam.")

granger_results_ds22007_HAI_monthly_2nd_round_clean <-
  subset(granger_results_ds22007_HAI_monthly_2nd_round, Family != "Fam.")

granger_results_ds22007_SCH_monthly_2nd_round_clean <-
  subset(granger_results_ds22007_SCH_monthly_2nd_round, Family != "Fam.")

# Create list of datasets per region
ds22007_monthly_list <- list(
  ALB = granger_results_ds22007_ALB_monthly_2nd_round_clean,
  HAI = granger_results_ds22007_HAI_monthly_2nd_round_clean,
  SCH = granger_results_ds22007_SCH_monthly_2nd_round_clean
)

# ------------------- Function to display dataset combinations -------------------
show_env_combinations <- function(df, region_name) {
  combos <- df %>%
    dplyr::select(EnvDataset, EnvColumn) %>%
    distinct() %>%
    arrange(EnvDataset, EnvColumn)
  cat("\n--- Combinations for region:", region_name, "---\n")
  print(combos)
  return(combos)
}

# Display combinations per region
alb_combos <- show_env_combinations(granger_results_ds22007_ALB_monthly_2nd_round_clean, "ALB")
hai_combos <- show_env_combinations(granger_results_ds22007_HAI_monthly_2nd_round_clean, "HAI")
sch_combos <- show_env_combinations(granger_results_ds22007_SCH_monthly_2nd_round_clean, "SCH")


############ MONTHLY HEATMAPS ds22007 (CLEAN LABELS) #######################

# ------------------- Helper table for variable labels -------------------
variable_labels <- c(
  # Weather
  "SM_10" = "SoilMoist_10cm [Weather]",
  "SM_20" = "SoilMoist_20cm [Weather]",
  "Ta_10" = "Temp_10cm [Weather]",
  "Ta_10_max" = "Temp_10cm_max [Weather]",
  "Ta_10_min" = "Temp_10cm_min [Weather]",
  "Ta_200" = "Temp_2m [Weather]",
  "Ta_200_min" = "Temp_2m_min [Weather]",
  "Ta_200_max" = "Temp_2m_max [Weather]",
  "rH_200" = "RelHum_2m [Weather]",
  "rH_200_min" = "RelHum_min [Weather]",
  "rH_200_max" = "RelHum_max [Weather]",
  "Ts_05" = "SoilTemp_5cm [Weather]",
  "Ts_05_min" = "SoilTemp_5cm_min [Weather]",
  "Ts_05_max" = "SoilTemp_5cm_max [Weather]",
  "Ts_10" = "SoilTemp_10cm [Weather]",
  "Ts_10_min" = "SoilTemp_10cm_min [Weather]",
  "Ts_10_max" = "SoilTemp_10cm_max [Weather]",
  "Ts_20" = "SoilTemp_20cm [Weather]",
  "Ts_20_min" = "SoilTemp_20cm_min [Weather]",
  "Ts_20_max" = "SoilTemp_20cm_max [Weather]",
  "Ts_50" = "SoilTemp_50cm [Weather]",
  "Ts_50_min" = "SoilTemp_50cm_min [Weather]",
  "Ts_50_max" = "SoilTemp_50cm_max [Weather]",
  "precipitation_radolan" = "Precipitation [Weather]",
  "precipitation_radolan_rain_days" = "RainDays [Weather]",
  
  # NDVI / NDMI / NIRv
  "mean_NDVI" = "NDVI [NDVI]",
  "mean_NDMI" = "NDMI [NDMI]",
  "mean_NIRv" = "NIRv [NIRv]",
  
  # SMI only if present
  "SMI_total [SMI_total]" = "SMI_total [SMI]",
  "SMI_upsoil [SMI_upsoil]" = "SMI_upsoil [SMI]"
)

# ------------------- Prepare all combinations -------------------
prepare_ds22007_monthly <- function(df, region){
  
  df <- df %>%
    # Ignore month number
    filter(EnvColumn != "month_num") %>%
    mutate(
      Label_raw = case_when(
        # SMI for ALB, HAI, SCH
        str_to_lower(EnvDataset) == "smi_upsoil" & region %in% c("ALB", "HAI", "SCH") ~ "SMI_upsoil [SMI_upsoil]",
        str_to_lower(EnvDataset) == "smi_total"  & region %in% c("ALB", "HAI", "SCH") ~ "SMI_total [SMI_total]",
        TRUE ~ EnvColumn
      ),
      Label = str_remove(Label_raw, "_detrended|_diffed|_diffed_detrended")
    )
  
  # All Family × Label combinations
  all_combinations <- expand.grid(
    Family = unique(df$Family),
    Label = unique(df$Label),
    stringsAsFactors = FALSE
  )
  
  # Aggregation
  df_agg <- df %>%
    group_by(Family, Label) %>%
    summarise(
      p_value = if (all(is.na(p_value))) NA_real_ else max(p_value, na.rm = TRUE),
      causality = {
        caus_clean <- causality
        caus_clean[is.na(caus_clean)] <- "no_test"
        if (all(caus_clean == "no_test")) "no_test"
        else caus_clean[which.max(p_value)]
      },
      .groups = "drop"
    )
  
  # Fill missing combinations
  all_combinations %>%
    left_join(df_agg, by = c("Family", "Label")) %>%
    mutate(causality = replace_na(causality, "no_test"))
}

# ------------------- Heatmap function -------------------
plot_ds22007_monthly_region <- function(df, region, out_dir){
  
  df_selected <- prepare_ds22007_monthly(df, region)
  
  # Beautify labels
  df_selected$Label <- ifelse(
    df_selected$Label %in% names(variable_labels),
    variable_labels[df_selected$Label],
    df_selected$Label
  )
  
  # Extract dataset and sort alphabetically
  df_selected <- df_selected %>%
    mutate(
      dataset = str_extract(Label, "\\[.*\\]") %>%
        str_remove_all("\\[|\\]") %>%
        str_trim(),
      Label = str_trim(Label)
    )
  
  label_levels <- df_selected %>%
    arrange(tolower(dataset), tolower(Label)) %>%
    pull(Label) %>%
    unique()
  df_selected$Label <- factor(df_selected$Label, levels = label_levels)
  
  # Dataset separators
  dataset_breaks <- df_selected %>%
    arrange(factor(Label, levels = label_levels)) %>%
    group_by(dataset) %>%
    summarise(max_y = max(as.numeric(Label))) %>%
    slice(-n())
  
  df_selected$causality <- factor(
    df_selected$causality,
    levels = c("causal", "non-causal", "no_test")
  )
  
  # ------------------- Plot -------------------
  p <- ggplot(df_selected, aes(x = Family, y = Label, fill = causality)) +
    geom_tile(color = "white", width = 0.9, height = 0.9) +
    geom_hline(
      data = dataset_breaks,
      aes(yintercept = max_y + 0.5),
      size = 0.3
    ) +
    scale_fill_manual(
      values = c(
        "causal" = "#0072B2",
        "non-causal" = "#D55E00",
        "no_test" = "grey80"
      ),
      name = "Granger causality"
    ) +
    scale_y_discrete(expand = c(0,0)) +
    scale_x_discrete(expand = c(0,0)) +
    theme_minimal(base_size = 10) +
    theme(
      axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, size = 7),
      axis.text.y = element_text(size = 7, hjust = 1),
      axis.title.x = element_text(margin = margin(t = 12), size = 10),
      axis.title.y = element_text(margin = margin(r = 15), size = 10),
      panel.grid = element_blank(),
      legend.position = "top"
    ) +
    labs(
      title = "Granger test results – ds22007 (monthly)",
      subtitle = paste("Region:", region),
      x = "Insect Families",
      y = "Environmental Variable [Dataset]"
    ) +
    coord_fixed(ratio = 1)
  
  file_name <- file.path(out_dir, paste0("ds22007_monthly_", region, "_heatmap.png"))
  ggsave(file_name, p, width = 11.7, height = 8.27, units = "in", bg = "white")
  
  message("✔ Plot saved: ", file_name)
}

# Output directory
out_dir <- "./plots/granger_heatmaps/ds22007_monthly" 
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE) 

# ------------------- Generate plots ------------------- 
for (region in names(ds22007_monthly_list)) { 
  plot_ds22007_monthly_region(ds22007_monthly_list[[region]], region, out_dir)
}
