# ---- Packages ----
library(dplyr)
library(tidyr)
library(ggplot2)
library(readr)
library(lubridate)

# Insect datasets
ds21969 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/21969_13_data.csv")
ds22007 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/22007_11_data.csv")
ds22008 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/22008_7_data.csv")
datasets <- list(ds21969=ds21969, ds22007=ds22007, ds22008=ds22008)

# ---- Hilfsfunktion: Monatsbuchstaben A–L in Monatszahl umwandeln ----
decode_collection_run <- function(run_letter) {
  mapvals <- setNames(4:15, LETTERS[1:12]) # A=4 (April), B=5, C=6, ...
  mapvals[run_letter]
}

datasets <- list(
  ds21969 = ds21969,
  ds22007 = ds22007,
  ds22008 = ds22008
)

# ---- Schleife über alle Datensätze ----
for (dataset_name in names(datasets)) {
  
  df <- datasets[[dataset_name]]
  
  # ---- Monats-Spalte harmonisieren ----
  if ("CollectionMonth" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = match(CollectionMonth, month.abb))
  } else if ("CollectionRun" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = decode_collection_run(CollectionRun))
  } else {
    stop(paste("Keine Monatsinformation in", dataset_name))
  }
  
  # ---- Datumsspalte erstellen ----
  df <- df %>%
    mutate(
      year = as.numeric(CollectionYear),
      date = suppressWarnings(ymd(paste0(year, "-", MonthNum, "-01")))
    ) %>%
    filter(!is.na(date))
  
  # ---- Summierte Individuenzahl pro Species & Region ----
  species_totals <- df %>%
    group_by(region = Exploratory, Species) %>%
    summarise(TotalAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Top 10 Species pro Region ----
  top_species <- species_totals %>%
    group_by(region) %>%
    slice_max(order_by = TotalAdults, n = 10, with_ties = FALSE) %>%
    ungroup() %>%
    select(region, Species)
  
  # ---- Filter nur auf Top-10 Species ----
  df_top <- df %>%
    inner_join(top_species, by = c("Exploratory" = "region", "Species"))
  
  # ---- Monatliche Aggregation ----
  df_summary <- df_top %>%
    group_by(Exploratory, date, Species) %>%
    summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Kompletter Zeitraster pro Region & Species (mit NAs für fehlende Monate) ----
  df_summary <- df_summary %>%
    group_by(Exploratory, Species) %>%
    complete(date = seq(min(date), max(date), by = "1 month")) %>%
    arrange(Exploratory, Species, date)
  
  # ---- Plot pro Region ----
  regions <- unique(df_summary$Exploratory)
  
  for (r in regions) {
    df_region <- df_summary %>% filter(Exploratory == r)
    
    p <- ggplot(df_region, aes(x = date, y = NumberAdults, color = Species)) +
      geom_line(size = 1, na.rm = FALSE) +  # behält NAs → Lücken in Linie
      geom_point(size = 1.8, na.rm = TRUE) +
      labs(
        title = paste("Top 10 most abundant species in", r),
        subtitle = paste("Monthly abundance –", dataset_name),
        x = "Date",
        y = "Number of adults",
        color = "Species"
      ) +
      scale_x_date(date_breaks = "6 months", date_labels = "%b\n%Y") +
      theme_minimal(base_size = 13) +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "right"
      )
    
    print(p)
  }
}



##########################families########################

# ---- Hilfsfunktion: Monatsbuchstaben A–L in Monatszahl umwandeln ----
decode_collection_run <- function(run_letter) {
  mapvals <- setNames(4:15, LETTERS[1:12]) # A=4 (April), B=5, C=6, ...
  mapvals[run_letter]
}

# ---- Schleife über alle Datensätze ----
for (dataset_name in names(datasets)) {
  
  df <- datasets[[dataset_name]]
  
  # ---- Monats-Spalte harmonisieren ----
  if ("CollectionMonth" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = match(CollectionMonth, month.abb))
  } else if ("CollectionRun" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = decode_collection_run(CollectionRun))
  } else {
    stop(paste("Keine Monatsinformation in", dataset_name))
  }
  
  # ---- Datumsspalte erstellen ----
  df <- df %>%
    mutate(
      year = as.numeric(CollectionYear),
      date = suppressWarnings(ymd(paste0(year, "-", MonthNum, "-01")))
    ) %>%
    filter(!is.na(date))
  
  # ---- Summierte Individuenzahl pro Family & Region ----
  family_totals <- df %>%
    group_by(region = Exploratory, Family) %>%
    summarise(TotalAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Top 10 Familien pro Region ----
  top_families <- family_totals %>%
    group_by(region) %>%
    slice_max(order_by = TotalAdults, n = 10, with_ties = FALSE) %>%
    ungroup() %>%
    select(region, Family)
  
  # ---- Filter nur auf Top-10 Familien ----
  df_top <- df %>%
    inner_join(top_families, by = c("Exploratory" = "region", "Family"))
  
  # ---- Monatliche Aggregation ----
  df_summary <- df_top %>%
    group_by(Exploratory, date, Family) %>%
    summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Kompletter Zeitraster pro Region & Familie (mit NAs für fehlende Monate) ----
  df_summary <- df_summary %>%
    group_by(Exploratory, Family) %>%
    complete(date = seq(min(date), max(date), by = "1 month")) %>%
    arrange(Exploratory, Family, date)
  
  # ---- Plot pro Region ----
  regions <- unique(df_summary$Exploratory)
  
  for (r in regions) {
    df_region <- df_summary %>% filter(Exploratory == r)
    
    p <- ggplot(df_region, aes(x = date, y = NumberAdults, color = Family)) +
      geom_line(size = 1, na.rm = FALSE) +  # Lücken bei NAs
      geom_point(size = 1.8, na.rm = TRUE) +
      labs(
        title = paste("Top 10 most abundant families in", r),
        subtitle = paste("Monthly abundance –", dataset_name),
        x = "Date",
        y = "Number of adults",
        color = "Family"
      ) +
      scale_x_date(date_breaks = "6 months", date_labels = "%b\n%Y") +
      theme_minimal(base_size = 13) +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "right"
      )
    
    print(p)
  }
}




####################ds21969####################
for (dataset_name in names(datasets)) {
  
  df <- datasets[[dataset_name]]
  
  # ---- Monats-Spalte harmonisieren ----
  if ("CollectionMonth" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = match(CollectionMonth, month.abb))
  } else if ("CollectionRun" %in% names(df)) {
    df <- df %>%
      mutate(MonthNum = decode_collection_run(CollectionRun))
  } else {
    stop(paste("Keine Monatsinformation in", dataset_name))
  }
  
  # ---- Datumsspalte erstellen ----
  df <- df %>%
    mutate(
      year = as.numeric(CollectionYear),
      date = suppressWarnings(ymd(paste0(year, "-", MonthNum, "-01")))
    ) %>%
    filter(!is.na(date))
  
  # ---- Summierte Individuenzahl pro Species & Region ----
  species_totals <- df %>%
    group_by(region = Exploratory, Species) %>%
    summarise(TotalAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Top 10 Species pro Region ----
  top_species <- species_totals %>%
    group_by(region) %>%
    slice_max(order_by = TotalAdults, n = 10, with_ties = FALSE) %>%
    ungroup() %>%
    select(region, Species)
  
  # ---- Filter nur auf Top-10 Species ----
  df_top <- df %>%
    inner_join(top_species, by = c("Exploratory" = "region", "Species"))
  
  # ---- Monatliche Aggregation ----
  df_summary <- df_top %>%
    group_by(Exploratory, date, Species) %>%
    summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  # ---- Kompletter Zeitraster pro Region & Species ----
  # ds21969: fehlende Monate mit 0 auffüllen
  fill_zero <- if(dataset_name == "ds21969") TRUE else FALSE
  
  df_summary <- df_summary %>%
    group_by(Exploratory, Species) %>%
    complete(date = seq(min(date), max(date), by = "1 month"),
             fill = list(NumberAdults = if(fill_zero) 0 else NA)) %>%
    arrange(Exploratory, Species, date)
  
  # ---- Plot pro Region ----
  regions <- unique(df_summary$Exploratory)
  
  for (r in regions) {
    df_region <- df_summary %>% filter(Exploratory == r)
    
    p <- ggplot(df_region, aes(x = date, y = NumberAdults, color = Species, group = Species)) +
      geom_line(size = 1) +  # Linien über 0, Lücken bei NA
      geom_point(size = 1.8, na.rm = TRUE) +
      labs(
        title = paste("Top 10 most abundant species in", r),
        subtitle = paste("Monthly abundance –", dataset_name),
        x = "Date",
        y = "Number of adults",
        color = "Species"
      ) +
      scale_x_date(date_breaks = "6 months", date_labels = "%b\n%Y") +
      theme_minimal(base_size = 13) +
      theme(
        axis.text.x = element_text(angle = 45, hjust = 1),
        legend.position = "right"
      )
    
    print(p)
  }
}

