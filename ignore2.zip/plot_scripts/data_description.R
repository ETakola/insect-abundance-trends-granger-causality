###################DATA DESCRIPTION PLOTS - INSECT DATA######

##################### load required packages ################
library(ggplot2)
library(dplyr)
library(forcats)
library(plotly)
library(scales)
library(readr)
library(cowplot)
library(htmltools)
library(viridis)
library(htmlwidgets)
library(stringr)
#################### Load and prepare data #################

# Dataset ds21969 (pre-filtered)
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv")

# Helper function to convert collection run letters into numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) through G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])
}

# Dataset ds22007
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),
    month = decode_collection_run(run_letter),
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),
    year = as.numeric(CollectionYear)
  ) %>%
  select(-run_letter)

##########################
# Remove spider families from dataset ds21969
##########################
spider_families <- c(
  "Araneidae", "Dictynidae", "Linyphiidae", "Lycosidae",
  "Philodromidae", "Salticidae", "Tetragnathidae",
  "Theridiidae", "Thomisidae"
)

ds21969 <- ds21969 %>%
  filter(!Family %in% spider_families)


# Abundance analysis: number of individuals per species and order (horizontal bar plots)

# Create folder for plots if it does not exist
dir.create("./plots/interactive_insect_plots", showWarnings = FALSE, recursive = TRUE)

#####################
# ds21969 - Species-level abundance
#####################
# Aggregate number of individuals per species
ds_summary <- ds21969 %>%
  group_by(Species) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE))

# Select top 30 species and reorder factor for plotting
p <- ds_summary %>%
  arrange(desc(NumberAdults)) %>%
  slice_head(n = 30) %>%
  mutate(Species = fct_reorder(Species, NumberAdults)) %>%
  ggplot(aes(x = Species, y = NumberAdults)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    x = "Species name",
    y = "Number of individuals"
  )

# Optional interactive Plotly version
ggplotly(p) %>%
  layout(
    title = "Top 30 most abundant species (dataset 21969)",
    margin = list(t = 50)
  )

# Save static plot as PNG
ggsave("./plots/interactive_insect_plots/ds21969_top30_species.png",
       plot = p, width = 10, height = 6, dpi = 300)

#####################
# ds21969 - Order-level abundance
#####################
# Aggregate number of individuals per order
ds_summary <- ds21969 %>%
  group_by(Order) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE))

# Reorder factor and create plot
p <- ds_summary %>%
  arrange(desc(NumberAdults)) %>%
  mutate(Order = fct_reorder(Order, NumberAdults)) %>%
  ggplot(aes(x = Order, y = NumberAdults)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    x = "Order name",
    y = "Number of individuals"
  ) +
  theme(axis.text.y = element_text(angle = 45, hjust = 1, size = 7, margin = margin(r = 15)))

# Optional interactive Plotly version
ggplotly(p) %>%
  layout(
    title = "Number of individuals per order (dataset 21969)",
    margin = list(t = 50, l = 140)
  )

# Save static plot as PNG
ggsave("./plots/interactive_insect_plots/ds21969_order_level.png",
       plot = p, width = 10, height = 6, dpi = 300)

#####################
# ds22007 - Species-level abundance
#####################
# Aggregate number of individuals per species
ds_summary <- ds22007 %>%
  group_by(Species) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE))

# Select top 30 species and reorder factor for plotting
p <- ds_summary %>%
  arrange(desc(NumberAdults)) %>%
  slice_head(n = 30) %>%
  mutate(Species = fct_reorder(Species, NumberAdults)) %>%
  ggplot(aes(x = Species, y = NumberAdults)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    x = "Species name",
    y = "Number of individuals"
  )

# Optional interactive Plotly version
ggplotly(p) %>%
  layout(
    title = "Top 30 most abundant species (dataset 22007)",
    margin = list(t = 50)
  )

# Save static plot as PNG
ggsave("./plots/interactive_insect_plots/ds22007_top30_species.png",
       plot = p, width = 10, height = 6, dpi = 300)


#####################
# ds22007 - Order-level abundance
#####################
# Aggregate number of individuals per order
ds_summary <- ds22007 %>%
  group_by(Order) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE))

# Reorder factor and create plot
p <- ds_summary %>%
  arrange(desc(NumberAdults)) %>%
  mutate(Order = fct_reorder(Order, NumberAdults)) %>%
  ggplot(aes(x = Order, y = NumberAdults)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    x = "Order name",
    y = "Number of individuals"
  )

# Optional interactive Plotly version
ggplotly(p) %>%
  layout(
    title = "Number of individuals per order (dataset 22007)",
    margin = list(t = 50)
  )

# Save static plot as PNG
ggsave("./plots/interactive_insect_plots/ds22007_order_level.png",
       plot = p, width = 10, height = 6, dpi = 300)


######################################################################################
##################### Species per location per year ##################################
######################################################################################

ds21969_clean <- ds21969 %>%
  filter(is.finite(NumberAdults), NumberAdults >= 0)

####### ds21969 ######
# Aggregate abundance data, excluding dominant species
ds_summary <- ds21969 %>%
  group_by(Species, Exploratory, year) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  filter(NumberAdults > 10)

# Interactive Plotly function per location
plotly_by_location <- function(location_name) {
  data_loc <- ds_summary %>%
    filter(Exploratory == location_name)
  
  # Calculate mean per year (to display as dashed line)
  mean_per_year <- data_loc %>%
    group_by(year) %>%
    summarise(MeanAdults = mean(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  gg <- ggplot(data_loc, aes(
    x = year,
    y = NumberAdults,
    color = Species,
    group = Species,
    text = paste0("Species: ", Species,
                  "<br>Year: ", year,
                  "<br>Count: ", NumberAdults)
  )) +
    geom_line(linewidth = 1) +
    geom_point(size = 2) +
    
    # Add mean abundance line per year
    geom_line(data = mean_per_year, aes(x = year, y = MeanAdults),
              color = "black", linetype = "dashed", linewidth = 1, inherit.aes = FALSE) +
    
    scale_x_continuous(
      breaks = scales::pretty_breaks(n = 10),
      labels = scales::number_format(accuracy = 1)
    ) +
    labs(
      title = paste("Location:", location_name),
      x = "Year",
      y = "Number of individuals"
    ) +
    theme_minimal() +
    scale_color_viridis_d(option = "plasma")
  
  ggplotly(gg, tooltip = "text") %>%
    layout(legend = list(orientation = "v", x = 1.02))
}

# Generate interactive plots
alb_plot <- plotly_by_location("ALB")
hai_plot <- plotly_by_location("HAI")
sch_plot <- plotly_by_location("SCH")

# Generate HTML page with tabs per location
html_page <- tagList(
  tags$html(
    tags$head(
      tags$title("Interactive species plots – ALB / HAI / SCH"),
      tags$style(HTML("
        .tab { display: none; }
        .tab-buttons button { margin: 5px; padding: 10px; font-size: 16px; }
        .tab-buttons { text-align: center; margin-bottom: 20px; }
      ")),
      tags$script(HTML("
        function showTab(id) {
          document.querySelectorAll('.tab').forEach(el => el.style.display = 'none');
          document.getElementById(id).style.display = 'block';
        }
        window.onload = function() { showTab('tab1'); };
      "))
    ),
    tags$body(
      div(class = "tab-buttons",
          tags$button("ALB", onclick = "showTab('tab1')"),
          tags$button("HAI", onclick = "showTab('tab2')"),
          tags$button("SCH", onclick = "showTab('tab3')")
      ),
      div(id = "tab1", class = "tab", alb_plot),
      div(id = "tab2", class = "tab", hai_plot),
      div(id = "tab3", class = "tab", sch_plot)
    )
  )
)

# Save as HTML file
save_html(html_page, file = "abundance_frequency_ds21969_more_10.html")

########## ds22007 ###########
# Aggregate abundance data, filtering extreme values
ds_summary <- ds22007 %>%
  group_by(Species, Exploratory, CollectionYear) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  filter(NumberAdults > 10)

# Interactive plot function per location with mean line
plotly_by_location <- function(location_name) {
  data_loc <- ds_summary %>%
    filter(Exploratory == location_name)
  
  mean_per_year <- data_loc %>%
    group_by(CollectionYear) %>%
    summarise(MeanAdults = mean(NumberAdults, na.rm = TRUE), .groups = "drop")
  
  gg <- ggplot(data_loc, aes(
    x = CollectionYear,
    y = NumberAdults,
    color = Species,
    group = Species,
    text = paste0("Species: ", Species,
                  "<br>Year: ", CollectionYear,
                  "<br>Count: ", NumberAdults)
  )) +
    geom_line(linewidth = 1) +
    geom_point(size = 2) +
    geom_line(data = mean_per_year, aes(x = CollectionYear, y = MeanAdults),
              color = "black", linetype = "dashed", linewidth = 1, inherit.aes = FALSE) +
    scale_x_continuous(
      breaks = scales::pretty_breaks(n = 10),
      labels = scales::number_format(accuracy = 1)
    ) +
    labs(
      title = paste("Location:", location_name),
      x = "Year",
      y = "Number of individuals"
    ) +
    theme_minimal() +
    scale_color_viridis_d(option = "plasma")
  
  ggplotly(gg, tooltip = "text") %>%
    layout(legend = list(orientation = "v", x = 1.02))
}

# Generate plots
alb_plot <- plotly_by_location("ALB")
hai_plot <- plotly_by_location("HAI")
sch_plot <- plotly_by_location("SCH")

# HTML page with tabs per location
html_page <- tagList(
  tags$html(
    tags$head(
      tags$title("Interactive species plots – ALB / HAI / SCH"),
      tags$style(HTML("
        .tab { display: none; }
        .tab-buttons button { margin: 5px; padding: 10px; font-size: 16px; }
        .tab-buttons { text-align: center; margin-bottom: 20px; }
      ")),
      tags$script(HTML("
        function showTab(id) {
          document.querySelectorAll('.tab').forEach(el => el.style.display = 'none');
          document.getElementById(id).style.display = 'block';
        }
        window.onload = function() { showTab('tab1'); };
      "))
    ),
    tags$body(
      div(class = "tab-buttons",
          tags$button("ALB", onclick = "showTab('tab1')"),
          tags$button("HAI", onclick = "showTab('tab2')"),
          tags$button("SCH", onclick = "showTab('tab3')")
      ),
      div(id = "tab1", class = "tab", alb_plot),
      div(id = "tab2", class = "tab", hai_plot),
      div(id = "tab3", class = "tab", sch_plot)
    )
  )
)

# Save as HTML file
save_html(html_page, file = "./plots/interactive_insect_plots/abundance_frequency_ds22007_more_10.html")
