#######################DETRENDING; DIFFERENCING; BOTH################################
###################load packages###########################
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) #for stationary tests 

####################load data##############################
# and get same names for the "year" and "month" column
#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Moisture Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))


# Crop yield and area data
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


#combined results from ADF/KPSS test - yearly 
stationarity_table_ds21969_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_yearly.csv", sep =",")
stationarity_table_ds22007_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_yearly.csv", sep =",")

stationarity_table_ds22007_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep =",")
stationarity_table_ds21969_ALB_HAI_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv" , sep =",")
stationarity_table_ds21969_SCH_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv" , sep =",")

##############################list with data for easier handling##############
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, 
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH, 
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  Fertilization = Fertilization, 
  mosaic = mosaic, 
  weather = weather, 
  ALB_crop = ALB_crop, 
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop, 
  ds21969 = ds21969, 
  ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped",group_cols = c("Croptype", "Fertilizer"),value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type ="grouped",group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds21969 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)


######################################################################
# Function: Aggregate datasets on a yearly basis
aggregate_yearly <- function(df, dataset_name) {
  
  # ---------------------------
  # 1. Filter for seasonal datasets (NDVI, NDWI, NirV)
  # Only keep months April (4) to October (10)
  # ---------------------------
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NirV_ALB", "NirV_HAI", "NirV_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
  # ---------------------------
  # 2. Special handling for crop datasets
  # ---------------------------
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
                  .groups = "drop")
    )
  }
  
  # ---------------------------
  # 3. Define grouping and aggregation columns
  # ---------------------------
  group_col <- NULL
  sum_cols <- c()
  
  # Insect datasets: sum adults, grouped by Exploratory & Family
  if (dataset_name %in% c("ds21969","ds22007")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  # Fertilization and mosaic datasets
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  # Columns to average (exclude year, grouping, sum, month/day)
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # ---------------------------
  # 4. Aggregate other datasets
  # ---------------------------
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################
# Special aggregation for the weather dataset (per plot → per region)
aggregate_weather <- function(weather_df) {
  
  sum_cols <- c("precipitation_radolan", "precipitation_radolan_rain_days")
  mean_cols <- c(
    "rH_200", "rH_200_max", "rH_200_min",
    "SM_10", "SM_20",
    "Ta_10", "Ta_10_max", "Ta_10_min",
    "Ta_200", "Ta_200_max", "Ta_200_min",
    "Ts_05", "Ts_05_max", "Ts_05_min",
    "Ts_10", "Ts_10_max", "Ts_10_min",
    "Ts_20", "Ts_20_max", "Ts_20_min",
    "Ts_50", "Ts_50_max", "Ts_50_min"
  )
  
  # Step 1: Aggregate per plot
  weather_annual <- weather_df %>%
    group_by(plotID, year) %>%
    summarise(
      region = first(region),
      across(all_of(sum_cols), sum, na.rm = TRUE),
      across(all_of(mean_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
  # Step 2: Aggregate per region
  weather_region <- weather_annual %>%
    group_by(region, year) %>%
    summarise(
      across(all_of(sum_cols), mean, na.rm = TRUE),  # Average the sum columns
      across(all_of(mean_cols), mean, na.rm = TRUE), # Average the mean columns
      .groups = "drop"
    )
  
  return(weather_region)
}

######################################################################
# 4. Prepare yearly aggregated data for insect datasets ds21969 and ds22007

# Determine the year ranges of each insect dataset
years_ds21969 <- range(ds21969$year, na.rm = TRUE)
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

# Aggregate all datasets on a yearly basis
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    # Use the special weather aggregation
    aggregate_weather(data_list[[name]])
  } else {
    # Use the aggregation function for other datasets
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# Filter datasets to the corresponding year ranges for each insect dataset
data_for_ds21969 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2]))
data_for_ds22007 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds22007[1], year <= years_ds22007[2]))

# Remove the other insect dataset from each list to avoid duplication
data_for_ds21969 <- data_for_ds21969[!names(data_for_ds21969) %in% c("ds22007")]
data_for_ds22007 <- data_for_ds22007[!names(data_for_ds22007) %in% c("ds21969")]

##################################################################
##################SELECT ONLY STATIONARY VARIABLES#################
# Yearly ADF and KPSS tests results
ds21969_stationary_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_stationary_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

##################SELECT VARIABLES THAT REQUIRE DETRENDING#################
# Yearly variables where ADF indicates non-stationarity but KPSS is stationary
ds21969_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds22007_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")


#############################DETRENDING##################################################
# Filter insect dataset ds21969 for detrending

# -------------------------------------------------------------------
# Function to filter a dataset for detrending based on overview table
# Only retains variables that need detrending and relevant grouping columns
# -------------------------------------------------------------------
filter_ds21969_detrend <- function(df, dataset_name, detrend_overview) {
  
  # Check if dataset appears in detrending overview
  if(!dataset_name %in% unique(detrend_overview$dataset)) return(NULL)
  
  # Extract variables to detrend
  allowed_columns <- detrend_overview %>%
    dplyr::filter(dataset == dataset_name) %>%
    dplyr::pull(variable)
  
  # Possible grouping columns to retain
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Columns to keep in filtered dataset
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter rows by allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- detrend_overview %>%
      dplyr::filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      dplyr::pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite datasets (NDVI, NDMI, NIRv)
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering function to all ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_detrend <- imap(data_for_ds21969, function(df, name) {
  filter_ds21969_detrend(df, name, ds21969_detrend_yearly)
})

# Remove any NULL entries (datasets not needing detrending)
filtered_ds21969_detrend <- filtered_ds21969_detrend[!sapply(filtered_ds21969_detrend, is.null)]

# -----------------------------
# Test output
# -----------------------------
cat("Filtered datasets for detrending:\n")
print(names(filtered_ds21969_detrend))

cat("\nColumns in each dataset:\n")
for (name in names(filtered_ds21969_detrend)) {
  cat(paste0(name, ": "), paste(names(filtered_ds21969_detrend[[name]]), collapse=", "), "\n")
}

##################DETRENDING DS21969##################################
# -------------------------------------------------------------------
# Function to perform linear detrending for each time series column
# Removes linear temporal trends to improve stationarity
# Purpose:
#   Removes a linear temporal trend from selected time series variables
#   using linear regression (value ~ time).
#
#   The function is robust to missing values by using na.exclude(),
#   ensuring that:
#     - residuals have the same length as the original data
#     - rows with missing values remain aligned with the time axis
#
# -------------------------------------------------------------------
detrend_ts <- function(df, value_cols, time_col = "year") {
  
  # Create a copy of the input data to store detrended values
  df_detrended <- df
  
  # Loop over all variables that should be detrended
  for (col in value_cols) {
    
    # Proceed only if the variable exists in the data frame
    if (col %in% names(df)) {
      
      # Check that there are at least two non-missing observations
      # (required to fit a linear model)
      if (sum(!is.na(df[[col]])) > 1) {
        
        # Fit a linear model of the variable against time
        # na.exclude() ensures residuals keep the original data length
        fit <- lm(
          df[[col]] ~ df[[time_col]],
          na.action = na.exclude
        )
        
        # Replace the original variable with detrended residuals
        df_detrended[[col]] <- residuals(fit)
        
      } else {
        # If there is insufficient data, return NA for the entire variable
        df_detrended[[col]] <- NA_real_
      }
    }
  }
  
  return(df_detrended)
}


# -------------------------------------------------------------------
# Apply detrending function to all filtered datasets
# -------------------------------------------------------------------
filtered_ds21969_detrended <- imap(filtered_ds21969_detrend, function(df, name) {
  
  # Determine which columns to detrend based on overview table
  value_cols <- ds21969_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts(df, value_cols, time_col = "year")
})

# -----------------------------
# Test output
# -----------------------------
cat("Detrended datasets:\n")
print(names(filtered_ds21969_detrended))

cat("\nExample: first rows of a dataset:\n")
print(head(filtered_ds21969_detrended[[1]]))
str(filtered_ds21969_detrended)


##################ADF-Test for ds21969 detrended#######################

######################################################################
# 1. Safe wrapper for ADF test
# Ensures the test handles missing data and small series gracefully
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  res <- tryCatch({
    test <- adf.test(x, k = 0)  # k=0: no lag (baseline)
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  return(res)
}

######################################################################
# 2. Configuration for ds21969: grouped by Exploratory site and family
configs_ds21969 <- list(
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

######################################################################
# 3. Run ADF Test for all detrended ds21969 datasets
# Iterates over datasets and groups, applying the safe ADF test
run_adf_tests_ds21969 <- function(detrended_list, configs) {
  
  results <- list()
  
  for (ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    if (is.null(cfg)) next
    
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_adf_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        for (v in vcols) {
          res <- safe_adf_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

######################################################################
# 4. Run the ADF tests
res_adf_ds21969_detrended <- run_adf_tests_ds21969(filtered_ds21969_detrended, configs_ds21969)

######################################################################
# 5. Preview results and optionally export
head(res_adf_ds21969_detrended)
#write.csv(res_adf_ds21969_detrended, "./tables/detrend_diff_stationarity/adf_test_ds21969_detrended.csv", row.names = FALSE)

################## KPSS-Test for ds21969 detrended #######################

# Safe wrapper for KPSS test to handle missing values and short series
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# Run KPSS tests for grouped detrended datasets
run_kpss_tests_ds21969 <- function(detrended_list, configs) {
  results <- list()
  for(ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    if(is.null(cfg)) next
    if(cfg$type == "grouped") {
      gcols <- intersect(cfg$group_cols, names(df))
      vcols <- intersect(cfg$value_cols, names(df))
      if(length(gcols) > 0) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y) %>% mutate(across(everything(), as.character))
            res_rows <- lapply(vcols, function(v) cbind(dataset = ds_name, variable = v, safe_kpss_test(.x[[v]]), group_info))
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        results[[length(results)+1]] <- do.call(rbind, lapply(vcols, function(v) cbind(dataset = ds_name, variable = v, safe_kpss_test(df[[v]]))))
      }
    }
  }
  bind_rows(results)
}

# Execute KPSS test
res_kpss_ds21969_detrended <- run_kpss_tests_ds21969(filtered_ds21969_detrended, configs_ds21969)

# Combine ADF and KPSS results into a single table
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  tibble(
    status_adf  = ifelse(!is.na(adf_p) & adf_p < alpha, "stationary", "non-stationary"),
    status_kpss = ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  )
}

combined_stationarity_ds21969 <- res_adf_ds21969_detrended %>%
  rename(adf_statistic = statistic, adf_pvalue = p_value) %>%
  left_join(
    res_kpss_ds21969_detrended %>% rename(kpss_statistic = statistic, kpss_pvalue = p_value),
    by = c("dataset","variable", "Exploratory","Family")
  ) %>%
  rowwise() %>%
  mutate(status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))) %>%
  unnest(cols = c(status)) %>%
  ungroup()

# Preview and export
cat("Combined stationarity table for ds21969:\n")
print(head(combined_stationarity_ds21969))

write.csv(
  combined_stationarity_ds21969,
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_yearly.csv",
  row.names = FALSE
)


################# TAKE ONLY DATASETS REQUIRING DIFFERENCING #################

# Yearly datasets needing differencing
ds21969_differencing_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds22007_differencing_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# Monthly datasets needing differencing
ds22007_differencing_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")


################## DIFFERENCING DS21969 ##############################

# -------------------------------------------------------------------
# Function: Filter ds21969 for differencing
# -------------------------------------------------------------------
filter_ds21969_diff <- function(df, dataset_name, diff_overview) {
  
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% select(any_of(columns_to_keep))
  
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Generate filtered list for differencing
# -------------------------------------------------------------------
filtered_ds21969_diff <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_diff(df, name, ds21969_differencing_yearly)
})

filtered_ds21969_diff <- filtered_ds21969_diff[!sapply(filtered_ds21969_diff, is.null)]

cat("Filtered datasets for differencing:\n")
print(names(filtered_ds21969_diff))


################## STATIONARITY TESTS FOR DIFFERENCED DS21969 #######################

# -------------------------------------------------------------------
# Safe wrapper for ADF test
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(statistic = as.numeric(test$statistic),
               p_value = as.numeric(test$p.value),
               status = ifelse(test$p.value < 0.05, "stationary", "non-stationary"))
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# -------------------------------------------------------------------
# Safe wrapper for KPSS test
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(statistic = as.numeric(test$statistic),
               p_value = as.numeric(test$p.value),
               status = ifelse(test$p.value < 0.05, "non-stationary", "stationary"))
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# -------------------------------------------------------------------
# Function: Differencing + ADF + KPSS tests
# -------------------------------------------------------------------
run_stationarity_tests_diff <- function(diff_list) {
  
  results <- list()
  
  for(ds_name in names(diff_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(group_cols)))
      res_list <- df_grouped %>%
        group_map(~{
          group_info <- as.data.frame(.y) %>% mutate(across(everything(), as.character))
          df_diff <- .x
          for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
          
          res_rows <- lapply(value_cols, function(col) {
            adf_res  <- safe_adf_test(df_diff[[col]])
            kpss_res <- safe_kpss_test(df_diff[[col]])
            cbind(dataset = ds_name, variable = col,
                  adf_statistic = adf_res$statistic, adf_pvalue = adf_res$p_value, status_adf = adf_res$status,
                  kpss_statistic = kpss_res$statistic, kpss_pvalue = kpss_res$p_value, status_kpss = kpss_res$status,
                  group_info, stringsAsFactors = FALSE)
          })
          do.call(rbind, res_rows)
        })
      results[[length(results)+1]] <- do.call(rbind, res_list)
    } else {
      df_diff <- df
      for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
      res_rows <- lapply(value_cols, function(col) {
        adf_res  <- safe_adf_test(df_diff[[col]])
        kpss_res <- safe_kpss_test(df_diff[[col]])
        cbind(dataset = ds_name, variable = col,
              adf_statistic = adf_res$statistic, adf_pvalue = adf_res$p_value, status_adf = adf_res$status,
              kpss_statistic = kpss_res$statistic, kpss_pvalue = kpss_res$p_value, status_kpss = kpss_res$status,
              stringsAsFactors = FALSE)
      })
      results[[length(results)+1]] <- do.call(rbind, res_rows)
    }
  }
  
  bind_rows(results)
}

# -------------------------------------------------------------------
# Execute stationarity tests on differenced data
# -------------------------------------------------------------------
res_stationarity_filtered_diff <- run_stationarity_tests_diff(filtered_ds21969_diff)

# Preview and export
head(res_stationarity_filtered_diff)

write.csv(
  res_stationarity_filtered_diff,
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_yearly.csv",
  row.names = FALSE
)


################# TAKE ONLY DATASETS REQUIRING BOTH METHODS #################

# Yearly
ds21969_diff_and_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_diff_and_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")


######################## FILTER DS21969 FOR DIFFERENCING & DETRENDING ##################

filter_ds21969_diff_detrend <- function(df, dataset_name, overview_table) {
  if(!dataset_name %in% unique(overview_table$dataset)) return(NULL)
  
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% select(any_of(columns_to_keep))
  
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
  }
  
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH","NDMI_ALB","NDMI_HAI","NDMI_SCH","NIRv_ALB","NIRv_HAI","NIRv_SCH")) {
    df_filtered <- df_filtered %>% select(-any_of("region"))
  }
  
  return(df_filtered)
}

filtered_ds21969_diff_detrend <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_diff_detrend(df, name, ds21969_diff_and_detrend_yearly)
})

filtered_ds21969_diff_detrend <- filtered_ds21969_diff_detrend[!sapply(filtered_ds21969_diff_detrend, is.null)]

cat("Filtered datasets for differencing + detrending:\n")
print(names(filtered_ds21969_diff_detrend))


######################## RUN ADF + KPSS TESTS ##################

run_stationarity_tests <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_detrend_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~{
        res_list <- list()
        
        for(val_col in value_cols) {
          ts_data <- .x %>% select(year, !!sym(val_col)) %>% filter(!is.na(.data[[val_col]]))
          if(nrow(ts_data) < 3) next
          
          detrended <- tryCatch(resid(lm(ts_data[[val_col]] ~ ts_data$year)), error = function(e) NULL)
          if(is.null(detrended) || length(detrended) < 2) next
          
          differenced <- diff(detrended)
          
          kpss_p <- tryCatch(tseries::kpss.test(differenced, null = "Level")$p.value, error = function(e) NA)
          adf_p  <- tryCatch(tseries::adf.test(differenced, alternative = "stationary")$p.value, error = function(e) NA)
          
          res_list[[val_col]] <- tibble(variable = val_col, adf_pvalue = adf_p, kpss_pvalue = kpss_p)
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

stationarity_results <- run_stationarity_tests(filtered_ds21969_diff_detrend)

cat("Stationarity test results:\n")
names(stationarity_results)


######################## COMBINE RESULTS INTO TABLE ##################
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  adf_status  <- ifelse(!is.na(adf_p) & adf_p < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  tibble(status_adf = adf_status, status_kpss = kpss_status)
}

stationarity_table_ds21969_both_yearly <- imap_dfr(stationarity_results, function(df, ds_name) {
  if(nrow(df) == 0) return(NULL)
  
  df %>%
    mutate(dataset = ds_name) %>%
    rowwise() %>%
    mutate(status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))) %>%
    unnest(cols = c(status)) %>%
    select(dataset, everything())
})

cat("Stationarity Table:\n")
print(stationarity_table_ds21969_both_yearly)

write.csv(
  stationarity_table_ds21969_both_yearly,
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_yearly.csv",
  row.names = FALSE
)


####################### DS22007 ##############################
##################
# DETREND TABLES
##################
ds22007_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

##################
# DIFFERENCING TABLES
##################
ds22007_diff_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

##################
# BOTH METHODS TABLES
##################
ds22007_both_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

############################# DETREND DS22007_YEARLY ##############################

# -------------------------------------------------------------------
# 1 Filter function for detrending (analogous to ds21969)
# -------------------------------------------------------------------
filter_ds22007_detrend <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is listed in overview
  if(!dataset_name %in% detrend_overview$dataset) {
    cat("Dataset", dataset_name, "not in detrend overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Allowed columns
  allowed_columns <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns
  grouping_columns <- c("year","Croptype","Fertilizer","region","var","measure","Exploratory","Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Filter data frame
  df_filtered <- df %>% dplyr::select(any_of(unique(c(existing_group_cols, allowed_columns))))
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# 2 Create filtered list of all ds22007 yearly datasets
# -------------------------------------------------------------------
filtered_ds22007_detrend <- purrr::imap(
  data_for_ds22007,
  function(df, name) {
    filter_ds22007_detrend(df, name, ds22007_detrend_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_detrend <- filtered_ds22007_detrend[!sapply(filtered_ds22007_detrend, is.null)]

cat("\nFiltered datasets for detrending:\n")
print(names(filtered_ds22007_detrend))

# -------------------------------------------------------------------
# 3 Linear detrending function (NA-safe)
# -------------------------------------------------------------------
detrend_ts <- function(df, value_cols, time_col = "year") {
  
  df_detrended <- df
  
  for (col in value_cols) {
    if (col %in% names(df)) {
      
      if (sum(!is.na(df[[col]])) > 1) {
        
        fit <- lm(
          df[[col]] ~ df[[time_col]],
          na.action = na.exclude
        )
        
        df_detrended[[col]] <- residuals(fit)
        
      } else {
        df_detrended[[col]] <- NA_real_
      }
    }
  }
  
  return(df_detrended)
}

# -------------------------------------------------------------------
# 4 Apply detrending to filtered datasets
# -------------------------------------------------------------------
filtered_ds22007_detrended <- imap(filtered_ds22007_detrend, function(df, name) {
  value_cols <- ds22007_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts(df, value_cols, time_col = "year")
})

cat("\nDetrended datasets:\n")
print(names(filtered_ds22007_detrended))

# Example output
if(length(filtered_ds22007_detrended) > 0) {
  cat("\nExample: first rows of the first dataset:\n")
  print(head(filtered_ds22007_detrended[[1]]))
}

# -------------------------------------------------------------------
# 5 Safe ADF test function
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(
      ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA
    ))
  }
  res <- tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(
      ADF_statistic = as.numeric(test$statistic),
      ADF_pvalue = as.numeric(test$p.value),
      ADF_status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(
    ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA
  ))
  return(res)
}

# -------------------------------------------------------------------
# 5b Safe KPSS test function
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(
      KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA
    ))
  }
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      KPSS_statistic = as.numeric(test$statistic),
      KPSS_pvalue = as.numeric(test$p.value),
      KPSS_status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(
    KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA
  ))
  return(res)
}

# -------------------------------------------------------------------
# 7 Configuration for ds22007
# -------------------------------------------------------------------
configs_ds22007 <- list(
  ds22007 = list(
    type = "grouped",
    group_cols = c("Exploratory","Family"),
    value_cols = c("NumberAdults")
  )
)

# -------------------------------------------------------------------
# 8 Combined ADF and KPSS test runner
# -------------------------------------------------------------------
run_stationarity_tests_ds22007 <- function(detrended_list, configs) {
  results <- list()
  
  for(ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    if(is.null(cfg)) next
    
    gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
    vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
    if(length(vcols) == 0) next
    
    if(length(gcols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(gcols)))
      
      res_list <- df_grouped %>% group_map(~ {
        group_info <- as.data.frame(.y)
        group_info[] <- lapply(group_info, as.character)
        
        res_rows <- list()
        for(v in vcols) {
          adf_res  <- safe_adf_test(.x[[v]])
          kpss_res <- safe_kpss_test(.x[[v]])
          
          full <- cbind(
            dataset = ds_name,
            variable = v,
            adf_res,
            kpss_res,
            group_info,
            stringsAsFactors = FALSE
          )
          res_rows[[length(res_rows) + 1]] <- full
        }
        
        do.call(rbind, res_rows)
      })
      
      results[[length(results) + 1]] <- do.call(rbind, res_list)
      
    } else {
      for(v in vcols) {
        adf_res  <- safe_adf_test(df[[v]])
        kpss_res <- safe_kpss_test(df[[v]])
        
        results[[length(results) + 1]] <- cbind(
          dataset = ds_name,
          variable = v,
          adf_res,
          kpss_res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  bind_rows(results)
}

# -------------------------------------------------------------------
# 9 Run tests
# -------------------------------------------------------------------
res_stationarity_ds22007_detrended <- run_stationarity_tests_ds22007(
  filtered_ds22007_detrended,
  configs_ds22007
)

# -------------------------------------------------------------------
# 10 Export
# -------------------------------------------------------------------
write.csv(
  res_stationarity_ds22007_detrended,
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_yearly.csv",
  row.names = FALSE
)


#############################
### DIFFERENCING DS22007_YEARLY
#############################

# -------------------------------------------------------------------
# Function: filter ds22007 dataset for differencing
# -------------------------------------------------------------------
filter_ds22007_diff <- function(df, dataset_name, diff_overview) {
  
  # Check whether dataset is listed in overview
  if(!dataset_name %in% unique(diff_overview$dataset)) {
    cat("Dataset", dataset_name, "not in differencing overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Extract variables to be differenced
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep only columns that exist in the data frame
  allowed_columns <- intersect(allowed_columns, names(df))
  cat("Allowed columns to difference (exist in df):", paste(allowed_columns, collapse = ", "), "\n")
  
  # Grouping columns
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region",
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  cat("Existing grouping columns in df:", paste(existing_group_cols, collapse = ", "), "\n")
  
  # Select existing columns only
  columns_to_keep <- intersect(unique(c(existing_group_cols, allowed_columns)), names(df))
  df_filtered <- df %>% dplyr::select(all_of(columns_to_keep))
  cat("Number of rows after column selection:", nrow(df_filtered), "\n")
  
  # Filter allowed values for grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite products
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Create filtered list of all ds22007 yearly datasets
# -------------------------------------------------------------------
filtered_ds22007_diff <- purrr::imap(
  data_for_ds22007,
  function(df, name) {
    filter_ds22007_diff(df, name, ds22007_differencing_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_diff <- filtered_ds22007_diff[!sapply(filtered_ds22007_diff, is.null)]

cat("Filtered datasets for differencing:\n")
print(names(filtered_ds22007_diff))

#############################################
### ADF + KPSS TESTS FOR DIFFERENCED DS22007
#############################################

# -------------------------------------------------------------------
# SAFE KPSS TEST
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) {
    return(data.frame(KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA))
  }
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      KPSS_statistic = as.numeric(test$statistic),
      KPSS_pvalue = as.numeric(test$p.value),
      KPSS_status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA))
  return(res)
}

# -------------------------------------------------------------------
# SAFE ADF TEST
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) {
    return(data.frame(ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA))
  }
  res <- tryCatch({
    test <- adf.test(x, alternative = "stationary")
    data.frame(
      ADF_statistic = as.numeric(test$statistic),
      ADF_pvalue = as.numeric(test$p.value),
      ADF_status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA))
  return(res)
}

# -------------------------------------------------------------------
# Function: differencing with ADF and KPSS tests for all groups
# -------------------------------------------------------------------
run_stationarity_tests_diff <- function(diff_list) {
  results <- list()
  
  for(ds_name in names(diff_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_list[[ds_name]]
    
    # Identify numeric columns
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(group_cols)))
      
      res_list <- df_grouped %>% group_map(~ {
        group_info <- as.data.frame(.y)
        group_info[] <- lapply(group_info, as.character)
        res_rows <- list()
        
        # Differencing
        df_diff <- .x
        for(col in value_cols) {
          df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
        }
        
        # Run tests
        for(col in value_cols) {
          adf_res  <- safe_adf_test(df_diff[[col]])
          kpss_res <- safe_kpss_test(df_diff[[col]])
          
          full <- cbind(
            dataset = ds_name,
            variable = col,
            adf_res,
            kpss_res,
            group_info,
            stringsAsFactors = FALSE
          )
          res_rows[[length(res_rows)+1]] <- full
        }
        
        do.call(rbind, res_rows)
      })
      
      results[[length(results)+1]] <- do.call(rbind, res_list)
      
    } else {
      # No grouping
      df_diff <- df
      for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
      
      res_rows <- lapply(value_cols, function(col) {
        adf_res  <- safe_adf_test(df_diff[[col]])
        kpss_res <- safe_kpss_test(df_diff[[col]])
        cbind(dataset = ds_name, variable = col, adf_res, kpss_res, stringsAsFactors = FALSE)
      })
      
      results[[length(results)+1]] <- do.call(rbind, res_rows)
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

# -------------------------------------------------------------------
# RUN TESTS
# -------------------------------------------------------------------
res_stationarity_ds22007_diff <- run_stationarity_tests_diff(filtered_ds22007_diff)

# -------------------------------------------------------------------
# EXPORT
# -------------------------------------------------------------------
write.csv(
  res_stationarity_ds22007_diff,
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_yearly.csv",
  row.names = FALSE
)

######################### DS22007 - YEARLY – DETRENDING + DIFFERENCING #########################

# =====================================================================================
# 1) Function to filter datasets (analogous to ds21969)
# =====================================================================================
filter_ds22007_diff_detrend <- function(df, dataset_name, overview_table) {
  
  # Proceed only if dataset is listed in overview table
  if(!dataset_name %in% unique(overview_table$dataset)) {
    cat("Dataset", dataset_name, "not found in overview\n")
    return(NULL)
  }
  
  # Extract variables to be processed
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns to retain
  grouping_columns <- c(
    "year", "Croptype", "Fertilizer", "region", 
    "var", "measure", "Exploratory", "Family"
  )
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Define columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% 
    dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter based on allowed combinations
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% 
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite data
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-dplyr::any_of("region"))
  }
  
  cat("Dataset", dataset_name, "filtered.\n")
  return(df_filtered)
}

# =====================================================================================
# 2) Apply to all ds22007 datasets
# =====================================================================================

filtered_ds22007_diff_detrend <- purrr::imap(
  data_for_ds22007,
  function(df, name){
    filter_ds22007_diff_detrend(df, name, ds22007_diff_and_detrend_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_diff_detrend <- filtered_ds22007_diff_detrend[!sapply(filtered_ds22007_diff_detrend, is.null)]

cat("\nFiltered datasets for DS22007:\n")
print(names(filtered_ds22007_diff_detrend))

# =====================================================================================
# 3) Function for ADF + KPSS on differenced and detrended data
# =====================================================================================

run_stationarity_tests_ds22007 <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- diff_detrend_list[[ds_name]]
    
    # Identify numeric columns (excluding year)
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    
    # Grouping columns
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        
        res_list <- list()
        
        for(val_col in value_cols) {
          
          ts_data <- .x %>%
            dplyr::select(year, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 3) next
          
          #--------------------------------------------------------------
          # 1) detrending
          #--------------------------------------------------------------
          detrended <- tryCatch(resid(lm(ts_data[[val_col]] ~ ts_data$year)),
                                error = function(e) NULL)
          if(is.null(detrended) || length(detrended) < 2) next
          
          #--------------------------------------------------------------
          # 2) differencing
          #--------------------------------------------------------------
          differenced <- diff(detrended)
          
          #--------------------------------------------------------------
          # Stationarity tests
          #--------------------------------------------------------------
          kpss_p <- tryCatch(
            tseries::kpss.test(differenced, null = "Level")$p.value,
            error = function(e) NA
          )
          
          adf_p <- tryCatch(
            tseries::adf.test(differenced, alternative = "stationary")$p.value,
            error = function(e) NA
          )
          
          res_list[[val_col]] <- tibble(
            variable = val_col,
            adf_pvalue = adf_p,
            kpss_pvalue = kpss_p
          )
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

# =====================================================================================
# 4) Run tests
# =====================================================================================

stationarity_results_ds22007 <- run_stationarity_tests_ds22007(filtered_ds22007_diff_detrend)

cat("\nStationarity test results:\n")
print(names(stationarity_results_ds22007))

# =====================================================================================
# 5) Function to derive stationarity status (same as ds21969)
# =====================================================================================

get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  adf_status  <- ifelse(!is.na(adf_p)  & adf_p  < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  
  tibble(
    status_adf  = adf_status,
    status_kpss = kpss_status
  )
}

# =====================================================================================
# 6) Convert result list to table
# =====================================================================================

stationarity_table_ds22007_both_yearly <- purrr::imap_dfr(
  stationarity_results_ds22007,
  function(df, ds_name) {
    if(nrow(df) == 0) return(NULL)
    
    df %>%
      mutate(dataset = ds_name) %>%
      rowwise() %>%
      mutate(
        status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))
      ) %>%
      unnest(cols = c(status)) %>%
      dplyr::select(dataset, everything())
  }
)

# =====================================================================================
# 7) Output and export
# =====================================================================================

cat("\nStationarity Table DS22007:\n")
print(stationarity_table_ds22007_both_yearly)

write.csv(
  stationarity_table_ds22007_both_yearly,
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_yearly.csv",
  row.names = FALSE
)

