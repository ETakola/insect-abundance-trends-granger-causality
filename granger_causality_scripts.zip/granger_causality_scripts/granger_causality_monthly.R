################### GRANGER CAUSALITY - MONTHLY ###########################################
#################### ds22007 #############################################################

################### Load packages ###########################                                          
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests 

#################### Load data ##############################
# Ensure consistent column names for "year" and "month"

# Soil Moisture Index (SMI)
SMI_total <- read.csv("D:/Masterarbeit/tables/smi_means_Gesamtboden.csv", sep=',', header=TRUE) %>% mutate(time = as.Date(time), 
                                                                                                           day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("D:/Masterarbeit/tables/smi_means_Oberboden.csv", sep=',', header=TRUE) %>% mutate(time = as.Date(time), 
                                                                                                          day = day(time), month = month(time), year = year(time))

# Satellite indices
NDVI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_ALB_2007_2019.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_HAI_all.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_SCH_all.csv") %>% dplyr::select(-`system:index`)

NDWI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_ALB_2007_2019.csv") %>% dplyr::select(-`system:index`)
NDWI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_HAI_all.csv") %>% dplyr::select(-`system:index`)
NDWI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_SCH_all.csv") %>% dplyr::select(-`system:index`)

NirV_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_ALB_2007_2019_norm.csv") %>% dplyr::select(-`system:index`)
NirV_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_HAI_all.csv") %>% dplyr::select(-`system:index`)
NirV_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_SCH_all.csv") %>% dplyr::select(-`system:index`)

# Fertilization
Fertilization <- read.csv("D:/Masterarbeit/environmental_data/Cropland_Maps/Cropland_Maps/cropland_means_by_region.csv", sep=';', header=TRUE) %>% rename(year = Year)

# Mosaic
mosaic <- read_csv("D:/Masterarbeit/tables/mosaic_zones_area_weighted_means_251001.csv")

# Weather
weather <- read.csv("D:/Masterarbeit/environmental_data/bexis_climate_data_250818/plots.csv") %>% mutate(datetime = ym(datetime),
                                                                                                         year = year(datetime), month = month(datetime)) %>% mutate(region=case_when(
                                                                                                           str_starts(plotID,"A") ~ "ALB",
                                                                                                           str_starts(plotID,"H") ~ "HAI",
                                                                                                           str_starts(plotID,"S") ~ "SCH",
                                                                                                           TRUE ~ NA_character_
                                                                                                         ))

# Crop yield and area
ALB_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_ALB_filled.csv")
HAI_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_HAI_filled.csv")
SCH_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_SCH_filled.csv")

############################################################################################
# Load insect datasets
ds21969 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/21969_13_data.csv") %>%  mutate(
  month_clean = str_trim(CollectionMonth),                     
  MonthNum = case_when(
    is.na(month_clean) ~ NA_character_,
    month_clean %in% month.abb ~ sprintf("%02d", match(month_clean, month.abb)),
    TRUE ~ NA_character_                              
  )
) %>% rename(year = CollectionYear,
             month = MonthNum) 

# Function: extract month from "CollectionRun"
decode_collection_run <- function(run_letter){
  # A = April = 4, B = May = 5, ..., G = October = 10
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # returns NA if letter not mapped
}

str(ds21969)
unique(ds21969$month)

############################################################################################

# Load ds22007
ds22007 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/22007_11_data.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # extract letter from CollectionRun
    month = decode_collection_run(run_letter),  # convert letter to month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # optional: character format
    year = as.numeric(CollectionYear)
  ) %>%
  dplyr::select(-run_letter) 

############################## Create data list for easier handling ##############
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, 
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH, 
  NDWI_ALB = NDWI_ALB,
  NDWI_HAI = NDWI_HAI,
  NDWI_SCH = NDWI_SCH,
  NirV_ALB = NirV_ALB,
  NirV_HAI = NirV_HAI,
  NirV_SCH = NirV_SCH,
  Fertilization = Fertilization, 
  mosaic = mosaic, 
  weather = weather, 
  ALB_crop = ALB_crop, 
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop, 
  ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDWI_ALB = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_HAI = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_SCH = list(type = "columns", cols = c("mean_NDWI")),
  NirV_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NirV_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NirV_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped",group_cols = c("Croptype", "Fertilizer"),value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type ="grouped",group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds22007 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds21969 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# Only datasets with monthly resolution (exclude Fertilization & mosaic)
# Time period and months as in ds22007
# Only months April–September (4–9)

# Determine months and year range from ds22007
months_ds22007 <- sort(unique(ds22007$month))
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# Exclude non-monthly datasets
monthly_datasets <- data_list[!names(data_list) %in% c("Fertilization", "mosaic", "ds22007")]

# Function to filter by months (April–September)
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df) # if no month info
  df %>%
    filter(
      month %in% 4:9,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# Apply filter to monthly datasets for ds22007
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# Remove ds21969 if included by mistake
data_for_ds22007_monthly <- data_for_ds22007_monthly[!names(data_for_ds22007_monthly) %in% c("ds21969")]

# Re-add insect datasets
data_for_ds22007_monthly$ds22007 <- ds22007

data_for_ds22007_monthly$ds22007 <- group_by(data_for_ds22007_monthly$ds22007, Exploratory, month, year, Family) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")


###################### FILTER FOR MONTHLY ds22007 ###########################
# -------------------------------------------------------------------
# Function: filter monthly ds22007 datasets based on stationary variables
# -------------------------------------------------------------------
filter_ds22007_dataset_monthly <- function(df, dataset_name, overview_ds22007) {
  
  # Check whether the dataset is listed in the stationary overview
  if(!dataset_name %in% unique(overview_ds22007$dataset)) return(NULL)
  
  # Variables allowed for this dataset
  allowed_columns <- overview_ds22007 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly data include month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final set of columns to retain
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns (except year and month) by allowed values
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds22007 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>%
      unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>%
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI / NDWI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds22007 datasets
# -------------------------------------------------------------------
filtered_ds22007_monthly_list <- imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_dataset_monthly(df, name, ds22007_stationary)
  }
)

# Remove NULL entries
filtered_ds22007_monthly_list <- filtered_ds22007_monthly_list[
  !sapply(filtered_ds22007_monthly_list, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds22007_monthly_list$ds22007
# -------------------------------------------------------------------
names(filtered_ds22007_monthly_list)
str(filtered_ds22007_monthly_list, max.level = 1)

######################################################################
############## Build sub-lists of ds22007_monthly by region ###########
######################################################################

#################### ALB ##########################################
# 1. SMI
smi_total_alb <- filtered_ds22007_monthly_list$SMI_total %>%
  dplyr::select(month, year, ALB)
smi_upsoil_alb <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, ALB)

# 2. NDVI, NDWI, NirV
ndvi_alb <- filtered_ds22007_monthly_list$NDVI_ALB
ndwi_alb <- filtered_ds22007_monthly_list$NDWI_ALB
nirv_alb <- filtered_ds22007_monthly_list$NirV_ALB

# 4. Weather
weather_alb <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "ALB")

# 5. ds22007 for ALB
ds22007_alb <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "ALB")

# 6. Create sub-list
ds22007_monthly_ALB <- list(
  SMI_total = smi_total_alb,
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDWI = ndwi_alb,
  NirV = nirv_alb,
  weather = weather_alb,
  ds22007 = ds22007_alb
)

#################### HAI ##########################################
# 1. SMI_upsoil
smi_hai <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, HAI)

# 2. NDVI, NDWI, NirV
ndvi_hai <- filtered_ds22007_monthly_list$NDVI_HAI
ndwi_hai <- filtered_ds22007_monthly_list$NDWI_HAI
nirv_hai <- filtered_ds22007_monthly_list$NirV_HAI

# 3. Weather
weather_hai <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "HAI")

# 4. ds22007
ds22007_hai <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "HAI")

# 5. Create sub-list
ds22007_monthly_HAI <- list(
  SMI_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NDWI = ndwi_hai,
  NirV = nirv_hai,
  weather = weather_hai,
  ds22007 = ds22007_hai
)

#################### SCH ##########################################
# 1. SMI_upsoil
smi_sch <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, SCH)

# 2. NDVI, NDWI, NirV
ndvi_sch <- filtered_ds22007_monthly_list$NDVI_SCH
ndwi_sch <- filtered_ds22007_monthly_list$NDWI_SCH
nirv_sch <- filtered_ds22007_monthly_list$NirV_SCH

# 3. Weather
weather_sch <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "SCH")

# 4. ds22007
ds22007_sch <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "SCH")

# 5. Create sub-list
ds22007_monthly_SCH <- list(
  smi_upsoil = smi_sch,
  NDVI = ndvi_sch,
  NDWI = ndwi_sch,
  NirV = nirv_sch,
  weather = weather_sch,
  ds22007 = ds22007_sch
)

################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################
# - Only datasets with monthly resolution (excluding Fertilization & mosaic)
# - Time period and months identical to ds22007
# - Only months April–September (4–9)

library(dplyr)
library(purrr)

# ------------------------------------------------------------------------------
# 1️⃣ Determine time span and month range from ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2️⃣ Remove datasets without monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[
  !names(data_list) %in% c("Fertilization", "mosaic", "ds22007")
]

# ------------------------------------------------------------------------------
# 3️⃣ Filter function for monthly period (April–September)
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  
  # Return unchanged if no monthly information is available
  if (!all(c("year", "month") %in% names(df))) return(df)
  
  df %>%
    filter(
      month %in% 4:9,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4️⃣ Apply filter for ds22007 (monthly datasets only)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(
  monthly_datasets,
  function(df) {
    filter_monthly_period(df, years_ds22007)
  }
)

# ------------------------------------------------------------------------------
# 5️⃣ Remove ds21969, which is included erroneously
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- data_for_ds22007_monthly[
  !names(data_for_ds22007_monthly) %in% c("ds21969")
]

# ------------------------------------------------------------------------------
# 6️⃣ Re-add unmodified insect dataset
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007



###################### FILTER FOR MONTHLY ds22007 ###########################
# -------------------------------------------------------------------
# Function: filter monthly ds22007 datasets based on stationary variables
# -------------------------------------------------------------------
filter_ds22007_dataset_monthly <- function(df, dataset_name, overview_ds22007) {
  
  # Check whether the dataset is listed in the stationary overview
  if(!dataset_name %in% unique(overview_ds22007$dataset)) return(NULL)
  
  # Variables allowed for this dataset
  allowed_columns <- overview_ds22007 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final set of columns to retain
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns (except year and month) by allowed values
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    
    allowed_values <- overview_ds22007 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>%
      unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>%
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI / NDWI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>%
      dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds22007 datasets
# -------------------------------------------------------------------
filtered_ds22007_monthly_list <- imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_dataset_monthly(df, name, ds22007_stationary)
  }
)

# Remove NULL entries
filtered_ds22007_monthly_list <- filtered_ds22007_monthly_list[
  !sapply(filtered_ds22007_monthly_list, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds22007_monthly_list$ds22007
# -------------------------------------------------------------------
names(filtered_ds22007_monthly_list)
str(filtered_ds22007_monthly_list, max.level = 1)


#####################################################################################
######### GRANGER TEST DS22007 ######################################################
########################## ALB ######################################################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_ALB$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) { 
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_ALB$ds22007 %>% 
    dplyr::filter(Family == family_name) %>% 
    dplyr::group_by(year, month) %>% 
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_total
# -----------------------------
results_smi_total <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_ALB$SMI_total, "ALB")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_total", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_ALB$SMI_upsoil, "ALB")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 6. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_ALB$NDVI %>% dplyr::select(year, month, ALB = mean_NDVI),
  NDWI = ds22007_monthly_ALB$NDWI %>% dplyr::select(year, month, ALB = mean_NDWI),
  NirV = ds22007_monthly_ALB$NirV %>% dplyr::select(year, month, ALB = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "ALB",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_ALB$weather)[!(names(ds22007_monthly_ALB$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_ALB$weather %>% dplyr::select(year, month, ALB = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 8. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_ALB <- dplyr::bind_rows(results_smi_total, results_smi_upsoil, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 9. Review and save results
# -----------------------------
head(results_ds22007_monthly_ALB)
write.csv(results_ds22007_monthly_ALB, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds22007_monthly_ALB.csv", row.names = FALSE)


############################################################################
##################### HAI, lags 1-3 #######################################
######################### GRANGER TEST FOR DS22007 - HAI (MONTHLY, MULTIPLE LAGS) ##################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_HAI$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_HAI$ds22007 %>%
    dplyr::filter(Family == family_name) %>%
    dplyr::group_by(year, month) %>%
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_upsoil
# -----------------------------
results_smi <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_HAI$SMI_upsoil, "HAI")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "HAI",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_HAI$NDVI %>% dplyr::select(year, month, HAI = mean_NDVI),
  NDWI = ds22007_monthly_HAI$NDWI %>% dplyr::select(year, month, HAI = mean_NDWI),
  NirV = ds22007_monthly_HAI$NirV %>% dplyr::select(year, month, HAI = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "HAI",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 6. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_HAI$weather)[!(names(ds22007_monthly_HAI$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_HAI$weather %>% dplyr::select(year, month, HAI = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_HAI <- dplyr::bind_rows(results_smi, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 8. Review and save results
# -----------------------------
head(results_ds22007_monthly_HAI)
write.csv(results_ds22007_monthly_HAI, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds22007_monthly_HAI.csv", row.names = FALSE)

############################################################################
##################### SCH, lags 1-3 #######################################
######################### GRANGER TEST FOR DS22007 - SCH (MONTHLY, MULTIPLE LAGS) ##################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_SCH$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_SCH$ds22007 %>%
    dplyr::filter(Family == family_name) %>%
    dplyr::group_by(year, month) %>%
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_upsoil
# -----------------------------
results_smi <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_SCH$smi_upsoil, "SCH")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "SCH",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_SCH$NDVI %>% dplyr::select(year, month, SCH = mean_NDVI),
  NDWI = ds22007_monthly_SCH$NDWI %>% dplyr::select(year, month, SCH = mean_NDWI),
  NirV = ds22007_monthly_SCH$NirV %>% dplyr::select(year, month, SCH = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "SCH",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 6. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_SCH$weather)[!(names(ds22007_monthly_SCH$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_SCH$weather %>% dplyr::select(year, month, SCH = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_SCH <- dplyr::bind_rows(results_smi, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 8. Review and save results
# -----------------------------
head(results_ds22007_monthly_SCH)
write.csv(results_ds22007_monthly_SCH, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds22007_monthly_SCH.csv", row.names = FALSE)


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# Determine months and year range
ds21969 <- ds21969 %>%
  mutate(month_num = as.numeric(month))  # numeric column for filtering

years_ds21969  <- range(ds21969$year, na.rm = TRUE)

# ALB & HAI months
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
# SCH months
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

cat("Months ALB & HAI:", paste(months_ALB_HAI, collapse = ", "), "\n")
cat("Months SCH:", paste(months_SCH, collapse = ", "), "\n")
cat("Year range ds21969:", paste(years_ds21969, collapse = " - "), "\n")

# Select only monthly datasets (SMI, NDVI, NDWI, NirV, weather, crops)
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ALB_crop", "HAI_crop", "SCH_crop",
                                  "ds22007")]

# Function to filter by year and month
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# Apply filter for ALB & HAI
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[!names(data_for_ds21969_ALB_HAI) %in% c("ds22007")]

# Add ds21969 for ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>% filter(Exploratory %in% c("ALB","HAI"))

# Apply filter for SCH
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[!names(data_for_ds21969_SCH) %in% c("ds22007")]

# Add ds21969 for SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>% filter(Exploratory == "SCH")

str(data_for_ds21969_ALB_HAI)
str(ds21969_detrend_ALB_HAI_monthly)
str(data_for_ds21969_SCH)

# Result: Two lists ready for monthly analysis
# data_for_ds21969_ALB_HAI
# data_for_ds21969_SCH

######################################################################
############## build sub-lists of ds21969_monthly by region ##########
######################################################################

#################### ALB #############################################
# 1. SMI
smi_total_alb <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, ALB)
smi_upsoil_alb <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, ALB)

# 2. NDVI, NDWI, NirV
ndvi_alb <- filtered_ds21969_monthly_list$NDVI_ALB
ndwi_alb <- filtered_ds21969_monthly_list$NDWI_ALB
nirv_alb <- filtered_ds21969_monthly_list$NirV_ALB

# 3. Weather
weather_alb <- filtered_ds21969_monthly_list$weather %>% filter(region == "ALB")

# 4. ds21969 for ALB
ds21969_alb <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "ALB")

# 5. Create sub-list
ds21969_monthly_ALB <- list(
  SMI_total = smi_total_alb,
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDWI = ndwi_alb,
  NirV = nirv_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI #############################################
# 1. SMI
smi_total_hai <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, HAI)
smi_upsoil_hai <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, HAI)

# 2. NDVI, NDWI, NirV
ndvi_hai <- filtered_ds21969_monthly_list$NDVI_HAI
ndwi_hai <- filtered_ds21969_monthly_list$NDWI_HAI
nirv_hai <- filtered_ds21969_monthly_list$NirV_HAI

# 3. Weather
weather_hai <- filtered_ds21969_monthly_list$weather %>% filter(region == "HAI")

# 4. ds21969 for HAI
ds21969_hai <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "HAI")

# 5. Create sub-list
ds21969_monthly_HAI <- list(
  SMI_total = smi_total_hai,
  SMI_upsoil = smi_upsoil_hai,
  NDVI = ndvi_hai,
  NDWI = ndwi_hai,
  NirV = nirv_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH #############################################
# 1. SMI_upsoil
smi_sch <- filtered_ds21969_monthly_list_SCH$SMI_upsoil %>% dplyr::select(month, year, SCH)

# 2. NDVI, NDWI, NirV
ndvi_sch <- filtered_ds21969_monthly_list_SCH$NDVI_SCH
ndwi_sch <- filtered_ds21969_monthly_list_SCH$NDWI_SCH
nirv_sch <- filtered_ds21969_monthly_list_SCH$NirV_SCH

# 3. Weather
weather_sch <- filtered_ds21969_monthly_list_SCH$weather %>% filter(region == "SCH")

# 4. ds21969 for SCH
ds21969_sch <- filtered_ds21969_monthly_list_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 5. Create sub-list
ds21969_monthly_SCH <- list(
  SMI_upsoil = smi_sch, 
  NDVI = ndvi_sch,
  NDWI = ndwi_sch,
  NirV = nirv_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## ALB ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_ALB$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_ALB$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds21969_monthly_ALB$SMI_total, "ALB")
  map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_total", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds21969_monthly_ALB$SMI_upsoil, "ALB")
  map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 6. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds21969_monthly_ALB$NDVI %>% dplyr::select(year, month, ALB = mean_NDVI),
  NDWI = ds21969_monthly_ALB$NDWI %>% dplyr::select(year, month, ALB = mean_NDWI),
  NirV = ds21969_monthly_ALB$NirV %>% dplyr::select(year, month, ALB = mean_NIRv)
)

results_env <- map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "ALB",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_ALB$weather)[
  !(names(ds21969_monthly_ALB$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_ALB$weather %>% dplyr::select(year, month, ALB = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 8. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_ALB <- bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_env,
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 9. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_ALB)

write.csv(
  results_ds21969_monthly_ALB,
  "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_ALB.csv",
  row.names = FALSE
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## HAI ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_HAI$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_HAI$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds21969_monthly_HAI$SMI_total, "HAI")
  map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_total", EnvColumn = "HAI",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds21969_monthly_HAI$SMI_upsoil, "HAI")
  map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "HAI",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 6. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds21969_monthly_HAI$NDVI %>% dplyr::select(year, month, HAI = mean_NDVI),
  NDWI = ds21969_monthly_HAI$NDWI %>% dplyr::select(year, month, HAI = mean_NDWI),
  NirV = ds21969_monthly_HAI$NirV %>% dplyr::select(year, month, HAI = mean_NIRv)
)

results_env <- map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "HAI",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_HAI$weather)[
  !(names(ds21969_monthly_HAI$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_HAI$weather %>% dplyr::select(year, month, HAI = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 8. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_HAI <- bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_env,
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 9. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_HAI)

write.csv(
  results_ds21969_monthly_HAI,
  "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_HAI.csv",
  row.names = FALSE
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## SCH ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_SCH$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_SCH$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds21969_monthly_SCH$SMI_upsoil, "SCH")
  map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "SCH",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test NDVI, NDWI, NirV
# -----------------------------
env_list <- list(
  NDVI = ds21969_monthly_SCH$NDVI %>% dplyr::select(year, month, SCH = mean_NDVI),
  NDWI = ds21969_monthly_SCH$NDWI %>% dplyr::select(year, month, SCH = mean_NDWI),
  NirV = ds21969_monthly_SCH$NirV %>% dplyr::select(year, month, SCH = mean_NIRv)
)

results_env <- map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "SCH",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 6. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_SCH$weather)[
  !(names(ds21969_monthly_SCH$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_SCH$weather %>%
    dplyr::select(year, month, SCH = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_SCH <- bind_rows(
  results_smi_upsoil,
  results_env,
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 8. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_SCH)

write.csv(
  results_ds21969_monthly_SCH,
  "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_SCH.csv",
  row.names = FALSE
)



