####################### ds21969 YEARLY ##################################

########################## 2nd Round Granger ############################
# Performs Granger tests on detrended/differenced (stationary) data
# 1. Uses the lists created in the scripts
#    "detrending_251118" and "detrending_ds21969_monthly_261127"
# 2. Performs Granger tests on all stationary insect data aggregated together


################### load packages #######################################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests

#################### load data #########################################
# Load datasets and harmonize column names for "year" and "month"

# Soil moisture index (SMI)
SMI_total <- read.csv("D:/Masterarbeit/tables/smi_means_Gesamtboden.csv", sep=',', header=TRUE) %>%
  mutate(time = as.Date(time),
         day = day(time), month = month(time), year = year(time))

SMI_upsoil <- read.csv("D:/Masterarbeit/tables/smi_means_Oberboden.csv", sep=',', header=TRUE) %>%
  mutate(time = as.Date(time),
         day = day(time), month = month(time), year = year(time))

# Satellite indices
NDVI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_ALB_2007_2019.csv") %>%
  dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

NDWI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_ALB_2007_2019.csv") %>%
  dplyr::select(-`system:index`)
NDWI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NDWI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

NirV_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_ALB_2007_2019_norm.csv") %>%
  dplyr::select(-`system:index`)
NirV_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NirV_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv(
  "D:/Masterarbeit/environmental_data/Cropland_Maps/Cropland_Maps/cropland_means_by_region.csv",
  sep=';', header=TRUE
) %>% rename(year = Year)

# Mosaic data
mosaic <- read_csv("D:/Masterarbeit/tables/mosaic_zones_area_weighted_means_251001.csv")

# Weather data
weather <- read.csv("D:/Masterarbeit/environmental_data/bexis_climate_data_250818/plots.csv") %>%
  mutate(datetime = ym(datetime),
         year = year(datetime),
         month = month(datetime)) %>%
  mutate(region = case_when(
    str_starts(plotID, "A") ~ "ALB",
    str_starts(plotID, "H") ~ "HAI",
    str_starts(plotID, "S") ~ "SCH",
    TRUE ~ NA_character_
  ))

# Crop yield and area data
ALB_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_ALB_filled.csv")
HAI_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_HAI_filled.csv")
SCH_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_SCH_filled.csv")

# Insect dataset ds21969
ds21969 <- read_csv(
  "C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/21969_13_data.csv"
) %>%
  mutate(
    month_clean = str_trim(CollectionMonth),
    MonthNum = case_when(
      is.na(month_clean) ~ NA_character_,
      month_clean %in% month.abb ~ sprintf("%02d", match(month_clean, month.abb)),
      TRUE ~ NA_character_
    )
  ) %>%
  rename(year = CollectionYear,
         month = MonthNum)

# Helper function: decode months from CollectionRun
decode_collection_run <- function(run_letter) {
  # A = April (4), B = May (5), ..., G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])
}

################################################################################

# Load insect dataset ds22007
ds22007 <- read_csv(
  "C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/22007_11_data.csv"
) %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),
    month = decode_collection_run(run_letter),
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),
    year = as.numeric(CollectionYear)
  ) %>%
  dplyr::select(-run_letter)

##### Stationarity tables from first round (used to build lists) ########
# Combined ADF/KPSS results – yearly
stationarity_table_ds21969_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969.csv",
  sep = ";"
)

# Monthly stationarity tables
stationarity_table_ds21969_ALB_HAI_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv",
  sep = ","
)
stationarity_table_ds21969_SCH_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv",
  sep = ","
)

##### Combined stationarity tables with transformed data ################
# ds21969 – yearly
ds21969_both_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_both_yearly.csv",
  sep = ";"
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_detrended_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_detrended_yearly.csv",
  sep = ";"
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_diff_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

# ds21969 – monthly
ds21969_both_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_both_monthly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_detrended_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_detrended_monthly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_diff_monthly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

# ds22007 – yearly
ds22007_both_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_both_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds22007_detrended_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_detrended_yearly.csv",
  sep = ","
) %>% filter(ADF_status == "stationary", KPSS_status == "stationary", Family != "Fam.")

ds22007_differenced_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_diff_yearly.csv",
  sep = ","
) %>% filter(ADF_status == "stationary", KPSS_status == "stationary", Family != "Fam.")

# ds22007 – monthly
ds22007_both_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_both_monthly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_detrended_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_detrended_monthly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds22007_differenced_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds22007_diff_monthly.csv",
  sep = ","
) %>% filter(adf_status == "stationary", kpss_status == "stationary", Family != "Fam.")


############################## data list ################################
# Combine all datasets into a single list for easier handling
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDWI_ALB = NDWI_ALB,
  NDWI_HAI = NDWI_HAI,
  NDWI_SCH = NDWI_SCH,
  NirV_ALB = NirV_ALB,
  NirV_HAI = NirV_HAI,
  NirV_SCH = NirV_SCH,
  Fertilization = Fertilization,
  mosaic = mosaic,
  weather = weather,
  ALB_crop = ALB_crop,
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop,
  ds21969 = ds21969
)


####################### YEARLY AGGREGATION ################################
# Function to aggregate datasets to yearly resolution
aggregate_yearly <- function(df, dataset_name) {
  
  # Special handling for crop datasets
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(
          weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
          .groups = "drop"
        )
    )
  }
  
  # Define grouping structure and aggregation variables
  group_col <- NULL
  sum_cols <- c()
  
  if (dataset_name %in% c("ds21969")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  if (dataset_name == "weather") {
    group_col <- "region"
    sum_cols <- names(df)[3:39]
  }
  
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month", "day"))
  
  # Perform yearly aggregation
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################

# Prepare yearly aggregated data for ds21969 

# Define year ranges
years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# Aggregate all datasets yearly
data_yearly <- lapply(names(data_list), function(name) {
  aggregate_yearly(data_list[[name]], name)
})
names(data_yearly) <- names(data_list)

# Restrict datasets to respective year ranges
data_for_ds21969 <- lapply(
  data_yearly,
  function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2])
)

##################################################################
################## SELECT ONLY STATIONARY RESULTS #################
# Yearly stationary datasets
ds21969_stationary_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DETRENDING #################
# Yearly
ds21969_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

################## DETRENDING DS21969 #################################

# -------------------------------------------
# Function: safe filtering for detrending
# -------------------------------------------
filter_ds21969_detrend_safe <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is listed in the detrending table
  if(!dataset_name %in% unique(detrend_overview$dataset)) return(NULL)
  
  # Identify variables that need to be detrended
  value_cols <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns only if they exist in the data frame
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Filter by Family + Exploratory (allowed combinations only)
  allowed_combinations <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  df_filtered <- df %>% dplyr::select(any_of(c(existing_group_cols, value_cols)))
  
  if("Family" %in% names(df_filtered) & "Exploratory" %in% names(df_filtered)) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family", "Exploratory"))
  }
  
  # Optional: remove region column for selected datasets
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDWI_ALB","NDWI_HAI","NDWI_SCH",
                         "NirV_ALB","NirV_HAI","NirV_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------
# Function: linear detrending with suffix – FIX using unname()
# -------------------------------------------
detrend_ts_with_suffix <- function(df, value_cols, time_col = "year", suffix = "_detrended") {
  df_out <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      if(sum(!is.na(df[[col]])) > 1) {
        
        fit <- lm(df[[col]] ~ df[[time_col]])
        
        # Critical step: store residuals without names
        df_out[[paste0(col, suffix)]] <- unname(residuals(fit))
        
      } else {
        df_out[[paste0(col, suffix)]] <- NA
      }
    }
  }
  
  return(df_out)
}

# -------------------------------------------
# Filter and detrend the full dataset list
# -------------------------------------------
filtered_ds21969_detrended_safe <- imap(data_for_ds21969, function(df, name) {
  
  df_filtered <- filter_ds21969_detrend_safe(df, name, ds21969_detrend_yearly)
  
  if(is.null(df_filtered)) return(NULL)
  
  value_cols <- ds21969_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts_with_suffix(df_filtered, value_cols, time_col = "year", suffix = "_detrended")
})

# Remove NULL entries
filtered_ds21969_detrended_safe <- filtered_ds21969_detrended_safe[!sapply(filtered_ds21969_detrended_safe, is.null)]

# Test output
cat("Filtered and detrended datasets:\n")
print(names(filtered_ds21969_detrended_safe))



################## SELECT DATASETS REQUIRING DIFFERENCING #################
# Yearly
ds21969_differencing_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# DIFFERENCING

# -------------------------------------------------------------------
# Function: first differencing per time series
# -------------------------------------------------------------------
difference_ts <- function(df, value_cols, time_col = "year") {
  df_diff <- df
  for(col in value_cols) {
    if(col %in% names(df)) {
      # Apply differencing within the column
      df_diff[[col]] <- c(NA, diff(df[[col]]))
    }
  }
  return(df_diff)
}

# -------------------------------------------------------------------
# Function: safely filter ds21969 datasets and apply differencing
# -------------------------------------------------------------------
filter_ds21969_diff_safe <- function(df, dataset_name, diff_overview) {
  
  # Check whether dataset is listed in the overview table
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  # Extract variables that need to be differenced
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns if they exist
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only relevant columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only allowed Family + Exploratory combinations
  allowed_combinations <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Apply differencing to the selected variables
  df_diff <- difference_ts(df_filtered, allowed_columns, time_col = "year")
  
  return(df_diff)
}

# -------------------------------------------------------------------
# Apply filtering and differencing to the full ds21969 dataset list
# -------------------------------------------------------------------
filtered_ds21969_diffed_safe <- imap(data_for_ds21969, function(df, name) {
  filter_ds21969_diff_safe(df, name, ds21969_differencing_yearly)
})

# Remove NULL entries
filtered_ds21969_diffed_safe <- filtered_ds21969_diffed_safe[!sapply(filtered_ds21969_diffed_safe, is.null)]

# -----------------------------
# Test output
# -----------------------------
cat("Differenced datasets:\n")
print(names(filtered_ds21969_diffed_safe))

cat("\nExample: first rows of one dataset:\n")
print(head(filtered_ds21969_diffed_safe[[1]]))
str(filtered_ds21969_diffed_safe)


################## TAKE ONLY DATASETS WHICH NEED BOTH METHODS FROM TABLE #################
# Yearly
ds21969_diff_and_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_diff_and_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

# Monthly
ds21969_diff_and_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_diff_and_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_diff_and_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

######################### DS21969 #########################################

# -------------------------------------------------------------------
# Function: filter ds21969 datasets for detrending and differencing
# -------------------------------------------------------------------
filter_ds21969_diff_detrend_safe <- function(df, dataset_name, overview_table) {
  
  # Skip dataset if it is not listed in the overview table
  if(!dataset_name %in% unique(overview_table$dataset)) return(NULL)
  
  # Extract variables that require processing
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Automatically keep grouping columns if they exist
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Define columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter by allowed values from the overview table (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only valid Family–Exploratory combinations
  allowed_combinations <- overview_table %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family","Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>% 
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Remove region column for satellite-based datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Create filtered dataset list
# -------------------------------------------------------------------
filtered_ds21969_diff_detrend_safe <- imap(
  data_for_ds21969,
  function(df, name){
    filter_ds21969_diff_detrend_safe(df, name, ds21969_diff_and_detrend_yearly)
  }
)
filtered_ds21969_diff_detrend_safe <- 
  filtered_ds21969_diff_detrend_safe[!sapply(filtered_ds21969_diff_detrend_safe, is.null)]

# -------------------------------------------------------------------
# Function: detrending followed by differencing
# -------------------------------------------------------------------
detrend_then_diff_safe <- function(df, value_cols, time_col = "year") {
  
  df_out <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      
      # Linear detrending
      if(sum(!is.na(df[[col]])) > 1) {
        detrended <- unname(resid(lm(df[[col]] ~ df[[time_col]])))
      } else {
        detrended <- rep(NA, nrow(df))
      }
      
      # First differencing of detrended series
      df_out[[col]] <- c(NA, diff(unname(detrended)))
    }
  }
  
  return(df_out)
}

# -------------------------------------------------------------------
# Apply detrending and differencing to all filtered datasets
# -------------------------------------------------------------------
filtered_ds21969_diffed_detrended_safe <- imap(
  filtered_ds21969_diff_detrend_safe,
  function(df, name) {
    value_cols <- ds21969_diff_and_detrend_yearly %>%
      filter(dataset == name) %>%
      pull(variable)
    
    detrend_then_diff_safe(df, value_cols, time_col = "year")
  }
)

# -------------------------------------------------------------------
# Test output
# -------------------------------------------------------------------
cat("Differenced and detrended datasets:\n")
print(names(filtered_ds21969_diffed_detrended_safe))

cat("\nExample – first dataset:\n")
print(head(filtered_ds21969_diffed_detrended_safe[[1]]))

str(filtered_ds21969_diffed_detrended_safe$SMI_total)
str(filtered_ds21969_detrended_safe$SMI_total)


############ ALL DONE ##############################################################
# Build lists

# Determine per dataset how many new families need to be added to the family list

# data_for_ds21969 is the original list for the Granger causality analysis
# Columns from other dataset lists need to be added to these datasets
# How can this be done?

# Originally, Granger tests were performed on regionally separated lists, as in
# script "granger_causality_test_251111"

################# PREPARE FOR FURTHER FILTERING - ds21969 and ds22007 - YEARLY ######
###############################################

############ ds21969 #######################################################
# Take stationary results from pre-tests, keep only stationary time-series in the list

# ---------------------------------------------------------------
# Function: filter ds21969 datasets, keep only stationary series (robust)
# ---------------------------------------------------------------
filter_ds21969_stationary_safe <- function(df, dataset_name, overview_stationary) {
  
  # Skip if dataset not in overview table
  if(!dataset_name %in% unique(overview_stationary$dataset)) return(NULL)
  
  # Allowed variables according to overview
  allowed_columns <- overview_stationary %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns if present
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Combine all columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter rows: keep only allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")){
    allowed_values <- overview_stationary %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only stationary Family + Exploratory combinations
  allowed_combinations <- overview_stationary %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Remove region column for NDVI, NDWI, NirV datasets
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDWI_ALB","NDWI_HAI","NDWI_SCH",
                         "NirV_ALB","NirV_HAI","NirV_SCH")){
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# ---------------------------------------------------------------
# Apply filtering to the entire ds21969 list
# ---------------------------------------------------------------
filtered_ds21969_list_safe <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_stationary_safe(df, name, ds21969_stationary_yearly)
})
filtered_ds21969_list_safe <- filtered_ds21969_list_safe[!sapply(filtered_ds21969_list_safe, is.null)]

# Test output
cat("Filtered stationary ds21969 datasets:\n")
print(names(filtered_ds21969_list_safe))


###################### ds21969 #########################################
# Create sub-lists per region

# ---------------------------------------------------------------
# 1. SMI_upsoil for ALB
# ---------------------------------------------------------------
smi_alb <- filtered_ds21969_list_safe$SMI_upsoil %>% dplyr::select(year, ALB)

# ---------------------------------------------------------------
# 2. NDVI, NDWI, NirV for ALB
# ---------------------------------------------------------------
ndvi_alb <- filtered_ds21969_list_safe$NDVI_ALB
ndwi_alb <- filtered_ds21969_list_safe$NDWI_ALB
nirv_alb <- filtered_ds21969_list_safe$NirV_ALB

# ---------------------------------------------------------------
# 3. Fertilization for ALB
# ---------------------------------------------------------------
fert_alb <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, ALB)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for ALB
# ---------------------------------------------------------------
mosaic_alb <- filtered_ds21969_list_safe$mosaic %>% filter(region == "ALB")
weather_alb <- filtered_ds21969_list_safe$weather %>% filter(region == "ALB")

# ---------------------------------------------------------------
# 5. ds21969 for ALB
# ---------------------------------------------------------------
ds21969_alb <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "ALB")

# ---------------------------------------------------------------
# 6. Create sub-list for ALB
# ---------------------------------------------------------------
ds21969_stationary_ALB <- list(
  smi_upsoil = smi_alb,
  NDVI = ndvi_alb,
  NDWI = ndwi_alb,
  NirV = nirv_alb,
  Fertilization = fert_alb,
  mosaic = mosaic_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

# Optional: check
names(ds21969_stationary_ALB)
lapply(ds21969_stationary_ALB, names)

############ ds21969 - sort for HAI ###############################################

# ---------------------------------------------------------------
# 1. SMI_upsoil for HAI
# ---------------------------------------------------------------
smi_hai <- filtered_ds21969_list_safe$SMI_upsoil %>% dplyr::select(year, HAI)

# ---------------------------------------------------------------
# 2. Fertilization for HAI
# ---------------------------------------------------------------
fert_hai <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, HAI)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for HAI
# ---------------------------------------------------------------
mosaic_hai <- filtered_ds21969_list_safe$mosaic %>% filter(region == "HAI")
weather_hai <- filtered_ds21969_list_safe$weather %>% filter(region == "HAI")

# ---------------------------------------------------------------
# 4. ds21969 for HAI
# ---------------------------------------------------------------
ds21969_hai <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "HAI")

# ---------------------------------------------------------------
# 5. Create sub-list for HAI
# ---------------------------------------------------------------
ds21969_stationary_HAI <- list(
  SMI_upsoil = smi_hai,
  Fertilization = fert_hai,
  mosaic = mosaic_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

# Optional: check
names(ds21969_stationary_HAI)
lapply(ds21969_stationary_HAI, names)

############ ds21969 - sort for SCH ###############################################

# ---------------------------------------------------------------
# 1. NDVI, NDWI, NirV for SCH
# ---------------------------------------------------------------
ndvi_sch <- filtered_ds21969_list_safe$NDVI_SCH
ndwi_sch <- filtered_ds21969_list_safe$NDWI_SCH
nirv_sch <- filtered_ds21969_list_safe$NirV_SCH

# ---------------------------------------------------------------
# 2. Fertilization for SCH
# ---------------------------------------------------------------
fert_sch <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, SCH)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for SCH
# ---------------------------------------------------------------
mosaic_sch <- filtered_ds21969_list_safe$mosaic %>% filter(region == "SCH")
weather_sch <- filtered_ds21969_list_safe$weather %>% filter(region == "SCH")

# ---------------------------------------------------------------
# 4. ds21969 for SCH
# ---------------------------------------------------------------
ds21969_sch <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "SCH")

# ---------------------------------------------------------------
# 5. Create sub-list for SCH
# ---------------------------------------------------------------
ds21969_stationary_SCH <- list(
  Fertilization = fert_sch,
  mosaic = mosaic_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch,
  ndvi_sch = ndvi_sch,
  ndwi_sch = ndwi_sch,
  nirv_sch = nirv_sch
)

# Optional: check
names(ds21969_stationary_SCH)
lapply(ds21969_stationary_SCH, names)


########################### FILTER ds21969 2nd time #######################

str(ds21969_stationary_ALB) 

# Target list: ds21969_stationary_ALB
target <- ds21969_stationary_ALB


# ---------------------------------------------
# 1) HELPER FUNCTIONS
# ---------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new, drop_cols = NULL) {
  if (!is.null(drop_cols)) new <- dplyr::select(new, -all_of(drop_cols))
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}


# ---------------------------------------------
# 2) FILTERED_DS21969_DETRENDED
# ---------------------------------------------

src <- filtered_ds21969_detrended_safe

## SMI_total (drop SCH)
if ("SMI_total" %in% names(src)) {
  new_data <- src$SMI_total |> dplyr::select(-SCH_detrended, -SCH)
  target$SMI_total <- merge_columns_simple(target$SMI_total, new_data)
}

## Fertilization$ALB (grouped)
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |> 
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region == "ALB")
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "ALB")
  target$mosaic <- merge_grouped_unique(
    target$mosaic,
    new_mosaic,
    c("region")
  )
}

## weather (region == "ALB")
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "ALB")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}

## ALB_crop
if ("ALB_crop" %in% names(src)) {
  target$ALB_crop <- merge_grouped_unique(
    target$ALB_crop,
    src$ALB_crop,
    c("var", "measure", "year")
  )
}

## ds21969 (region == "ALB")
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "ALB")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}


# ---------------------------------------------
# 3) FILTERED_DS21969_DIFFED
# ---------------------------------------------

src <- filtered_ds21969_diffed_safe

## Fertilization$ALB
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |>
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "ALB")
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "ALB")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}


# ---------------------------------------------
# 4) FILTERED_DS21969_DIFFED_DETRENDED
# ---------------------------------------------

src <- filtered_ds21969_diffed_detrended_safe

## Fertilization$ALB
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |>
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "ALB")
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "ALB")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}


# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_ALB <- target


##########################################################################
ds21969_stationary_HAI

# Target list
target <- ds21969_stationary_HAI


# ---------------------------------------------------
# Helper functions
# ---------------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new) {
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}



# ===================================================
# 1) FILTERED_DS21969_DETRENDED
# ===================================================

src <- filtered_ds21969_detrended_safe

## NDVI_HAI
if ("NDVI_HAI" %in% names(src)) {
  target$NDVI_HAI <- merge_columns_simple(target$NDVI_HAI, src$NDVI_HAI)
}

## NDWI_HAI
if ("NDWI_HAI" %in% names(src)) {
  target$NDWI_HAI <- merge_columns_simple(target$NDWI_HAI, src$NDWI_HAI)
}

## NirV_HAI
if ("NirV_HAI" %in% names(src)) {
  target$NirV_HAI <- merge_columns_simple(target$NirV_HAI, src$NirV_HAI)
}

## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region = HAI)
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "HAI")
  target$mosaic <- merge_grouped_unique(
    target$mosaic,
    new_mosaic,
    c("region")
  )
}

## weather (region = HAI)
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "HAI")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}

## ds21969 (Exploratory = HAI)
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "HAI")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 2) FILTERED_DS21969_DIFFED
# ===================================================

src <- filtered_ds21969_diffed_safe


## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region = HAI)
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "HAI")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}

## ds21969 (Exploratory = "HAI")
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "HAI")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 3) FILTERED_DS21969_DIFFED_DETRENDED
# ===================================================

src <- filtered_ds21969_diffed_detrended_safe

## SMI_total
if ("SMI_total" %in% names(src)) {
  
  smi <- src$SMI_total %>%
    dplyr::rename(HAI_diff_detrended = HAI)   # <-- New standardized column name
  
  target$SMI_total <- merge_columns_simple(
    target$SMI_total,
    smi
  )
}

## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## HAI_crop
if ("HAI_crop" %in% names(src)) {
  target$HAI_crop <- merge_grouped_unique(
    target$HAI_crop,
    src$HAI_crop,
    c("var", "measure", "year")
  )
}



# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_HAI <- target

#####################################################################


# Target list
target <- ds21969_stationary_SCH

# ---------------------------------------------------
# Helper functions
# ---------------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new) {
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}



# ===================================================
# 1) FILTERED_DS21969_DETRENDED
# ===================================================

src <- filtered_ds21969_detrended_safe

## SMI_total (exclude ALB)
if ("SMI_total" %in% names(src)) {
  new_smi <- src$SMI_total |> dplyr::select(-ALB_detrended, -ALB)
  target$SMI_total <- merge_columns_simple(target$SMI_total, new_smi)
}

## SMI_upsoil
if ("SMI_upsoil" %in% names(src)) {
  target$SMI_upsoil <- merge_columns_simple(target$SMI_upsoil, src$SMI_upsoil)
}

## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region = SCH)
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "SCH")
  target$mosaic <- merge_grouped_unique(target$mosaic, new_mosaic, c("region"))
}

## weather (region = SCH)
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "SCH")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}

## SCH_crop
if ("SCH_crop" %in% names(src)) {
  target$SCH_crop <- merge_grouped_unique(
    target$SCH_crop,
    src$SCH_crop,
    c("var", "measure", "year")
  )
}

## ds21969 (Exploratory = SCH)
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "SCH")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 2) FILTERED_DS21969_DIFFED
# ===================================================

src <- filtered_ds21969_diffed_safe


## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region = SCH)
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "SCH")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}



# ===================================================
# 3) FILTERED_DS21969_DIFFED_DETRENDED
# ===================================================

src <- filtered_ds21969_diffed_detrended_safe


## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region = SCH)
if ("weather" %in% names(src)) {
  new_weather <- src$weather |> dplyr::filter(region == "SCH")
  target$weather <- merge_grouped_unique(
    target$weather,
    new_weather,
    c("region", "year")
  )
}



# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_SCH <- target



##########################################################################
### FILTER, MERGE & UPDATE DS21969 FOR ALB – FINAL VERSION  ###
##########################################################################

target <- ds21969_stationary_ALB      # Target object
# Note: target is a list containing: SMI_total, Fertilization, mosaic, weather, ALB_crop, ds21969


# =============================================================
# 1) HELPER FUNCTIONS
# =============================================================

## Merge by groups (sorted by year)
merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new) |> dplyr::distinct()
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

## Simple merge (optionally drop columns)
merge_columns_simple <- function(old, new, drop_cols = NULL) {
  if (!is.null(drop_cols)) new <- dplyr::select(new, -all_of(drop_cols))
  dplyr::bind_rows(old, new) |> dplyr::distinct()
} 


# =============================================================
# 2) HELPER: Generic function to extract ALB rows
# =============================================================

extract_ALB <- function(df) {
  region_cols <- intersect(names(df), c("region", "Exploratory"))
  if ("region" %in% region_cols)     return(df |> dplyr::filter(region == "ALB"))
  if ("Exploratory" %in% region_cols) return(df |> dplyr::filter(Exploratory == "ALB"))
  return(df)   # if no region column exists → keep all
}

# =============================================================
# 3) REFERENCE TABLES: Names of your source lists
# =============================================================

list_detrend   <- filtered_ds21969_detrended_safe
list_diff      <- filtered_ds21969_diffed_safe
list_both      <- filtered_ds21969_diffed_detrended_safe


# =============================================================
# 4) MASTER FUNCTION to insert new data into target
# =============================================================

update_target_with_list <- function(target, src) {
  
  # ---------------------------- SMI_total ----------------------------
  if ("SMI_total" %in% names(src)) {
    new_data <- src$SMI_total
    drop_cols <- setdiff(names(new_data), c("year", "ALB"))
    target$SMI_total <- merge_columns_simple(target$SMI_total, new_data, drop_cols=drop_cols)
  }
  
  # ---------------------------- Fertilization ----------------------------
  if ("Fertilization" %in% names(src)) {
    new_fert <- extract_ALB(src$Fertilization)
    new_fert <- new_fert |> dplyr::select(any_of(c("Croptype","Fertilizer","year","ALB")))
    target$Fertilization <- merge_grouped_unique(
      target$Fertilization,
      new_fert,
      c("Croptype","Fertilizer","year")
    )
  }
  
  # ---------------------------- mosaic ----------------------------
  if ("mosaic" %in% names(src)) {
    new_mosaic <- extract_ALB(src$mosaic)
    target$mosaic <- merge_grouped_unique(
      target$mosaic,
      new_mosaic,
      c("region")
    )
  }
  
  # ---------------------------- weather ----------------------------
  if ("weather" %in% names(src)) {
    new_weather <- extract_ALB(src$weather)
    target$weather <- merge_grouped_unique(
      target$weather,
      new_weather,
      c("region","year")
    )
  }
  
  # ---------------------------- ALB_crop ----------------------------
  if ("ALB_crop" %in% names(src)) {
    new_crop <- src$ALB_crop
    target$ALB_crop <- merge_grouped_unique(
      target$ALB_crop,
      new_crop,
      c("var","measure","year")
    )
  }
  
  # ---------------------------- ds21969 (Insects) ----------------------------
  if ("ds21969" %in% names(src)) {
    new_insects <- extract_ALB(src$ds21969)
    target$ds21969 <- merge_grouped_unique(
      target$ds21969,
      new_insects,
      c("Exploratory","Family","year")
    )
  }
  
  return(target)
}



# =============================================================
# 5) APPLY TO ALL 3 SOURCE LISTS
# =============================================================

target <- update_target_with_list(target, list_detrend)
target <- update_target_with_list(target, list_diff)
target <- update_target_with_list(target, list_both)


# =============================================================
# 6) FINAL OUTPUT
# =============================================================

updated_ds21969_stationary_ALB <- target


################## GRANGER ANALYSIS ######################
################ DS21969_ALB_YEARLY ######################

# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_ALB$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_ALB$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_ALB$smi_upsoil, "ALB")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_upsoil",
           EnvColumn = "ALB",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_ALB$SMI_total, "ALB")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "ALB",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDWI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_ALB$NDVI, "NDVI", "mean_NDVI")
results_ndwi <- run_granger_env_vars(updated_ds21969_stationary_ALB$NDWI, "NDWI", "mean_NDWI")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_ALB$NirV, "NirV", "mean_NIRv")

# -----------------------------
# 3. Fertilization (ALB)
# -----------------------------
fert_data <- updated_ds21969_stationary_ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, ALB_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "ALB") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_ALB$mosaic,
  weather = updated_ds21969_stationary_ALB$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 5. ALB_crop
# -----------------------------
alb_crop <- updated_ds21969_stationary_ALB$ALB_crop

results_crop <- map_dfr(unique(alb_crop$var), function(varname) {
  map_dfr(unique(alb_crop$measure), function(measurename) {
    subset_data <- alb_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "ALB_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_ALB <- bind_rows(
  results_smi_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_ALB

results_ALB$causality <- with(results_ALB,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_ALB, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_ALB_2nd_round.csv", row.names = FALSE)


################## GRANGER ANALYSIS ######################
################ DS21969_HAI_YEARLY ######################

# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_HAI$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_HAI$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_SMI_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_HAI$SMI_upsoil, "HAI")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_upsoil",
           EnvColumn = "HAI",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_HAI$SMI_total, "HAI_diff_detrended")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "HAI_diff_detrended",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDWI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_HAI$NDVI, "NDVI", "mean_NDVI")
results_ndwi <- run_granger_env_vars(updated_ds21969_stationary_HAI$NDWI, "NDWI", "mean_NDWI")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_HAI$NirV, "NirV", "mean_NIRv")

# -----------------------------
# 3. Fertilization (HAI)
# -----------------------------
fert_data <- updated_ds21969_stationary_HAI$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(HAI_list = list(HAI), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, HAI_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "HAI") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_HAI$mosaic,
  weather = updated_ds21969_stationary_HAI$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 5. HAI_crop
# -----------------------------
hai_crop <- updated_ds21969_stationary_HAI$HAI_crop

results_crop <- map_dfr(unique(hai_crop$var), function(varname) {
  map_dfr(unique(hai_crop$measure), function(measurename) {
    subset_data <- hai_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "HAI_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_HAI <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_HAI

results_HAI$causality <- with(results_HAI,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_HAI, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_HAI_2nd_round.csv", row.names = FALSE)


########################### SCH ##################################
################## GRANGER ANALYSIS ############################
# confirmed working

# -----------------------------
# 1. List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_SCH$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_SCH$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# 3. Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 5. SMI
# -----------------------------
results_SMI_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_SCH$SMI_upsoil, "SCH")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_upsoil",
           EnvColumn = "SCH",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_SCH$SMI_total, "SCH")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "SCH",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 6. NDVI / NDWI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_SCH$ndvi_sch, "ndvi", "mean_NDVI")
results_ndwi <- run_granger_env_vars(updated_ds21969_stationary_SCH$ndwi_sch, "ndwi", "mean_NDWI")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_SCH$nirv, "nirv", "mean_NIRv")

# -----------------------------
# 7. Fertilization (SCH)
# -----------------------------
fert_data <- updated_ds21969_stationary_SCH$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(SCH_list = list(SCH), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, SCH_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "SCH") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 8. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_SCH$mosaic,
  weather = updated_ds21969_stationary_SCH$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 9. SCH_crop
# -----------------------------
sch_crop <- updated_ds21969_stationary_SCH$SCH_crop

results_crop <- map_dfr(unique(sch_crop$var), function(varname) {
  map_dfr(unique(sch_crop$measure), function(measurename) {
    subset_data <- sch_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "SCH_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 10. Combine all results & label causality
# -----------------------------
results_SCH <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_SCH

results_SCH$causality <- with(results_SCH,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_SCH, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_SCH_2nd_round.csv", row.names = FALSE)






#18.01.2026: From here on, it most probably can be removed
table(results_ALB$causality)




################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDWI_ALB = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_HAI = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_SCH = list(type = "columns", cols = c("mean_NDWI")),
  NirV_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NirV_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NirV_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped",group_cols = c("Croptype", "Fertilizer"),value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type ="grouped",group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds22007 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds21969 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

# ------------------------------------------------------------------------------
# 1. Determine months and year range
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>%
  mutate(month_num = as.numeric(month))  # numeric column for filtering

years_ds21969  <- range(ds21969$year, na.rm = TRUE)

# Months for ALB & HAI
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
# Months for SCH
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

cat("ALB & HAI months:", paste(months_ALB_HAI, collapse = ", "), "\n")
cat("SCH months:", paste(months_SCH, collapse = ", "), "\n")
cat("ds21969 years:", paste(years_ds21969, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2. Select all monthly datasets (SMI, NDVI, NDWI, NirV, weather, crops)
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ALB_crop", "HAI_crop", "SCH_crop",
                                  "ds22007")]

# ------------------------------------------------------------------------------
# 3. Function to filter by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4. ALB & HAI: Apply filter
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets (only ds21969 added separately)
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[!names(data_for_ds21969_ALB_HAI) %in% c("ds22007")]

# Add ds21969 ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>% filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# 5. SCH: Apply filter
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[!names(data_for_ds21969_SCH) %in% c("ds22007")]

# Add ds21969 SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>% filter(Exploratory == "SCH")

################## FILTERING FOR DETRENDING ####################################
################## Select only datasets requiring detrending ###################

# monthly
ds21969_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds21969_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

################# Filter and sort by region ####################################
ALB_detrend_subset <- subset(ds21969_detrend_ALB_HAI_monthly, Exploratory == "ALB")
HAI_detrend_subset <- subset(ds21969_detrend_ALB_HAI_monthly, Exploratory == "HAI")

Family_ALB <- unique(ALB_detrend_subset$Family)
Family_HAI <- unique(HAI_detrend_subset$Family)
Family_SCH <- unique(ds21969_detrend_SCH_monthly$Family)

detrending_ALB <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "ALB", Family %in% Family_ALB)  
str(detrending_ALB)

detrending_HAI <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "HAI", Family %in% Family_HAI)
str(detrending_HAI)

detrending_SCH <- data_for_ds21969_SCH$ds21969 %>%
  filter(Family %in% Family_SCH)
str(detrending_SCH)

################# DETRENDING ###################################################

# ==========================================
# 2. Detrending function
# ==========================================
detrend_number_adults <- function(df) {
  df %>%
    group_by(Family) %>%
    mutate(NumberAdults_detrended = NumberAdults - mean(NumberAdults, na.rm = TRUE)) %>%
    ungroup()
}

# Apply detrending
detrending_ALB_detr <- detrend_number_adults(detrending_ALB)
detrending_HAI_detr <- detrend_number_adults(detrending_HAI)
detrending_SCH_detr <- detrend_number_adults(detrending_SCH)

#############################################################
################## Select datasets requiring differencing #######################

ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

################# Filter and sort by region ####################################
# ALB
ALB_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "ALB" | region == "ALB")

unique(ALB_diff$dataset)

weather_ALB_diff <- ALB_diff %>%
  filter(dataset == "weather") 
weather_ALB_diff <- unique(weather_ALB_diff$variable)

str(data_for_ds21969_ALB_HAI$weather)

Family_ALB_diff <- unique(ALB_diff$Family)
Family_ALB_diff <- Family_ALB_diff[!is.na(Family_ALB_diff)]

# HAI
HAI_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "HAI" | region == "HAI")

unique(HAI_diff$dataset)
weather_HAI_diff <- HAI_diff %>%
  filter(dataset == "weather") 
weather_HAI_diff <- unique(weather_HAI_diff$variable)

Family_HAI_diff <- unique(HAI_diff$Family)
Family_HAI_diff <- Family_HAI_diff[!is.na(Family_HAI_diff)]

# SCH
SCH_diff <- ds21969_differencing_SCH_monthly %>% 
  filter(Exploratory == "SCH" | region == "SCH")

unique(SCH_diff$dataset)

weather_SCH_diff <- SCH_diff %>%
  filter(dataset == "weather") 
weather_SCH_diff <- unique(weather_SCH_diff$variable)

Family_SCH_diff <- unique(SCH_diff$Family)
Family_SCH_diff <- Family_SCH_diff[!is.na(Family_SCH_diff)]

##### Combine Family and weather datasets for each region in a list #####
# ALB
differencing_Family_ALB <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "ALB", Family %in% Family_ALB_diff) 

differencing_weather_ALB <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_ALB_diff))

# list
differencing_list_ALB <- list(
  insect = differencing_Family_ALB,
  weather = differencing_weather_ALB
)

str(differencing_list_ALB, max.level = 2)

# HAI 
differencing_Family_HAI <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "HAI", Family %in% Family_HAI_diff) 

differencing_weather_HAI <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_HAI_diff))

# list
differencing_list_HAI <- list(
  insect = differencing_Family_HAI,
  weather = differencing_weather_HAI
)

str(differencing_list_HAI, max.level = 2)

# SCH 
differencing_Family_SCH <- data_for_ds21969_SCH$ds21969 %>%
  filter(Exploratory == "SCH", Family %in% Family_HAI_diff) 

differencing_weather_SCH <- data_for_ds21969_SCH$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_SCH_diff))

# list
differencing_list_SCH <- list(
  insect = differencing_Family_SCH,
  weather = differencing_weather_SCH
)

str(differencing_list_SCH, max.level = 2)

###########################
### DIFFERENCING FOR DS21969 (REGIONAL)
###########################

# ==========================================
# 1. Differencing function
# ==========================================
difference_df <- function(df, exclude_cols = c("TrapID","Exploratory","PlotID","CollectionMonth","year","month","month_num")) {
  num_cols <- names(df)[sapply(df, is.numeric) & !(names(df) %in% exclude_cols)]
  df_diff <- df
  df_diff[num_cols] <- lapply(df[num_cols], function(x) c(NA, diff(x)))
  return(df_diff)
}

# ==========================================
# 2. Prepare region list (like diff_lists)
# ==========================================
diff_lists <- list(
  ALB = differencing_list_ALB,
  HAI = differencing_list_HAI,
  SCH = differencing_list_SCH
)

# ==========================================
# 3. Apply differencing & store per region
# ==========================================
diffed_datasets <- list()   # store differenced data per region

for(region in names(diff_lists)) {
  cat("Processing region:", region, "\n")
  
  df_list <- diff_lists[[region]]
  
  # Apply differencing
  insect_diff  <- difference_df(df_list$insect)
  weather_diff <- difference_df(df_list$weather)
  
  # store list for this region
  diffed_datasets[[region]] <- list(
    insect  = insect_diff,
    weather = weather_diff
  )
}

# ==========================================
# 4. Test output
# ==========================================
cat("Differenced datasets per region:\n")
str(diffed_datasets, max.level = 2)

ds21969_both_SCH <- data_for_ds21969_SCH$SMI_total %>%
  dplyr::select(1, 4:7)

head(ds21969_both_SCH) 


################## SELECT DATASETS REQUIRING BOTH DETRENDING AND DIFFERENCING ###########

ds21969_both_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_both_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")


# 1. Detrending (linear model)
ds21969_both_SCH <- ds21969_both_SCH %>%
  arrange(time)

# Fit linear model over time
lm_model <- lm(SCH ~ as.numeric(time), data = ds21969_both_SCH)

# Residuals as detrended time series
ds21969_both_SCH$SCH_detrended <- resid(lm_model)

# 2. Differencing (if needed)
ds21969_both_SCH$SCH_diffed_detrended <- c(NA, diff(ds21969_both_SCH$SCH_detrended))

################################################################################
################## DS21969 ######################################################
################### ADF TEST - MONTHLY DATA ####################################

# ------------------------------------------------------------------------------
# 1 Safe ADF test function
# ------------------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  res <- tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  return(res)
}

# ------------------------------------------------------------------------------
# ️2 Run ADF test on monthly datasets
# ------------------------------------------------------------------------------
run_adf_tests_monthly <- function(data_list, configs) {
  results <- list()
  
  for (ds_name in names(data_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- data_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    if (is.null(cfg)) {
      cat("No config found for", ds_name, "- skipped.\n")
      next
    }
    
    # Skip *_crop datasets if not monthly relevant
    if (grepl("_crop", ds_name) & ds_name != "ds21969") next
    
    # --- Grouped datasets ---
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_adf_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        # No grouping columns
        for (v in vcols) {
          res <- safe_adf_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
    
    # --- Columns-only datasets ---
    if (cfg$type == "columns") {
      cols <- cfg$cols[cfg$cols %in% names(df)]
      for (col in cols) {
        res <- safe_adf_test(df[[col]])
        results[[length(results)+1]] <- cbind(
          dataset = ds_name,
          variable = col,
          res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

# ------------------------------------------------------------------------------
# 3 Run ADF on monthly datasets prepared for ds21969 ALB/HAI and SCH
# ------------------------------------------------------------------------------
res_adf_ds21969_ALB_HAI  <- run_adf_tests_monthly(data_for_ds21969_ALB_HAI, configs)
res_adf_ds21969_SCH      <- run_adf_tests_monthly(data_for_ds21969_SCH, configs)

# ------------------------------------------------------------------------------
# 4 Export results
# ------------------------------------------------------------------------------
write.csv(res_adf_ds21969_ALB_HAI,
          "D:/Masterarbeit/tables/final_tables/stationarity_test/adf_test_ds21969_ALB_HAI_monthly.csv",
          row.names = FALSE)

write.csv(res_adf_ds21969_SCH,
          "D:/Masterarbeit/tables/final_tables/stationarity_test/adf_test_ds21969_SCH_monthly.csv",
          row.names = FALSE)

cat("ADF tests for ds21969 monthly datasets completed.\n")



################### KPSS TEST - MONTHLY DATA ######################################

# ------------------------------------------------------------------------------
# Safe KPSS test function
# ------------------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")  # test for level stationarity
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  return(res)
}

# ------------------------------------------------------------------------------
# Run KPSS test on monthly datasets
# ------------------------------------------------------------------------------
run_kpss_tests_monthly <- function(data_list, configs) {
  results <- list()
  
  for (ds_name in names(data_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- data_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    if (is.null(cfg)) {
      cat("No config found for", ds_name, "- skipped.\n")
      next
    }
    
    # Skip *_crop datasets if not monthly relevant
    if (grepl("_crop", ds_name) & ds_name != "ds21969") next
    
    # --- Grouped datasets ---
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_kpss_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        # No grouping columns
        for (v in vcols) {
          res <- safe_kpss_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
    
    # --- Columns-only datasets ---
    if (cfg$type == "columns") {
      cols <- cfg$cols[cfg$cols %in% names(df)]
      for (col in cols) {
        res <- safe_kpss_test(df[[col]])
        results[[length(results)+1]] <- cbind(
          dataset = ds_name,
          variable = col,
          res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

# ------------------------------------------------------------------------------
# Run KPSS test on monthly datasets prepared for ds21969
# ------------------------------------------------------------------------------
res_kpss_ds21969_ALB_HAI <- run_kpss_tests_monthly(data_for_ds21969_ALB_HAI, configs)
res_kpss_ds21969_SCH     <- run_kpss_tests_monthly(data_for_ds21969_SCH, configs)

# ------------------------------------------------------------------------------
# Export results
# ------------------------------------------------------------------------------
write.csv(res_kpss_ds21969_ALB_HAI,
          "D:/Masterarbeit/tables/final_tables/stationarity_test/kpss_test_ds21969_ALB_HAI_monthly.csv",
          row.names = FALSE)

write.csv(res_kpss_ds21969_SCH,
          "D:/Masterarbeit/tables/final_tables/stationarity_test/kpss_test_ds21969_SCH_monthly.csv",
          row.names = FALSE)

cat("KPSS tests for ds21969 monthly datasets completed.\n")


######################################################################
# Combine monthly ADF & KPSS results for ds21969 + add recommended action
######################################################################

# Function reused from yearly version
combine_stationarity_results <- function(res_adf, res_kpss, file_out) {
  
  # Automatically determine common join keys
  join_keys <- intersect(names(res_adf), names(res_kpss))
  join_keys <- join_keys[!join_keys %in% c("statistic", "p_value", "status")]  # exclude test columns
  
  # Merge ADF and KPSS results
  combined <- full_join(
    res_adf %>% rename(
      statistic_adf = statistic,
      p_value_adf = p_value,
      status_adf = status
    ),
    res_kpss %>% rename(
      statistic_kpss = statistic,
      p_value_kpss = p_value,
      status_kpss = status
    ),
    by = join_keys
  )
  
  # Add recommended transformation based on stationarity tests
  combined <- combined %>%
    mutate(
      recommended_action = case_when(
        status_adf == "stationary" & status_kpss == "non-stationary" ~
          "Apply differencing to time series and check for stationarity again (difference stationary)",
        status_adf == "non-stationary" & status_kpss == "stationary" ~
          "Detrend time series and check for stationarity again (trend stationary)",
        status_adf == "stationary" & status_kpss == "stationary" ~
          "No transformation required (stationary)",
        status_adf == "non-stationary" & status_kpss == "non-stationary" ~
          "Detrend and then difference the time series and recheck for stationarity (both trends present)",
        TRUE ~ "Indeterminate, check data or increase time series length"
      )
    )
  
  # Export combined table
  write.csv(combined, file_out, row.names = FALSE)
  
  message("Combined stationarity file saved to: ", file_out)
  return(combined)
}

############################################################
# Apply function to monthly ds21969 ALB/HAI
############################################################
combined_ds21969_ALB_HAI <- combine_stationarity_results(
  res_adf_ds21969_ALB_HAI,
  res_kpss_ds21969_ALB_HAI,
  "D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv"
)

############################################################
# Apply function to monthly ds21969 SCH
############################################################
combined_ds21969_SCH <- combine_stationarity_results(
  res_adf_ds21969_SCH,
  res_kpss_ds21969_SCH,
  "D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv"
)

############################################################
# Preview combined outputs
############################################################
head(combined_ds21969_ALB_HAI)
head(combined_ds21969_SCH)

################## Take only fully stationary results #################
ds21969_ALB_HAI_stationary <- combined_ds21969_ALB_HAI %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_SCH_stationary <- combined_ds21969_SCH %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

###################### Filter monthly ds21969 datasets ###################

# -------------------------------------------------------------------
# Function: filter monthly ds21969 datasets based on stationary variables
# -------------------------------------------------------------------
filter_ds21969_dataset_monthly <- function(df, dataset_name, overview_ds21969) {
  
  # Check if dataset appears in stationary overview
  if(!dataset_name %in% unique(overview_ds21969$dataset)) return(NULL)
  
  # Allowed variables for this dataset
  allowed_columns <- overview_ds21969 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns except year & month
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds21969 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI / NDWI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_monthly_ALB_HAI_list <- imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_ALB_HAI_stationary)
  }
)

filtered_ds21969_monthly_list_SCH <- imap(
  data_for_ds21969_SCH,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_SCH_stationary)
  }
)

# Remove NULL entries
filtered_ds21969_monthly_list <- filtered_ds21969_monthly_ALB_HAI_list[
  !sapply(filtered_ds21969_monthly_ALB_HAI_list, is.null)
]

filtered_ds21969_monthly_list_SCH <- filtered_ds21969_monthly_list_SCH[
  !sapply(filtered_ds21969_monthly_list_SCH, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds21969_monthly_list$ds21969_ALB_HAI
# filtered_ds21969_monthly_list_SCH$ds21969_SCH
# -------------------------------------------------------------------

names(filtered_ds21969_monthly_list)
names(filtered_ds21969_monthly_list_SCH)
str(filtered_ds21969_monthly_ALB_HAI_list, max.level = 1)
str(filtered_ds21969_monthly_list_SCH, max.level = 1)


######################################################################
############## build sub-lists of ds21969_monthly per region #########
######################################################################

#################### ALB #############################################
# 1. SMI 
smi_total_alb <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, ALB)
smi_upsoil_alb <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, ALB)

# 2. NDVI, NDWI, NirV
ndvi_alb <- filtered_ds21969_monthly_list$NDVI_ALB
ndwi_alb <- filtered_ds21969_monthly_list$NDWI_ALB
nirv_alb <- filtered_ds21969_monthly_list$NirV_ALB

# 3. Weather
weather_alb <- filtered_ds21969_monthly_list$weather %>% filter(region == "ALB")

# 4. ds21969 for ALB
ds21969_alb <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "ALB")

# 5. Build sub-list
ds21969_monthly_ALB <- list(
  SMI_total = smi_total_alb,
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDWI = ndwi_alb,
  NirV = nirv_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI ##########################################
# 1. SMI
smi_total_hai <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, HAI)
smi_upsoil_hai <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, HAI)

# 2. NDVI, NDWI, NirV
ndvi_hai <- filtered_ds21969_monthly_list$NDVI_HAI
ndwi_hai <- filtered_ds21969_monthly_list$NDWI_HAI
nirv_hai <- filtered_ds21969_monthly_list$NirV_HAI

# 3. Weather
weather_hai <- filtered_ds21969_monthly_list$weather %>% filter(region == "HAI")

# 4. ds21969 for HAI
ds21969_hai <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "HAI")

# 5. Build sub-list
ds21969_monthly_HAI <- list(
  SMI_total = smi_total_hai,
  SMI_upsoil = smi_upsoil_hai,
  NDVI = ndvi_hai,
  NDWI = ndwi_hai,
  NirV = nirv_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH ##########################################
# 1. SMI_upsoil
smi_sch <- filtered_ds21969_monthly_list_SCH$SMI_upsoil %>% dplyr::select(month, year, SCH)

# 2. NDVI, NDWI, NirV
ndvi_sch <- filtered_ds21969_monthly_list_SCH$NDVI_SCH
ndwi_sch <- filtered_ds21969_monthly_list_SCH$NDWI_SCH
nirv_sch <- filtered_ds21969_monthly_list_SCH$NirV_SCH

# 3. Weather
weather_sch <- filtered_ds21969_monthly_list_SCH$weather %>% filter(region == "SCH")

# 4. ds21969 for SCH
ds21969_sch <- filtered_ds21969_monthly_list_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 5. Build sub-list
ds21969_monthly_SCH <- list(
  SMI_upsoil = smi_sch, 
  NDVI = ndvi_sch,
  NDWI = ndwi_sch,
  NirV = nirv_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch
)

#####################################################################

# -------------------------------
# ALB Updated Dataset
# -------------------------------

# 1. Start from original list
ds21969_monthly_ALB_updated <- ds21969_monthly_ALB

# 2. Prepare new rows from detrended ALB data
new_rows_ALB <- detrending_ALB_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# 3. Prepare existing rows
existing_ALB <- ds21969_monthly_ALB_updated$ds21969 %>%
  mutate(month = as.character(month))

# 4. Only add rows that do not exist yet
rows_to_add_ALB <- anti_join(new_rows_ALB, existing_ALB, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# 5. Combine
ds21969_monthly_ALB_updated$ds21969 <- bind_rows(existing_ALB, rows_to_add_ALB) %>%
  arrange(year, month, Exploratory, Family)

# -------------------------------
# Add insect data from diffed datasets
# -------------------------------

# Old insect data
old_insect_ALB <- ds21969_monthly_ALB_updated$ds21969 %>%
  mutate(month = as.character(month))

# New insect data from diffed_datasets
new_insect_ALB <- diffed_datasets$ALB$insect %>%
  mutate(month = as.character(month))

# Merge: keep all rows, do not remove duplicates
ds21969_monthly_ALB_updated$ds21969 <- bind_rows(old_insect_ALB, new_insect_ALB) %>%
  arrange(Exploratory, year, Family, month)

# -------------------------------
# Add weather data
# -------------------------------

# Old weather data
old_weather_ALB <- ds21969_monthly_ALB_updated$weather %>%
  mutate(month = as.character(month))

# New weather data
new_weather_ALB <- diffed_datasets$ALB$weather %>%
  mutate(month = as.character(month))

# Merge: keep all rows
ds21969_monthly_ALB_updated$weather <- bind_rows(old_weather_ALB, new_weather_ALB) %>%
  arrange(plotID, year, month)

# -------------------------------
# Check
# -------------------------------
cat("Rows ds21969:", nrow(ds21969_monthly_ALB_updated$ds21969), "\n")
cat("Rows weather:", nrow(ds21969_monthly_ALB_updated$weather), "\n")


# -------------------------------
# HAI Updated Dataset
# -------------------------------

ds21969_monthly_HAI_updated <- ds21969_monthly_HAI

# Prepare new rows from detrended HAI data
new_rows_HAI <- detrending_HAI_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# Prepare existing rows
existing_HAI <- ds21969_monthly_HAI_updated$ds21969 %>%
  mutate(month = as.character(month))

# Only add rows that do not exist yet
rows_to_add_HAI <- anti_join(new_rows_HAI, existing_HAI, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# Merge
ds21969_monthly_HAI_updated$ds21969 <- bind_rows(existing_HAI, rows_to_add_HAI) %>%
  arrange(year, month, Exploratory, Family)

# Add insect data from diffed datasets
old_insect_HAI <- ds21969_monthly_HAI_updated$ds21969 %>%
  mutate(month = as.character(month))

new_insect_HAI <- diffed_datasets$HAI$insect %>%
  mutate(month = as.character(month))

ds21969_monthly_HAI_updated$ds21969 <- bind_rows(old_insect_HAI, new_insect_HAI) %>%
  arrange(Exploratory, year, Family, month)

# Add weather data
old_weather_HAI <- ds21969_monthly_HAI_updated$weather %>%
  mutate(month = as.character(month))

new_weather_HAI <- diffed_datasets$HAI$weather %>%
  mutate(month = as.character(month))

ds21969_monthly_HAI_updated$weather <- bind_rows(old_weather_HAI, new_weather_HAI) %>%
  arrange(plotID, year, month)

# Check
cat("Rows ds21969 HAI:", nrow(ds21969_monthly_HAI_updated$ds21969), "\n")
cat("Rows weather HAI:", nrow(ds21969_monthly_HAI_updated$weather), "\n")


#############################SCH##############################################

# -------------------------------
# SCH Updated Dataset
# -------------------------------

ds21969_monthly_SCH_updated <- ds21969_monthly_SCH

# Prepare new rows from detrended SCH data
new_rows_SCH <- detrending_SCH_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# Prepare existing rows
existing_SCH <- ds21969_monthly_SCH_updated$ds21969 %>%
  mutate(month = as.character(month))

# Only add rows that do not exist yet
rows_to_add_SCH <- anti_join(new_rows_SCH, existing_SCH, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# Merge
ds21969_monthly_SCH_updated$ds21969 <- bind_rows(existing_SCH, rows_to_add_SCH) %>%
  arrange(year, month, Exploratory, Family)

# Add insect data from diffed datasets
old_insect_SCH <- ds21969_monthly_SCH_updated$ds21969 %>%
  mutate(month = as.character(month))

new_insect_SCH <- diffed_datasets$SCH$insect %>%
  mutate(month = as.character(month))

ds21969_monthly_SCH_updated$ds21969 <- bind_rows(old_insect_SCH, new_insect_SCH) %>%
  arrange(Exploratory, year, Family, month)

# Add weather data
old_weather_SCH <- ds21969_monthly_SCH_updated$weather %>%
  mutate(month = as.character(month))

new_weather_SCH <- diffed_datasets$SCH$weather %>%
  mutate(month = as.character(month))

ds21969_monthly_SCH_updated$weather <- bind_rows(old_weather_SCH, new_weather_SCH) %>%
  arrange(plotID, year, month)

# Add SMI_total from ds21969_both_SCH
ds21969_monthly_SCH_updated$SMI_total <- ds21969_both_SCH %>%
  rename(
    time = time,
    SCH_value = SCH,
    day = day,
    month_num = month,
    year = year,
    detrended = SCH_detrended,
    diffed_detrended = SCH_diffed_detrended
  )

# Check
cat("Rows ds21969 SCH:", nrow(ds21969_monthly_SCH_updated$ds21969), "\n")
cat("Rows weather SCH:", nrow(ds21969_monthly_SCH_updated$weather), "\n")
cat("Rows SMI_total SCH:", nrow(ds21969_monthly_SCH_updated$SMI_total), "\n")


##############NEW TRY FOR PROPER MERGE####################################
# Remove duplicated columns in a dataframe
remove_duplicate_columns <- function(df) {
  df[, !duplicated(names(df))]
}

# Clean all datasets in the stationary list
clean_stationary_list <- function(stationary_list) {
  cleaned <- list()
  for(name in names(stationary_list)) {
    df <- stationary_list[[name]]
    if(is.data.frame(df)) {
      # 1. Clean column names
      names(df) <- gsub("\\.\\.\\.[0-9]+", "", names(df))
      names(df) <- gsub("_detrended_detrended", "_detrended", names(df))
      names(df) <- gsub("_diffed_diffed", "_diffed", names(df))
      names(df) <- gsub("_diff_detrended_diff_detrended", "_diff_detrended", names(df))
      # 2. Remove duplicate columns
      df <- remove_duplicate_columns(df)
      cleaned[[name]] <- df
    }
  }
  return(cleaned)
}

# Apply cleaning for ALB, HAI, SCH
all_stationary_clean <- list(
  ALB = clean_stationary_list(updated_ds21969_stationary_ALB),
  HAI = clean_stationary_list(updated_ds21969_stationary_HAI),
  SCH = clean_stationary_list(updated_ds21969_stationary_SCH)
)

# Check cleaned column names
lapply(all_stationary_clean, function(x) lapply(x, names))

############GRANGER TEST###################################
######################## DS21969 ALB - Granger Test #################################

# -----------------------------
# 1. List of insect families & lag values
# -----------------------------
families <- unique(all_stationary_clean$ALB$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Prepare insect time series dataframe
# -----------------------------
get_insect_ts_df <- function(fam, variant = "detrended") {
  df <- all_stationary_clean$ALB$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year)
  
  # Select the appropriate insect column based on variant
  insect_col <- switch(variant,
                       detrended = "NumberAdults_detrended",
                       diffed = "NumberAdults_diffed",
                       diffed_detrended = "NumberAdults_diff_detrended",
                       "NumberAdults")
  
  if(!insect_col %in% names(df)) {
    insect_col <- "NumberAdults" # fallback
  }
  
  df %>%
    mutate(NumberAdults_use = .data[[insect_col]]) %>%
    filter(!is.na(NumberAdults_use)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# 3. Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 5. Run Granger test for ALB environmental datasets
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname, variants = c("detrended", "diffed", "diffed_detrended")) {
  map_dfr(variants, function(var) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam, var)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               InsectVariant = var,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, InsectVariant, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

# 5a. SMI_upsoil
#results_SMI_upsoil <- run_granger_env_vars(all_stationary_clean$ALB$SMI_upsoil, "SMI_upsoil", "ALB")

# 5b. SMI_total
results_SMI_total <- run_granger_env_vars(all_stationary_clean$ALB$SMI_total, "SMI_total", "ALB") #former ALB

# 5c. NDVI / NDWI / NIRv
results_ndvi <- run_granger_env_vars(all_stationary_clean$ALB$NDVI, "NDVI", "mean_NDVI")
results_ndwi <- run_granger_env_vars(all_stationary_clean$ALB$NDWI, "NDWI", "mean_NDWI")
results_nirv <- run_granger_env_vars(all_stationary_clean$ALB$NirV, "NirV", "mean_NIRv")

# 5d. Fertilization
fert_data <- all_stationary_clean$ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families, InsectVariant = c("detrended", "diffed", "diffed_detrended")) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family, InsectVariant)
    granger_safe(insect_df$NumberAdults_use, ALB_list[[1]], lags)
  })) %>%
  ungroup() %>%
  tidyr::unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "ALB") %>%
  dplyr::select(Family, InsectVariant, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# 5e. Mosaic & Weather
run_granger_env <- function(env_df, envname, variants = c("detrended", "diffed", "diffed_detrended")) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(variants, function(var) {
      map_dfr(families, function(fam) {
        insect_df <- get_insect_ts_df(fam, var)
        ts <- align_ts_year(insect_df, env_df, colname)
        
        res <- granger_safe(ts$insect, ts$env, lags)
        
        res %>%
          mutate(Family = fam,
                 InsectVariant = var,
                 EnvDataset = envname,
                 EnvColumn = colname,
                 Croptype = NA_character_,
                 Fertilizer = NA_character_) %>%
          dplyr::select(Family, InsectVariant, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
      })
    })
  })
}

mosaic_weather <- list(
  mosaic = all_stationary_clean$ALB$mosaic,
  weather = all_stationary_clean$ALB$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# 5f. ALB_crop
alb_crop <- all_stationary_clean$ALB$ALB_crop

results_crop <- map_dfr(unique(alb_crop$var), function(varname) {
  map_dfr(unique(alb_crop$measure), function(measurename) {
    subset_data <- alb_crop %>% filter(var == varname, measure == measurename)
    
    map_dfr(c("detrended", "diffed", "diffed_detrended"), function(var) {
      map_dfr(families, function(fam) {
        insect_df <- get_insect_ts_df(fam, var)
        ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
        
        res <- granger_safe(ts$insect, ts$env, lags)
        
        res %>%
          mutate(Family = fam,
                 InsectVariant = var,
                 EnvDataset = "ALB_crop",
                 EnvColumn = paste(varname, measurename, sep = "_"),
                 Croptype = NA_character_,
                 Fertilizer = NA_character_) %>%
          dplyr::select(Family, InsectVariant, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
      })
    })
  })
})

# -----------------------------
# 10. Combine all results & mark causality
# -----------------------------
results_ALB <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_ALB <- results_ALB %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 11. Save results
# -----------------------------
write.csv(results_ALB,
          "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_ALB.csv",
          row.names = FALSE)














