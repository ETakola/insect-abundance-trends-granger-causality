########################## 2nd Round Granger ###############################
# Performs Granger tests on detrended and/or differenced data (stationary):
# 1. Uses the lists created in the "detrending/differencing"-scripts
# 2. Performs Granger tests on all stationary insect datasets combined


################### load packages ###########################
library(lmtest)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests


#################### load data ##############################
# and harmonize column names for "year" and "month"

# SMI
SMI_total <- read.csv("D:/Masterarbeit/tables/smi_means_Gesamtboden.csv", sep=',', header=TRUE) %>%
  mutate(time = as.Date(time),
         day = day(time), month = month(time), year = year(time))

SMI_upsoil <- read.csv("D:/Masterarbeit/tables/smi_means_Oberboden.csv", sep=',', header=TRUE) %>%
  mutate(time = as.Date(time),
         day = day(time), month = month(time), year = year(time))

# Satellite data
NDVI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_ALB_2007_2019.csv") %>%
  dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

NDWI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_ALB_2007_2019.csv") %>%
  dplyr::select(-`system:index`)
NDWI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NDWI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

NirV_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_ALB_2007_2019_norm.csv") %>%
  dplyr::select(-`system:index`)
NirV_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_HAI_all.csv") %>%
  dplyr::select(-`system:index`)
NirV_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_SCH_all.csv") %>%
  dplyr::select(-`system:index`)

# Fertilization
Fertilization <- read.csv(
  "D:/Masterarbeit/environmental_data/Cropland_Maps/Cropland_Maps/cropland_means_by_region.csv",
  sep=';', header=TRUE
) %>% rename(year = Year)

# Mosaic
mosaic <- read_csv("D:/Masterarbeit/tables/mosaic_zones_area_weighted_means_251001.csv")

# Weather
weather <- read.csv("D:/Masterarbeit/environmental_data/bexis_climate_data_250818/plots.csv") %>%
  mutate(datetime = ym(datetime),
         year = year(datetime),
         month = month(datetime)) %>%
  mutate(region = case_when(
    str_starts(plotID,"A") ~ "ALB",
    str_starts(plotID,"H") ~ "HAI",
    str_starts(plotID,"S") ~ "SCH",
    TRUE ~ NA_character_
  ))

# Crop yield and area
ALB_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_ALB_filled.csv")
HAI_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_HAI_filled.csv")
SCH_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_SCH_filled.csv")

# Insect dataset
ds21969 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/21969_13_data.csv") %>%
  mutate(
    month_clean = str_trim(CollectionMonth),
    MonthNum = case_when(
      is.na(month_clean) ~ NA_character_,
      month_clean %in% month.abb ~ sprintf("%02d", match(month_clean, month.abb)),
      TRUE ~ NA_character_
    )
  ) %>%
  rename(year = CollectionYear,
         month = MonthNum)

# Function to decode months from "CollectionRun"
decode_collection_run <- function(run_letter){
  # A = April (4), B = May (5), ..., G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # returns NA if letter is not mapped
}


##### Stationarity tables from first round to build lists #####

# Combined ADF/KPSS results (yearly)
stationarity_table_ds21969_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969.csv",
  sep =";"
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

stationarity_table_ds21969_ALB_HAI_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv",
  sep =","
)

stationarity_table_ds21969_SCH_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv",
  sep =","
)

##### Combined stationarity tables for detrended/differenced data #####

# ds21969 yearly
ds21969_both_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_both_yearly.csv",
  sep =";"
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_detrended_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_detrended_yearly.csv",
  sep =";"
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_yearly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_diff_yearly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

# ds21969 monthly
ds21969_both_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_both_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_detrended_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_detrended_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_monthly <- read.csv(
  "D:/Masterarbeit/tables/stationarity_test/stationarity_table_ds21969_diff_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")


############################## data list for easier handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDWI_ALB = NDWI_ALB,
  NDWI_HAI = NDWI_HAI,
  NDWI_SCH = NDWI_SCH,
  NirV_ALB = NirV_ALB,
  NirV_HAI = NirV_HAI,
  NirV_SCH = NirV_SCH,
  Fertilization = Fertilization,
  mosaic = mosaic,
  weather = weather,
  ALB_crop = ALB_crop,
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop,
  ds21969 = ds21969
)


################## select datasets requiring both methods based on tables #################

# monthly
ds21969_diff_and_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_diff_and_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1. Determine months and year range
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>%
  mutate(month_num = as.numeric(month))  # numeric month for filtering

years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# ALB & HAI months
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
# SCH months
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

# ------------------------------------------------------------------------------
# 2. Select all monthly datasets (SMI, NDVI, NDWI, NirV, weather, crops)
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in%
                                c("Fertilization", "mosaic", "ALB_crop", "HAI_crop", "SCH_crop",
                                  "ds22007")]

# ------------------------------------------------------------------------------
# 3. Function to filter by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4. Apply filter for ALB & HAI
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets (ds21969 is added separately)
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[
  !names(data_for_ds21969_ALB_HAI) %in% c("ds22007")
]

# Add ds21969 for ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>%
  filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# 5. Apply filter for SCH
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[
  !names(data_for_ds21969_SCH) %in% c("ds22007")
]

# Add ds21969 for SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>%
  filter(Exploratory == "SCH")


################################################################################
# Result: two lists
# data_for_ds21969_ALB_HAI
# data_for_ds21969_SCH
################################################################################

################# DETRENDING ######################################################

# ==========================================
# 2. Detrending function
# ==========================================
detrend_number_adults <- function(df) {
  df %>%
    group_by(Family) %>%
    mutate(NumberAdults_detrended = NumberAdults - mean(NumberAdults, na.rm = TRUE)) %>%
    ungroup()
}

# Apply detrending
detrending_ALB_detr <- detrend_number_adults(detrending_ALB)
detrending_HAI_detr <- detrend_number_adults(detrending_HAI)
detrending_SCH_detr <- detrend_number_adults(detrending_SCH)

##################################################################################
################## Select datasets requiring differencing based on table ##########

ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

################# Filter and sort by region ######################################

# ALB
ALB_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "ALB" | region == "ALB")

unique(ALB_diff$dataset)

weather_ALB_diff <- ALB_diff %>%
  filter(dataset == "weather") 
weather_ALB_diff <- unique(weather_ALB_diff$variable)

str(data_for_ds21969_ALB_HAI$weather)

Family_ALB_diff <- unique(ALB_diff$Family)
Family_ALB_diff <- Family_ALB_diff[!is.na(Family_ALB_diff)]

# HAI
HAI_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "HAI" | region == "HAI")

unique(HAI_diff$dataset)
weather_HAI_diff <- HAI_diff %>%
  filter(dataset == "weather") 
weather_HAI_diff <- unique(weather_HAI_diff$variable)

Family_HAI_diff <- unique(HAI_diff$Family)
Family_HAI_diff <- Family_HAI_diff[!is.na(Family_HAI_diff)]

# SCH
SCH_diff <- ds21969_differencing_SCH_monthly %>% 
  filter(Exploratory == "SCH" | region == "SCH")

unique(SCH_diff$dataset)

weather_SCH_diff <- SCH_diff %>%
  filter(dataset == "weather") 
weather_SCH_diff <- unique(weather_SCH_diff$variable)

Family_SCH_diff <- unique(SCH_diff$Family)
Family_SCH_diff <- Family_SCH_diff[!is.na(Family_SCH_diff)]

##### Combine Family and weather datasets for each region into a list #####

# ALB
differencing_Family_ALB <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "ALB", Family %in% Family_ALB_diff) 

differencing_weather_ALB <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_ALB_diff))

# Combine into a list
differencing_list_ALB <- list(
  insect = differencing_Family_ALB,
  weather = differencing_weather_ALB
)

str(differencing_list_ALB, max.level = 2)

# HAI
differencing_Family_HAI <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "HAI", Family %in% Family_HAI_diff) 

differencing_weather_HAI <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_HAI_diff))

# Combine into a list
differencing_list_HAI <- list(
  insect = differencing_Family_HAI,
  weather = differencing_weather_HAI
)

str(differencing_list_HAI, max.level = 2)

# SCH
differencing_Family_SCH <- data_for_ds21969_SCH$ds21969 %>%
  filter(Exploratory == "SCH", Family %in% Family_HAI_diff) 

differencing_weather_SCH <- data_for_ds21969_SCH$weather %>%
  dplyr::select(1:2, 39:43, all_of(weather_SCH_diff))

# Combine into a list
differencing_list_SCH <- list(
  insect = differencing_Family_SCH,
  weather = differencing_weather_SCH
)

str(differencing_list_SCH, max.level = 2)


###########################
### Regional differencing for ds21969
###########################
# ==========================================
# 1. Differencing function
# ==========================================
difference_df <- function(df, exclude_cols = c("TrapID","Exploratory","PlotID","CollectionMonth","year","month","month_num")) {
  num_cols <- names(df)[sapply(df, is.numeric) & !(names(df) %in% exclude_cols)]
  df_diff <- df
  df_diff[num_cols] <- lapply(df[num_cols], function(x) c(NA, diff(x)))
  return(df_diff)
}

# ==========================================
# 2. Prepare region lists (like diff_lists)
# ==========================================
diff_lists <- list(
  ALB = differencing_list_ALB,
  HAI = differencing_list_HAI,
  SCH = differencing_list_SCH
)

# ==========================================
# 3. Apply differencing & save per region
# ==========================================
diffed_datasets <- list()   # Stores differenced datasets per region

for(region in names(diff_lists)) {
  cat("Processing region:", region, "\n")
  
  df_list <- diff_lists[[region]]
  
  # Apply differencing
  insect_diff  <- difference_df(df_list$insect)
  weather_diff <- difference_df(df_list$weather)
  
  # Save list for this region
  diffed_datasets[[region]] <- list(
    insect  = insect_diff,
    weather = weather_diff
  )
}

# ==========================================
# 4. Test output
# ==========================================
cat("Differenced datasets per region:\n")
str(diffed_datasets, max.level = 2)

# Select SMI_total columns for SCH
ds21969_both_SCH <- data_for_ds21969_SCH$SMI_total %>%
  dplyr::select(1, 4:7)

head(ds21969_both_SCH) 

################## Select datasets requiring both methods from table ###########

ds21969_both_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_both_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

library(dplyr)
library(tseries)
library(zoo)

# 1. Detrending (linear model)
ds21969_both_SCH <- ds21969_both_SCH %>%
  arrange(time)

# Fit linear model over time
lm_model <- lm(SCH ~ as.numeric(time), data = ds21969_both_SCH)

# Residuals as detrended time series
ds21969_both_SCH$SCH_detrended <- resid(lm_model)

# 2. Differencing (if needed)
ds21969_both_SCH$SCH_diffed_detrended <- c(NA, diff(ds21969_both_SCH$SCH_detrended))

############ ALL DONE ############################################################
# Build lists 

# Determine per dataset: which new families need to be added to the family list?

# data_for_ds21969 is the original list for Granger causality; 
# the columns from the other dataset lists now need to be added into these datasets
# How to do this?

# Originally, Granger Test was done on regionally separated lists from
# script "granger_causality_test_251111"

################################################################################
################## DS21969 ######################################################
################### ADF TEST - MONTHLY DATA ######################################

combined_ds21969_ALB_HAI <- read.csv("D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv", sep =",")

combined_ds21969_SCH <- read.csv("D:/Masterarbeit/tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv", sep =",")

################## Select only stationary results from table #################
ds21969_ALB_HAI_stationary <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_SCH_stationary <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

###################### FILTER FOR MONTHLY ds21969 ###########################

# -------------------------------------------------------------------
# Function: filter monthly ds21969 datasets based on stationary vars
# -------------------------------------------------------------------
filter_ds21969_dataset_monthly <- function(df, dataset_name, overview_ds21969) {
  
  # Check if dataset appears in stationary overview
  if(!dataset_name %in% unique(overview_ds21969$dataset)) return(NULL)
  
  # Allowed variables for this dataset
  allowed_columns <- overview_ds21969 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns except year & month
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds21969 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region for NDVI / NDWI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_monthly_ALB_HAI_list <- imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_ALB_HAI_stationary)
  }
)

filtered_ds21969_monthly_list_SCH <- imap(
  data_for_ds21969_SCH,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_SCH_stationary)
  }
)

# Remove NULL entries
filtered_ds21969_monthly_list <- filtered_ds21969_monthly_ALB_HAI_list[
  !sapply(filtered_ds21969_monthly_ALB_HAI_list, is.null)
]

filtered_ds21969_monthly_list_SCH <- filtered_ds21969_monthly_list_SCH[
  !sapply(filtered_ds21969_monthly_list_SCH, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds21969_monthly_list$ds21969_ALB_HAI
# filtered_ds21969_monthly_list_SCH$ds21969_SCH
# -------------------------------------------------------------------

names(filtered_ds21969_monthly_list)
names(filtered_ds21969_monthly_list_SCH)
str(filtered_ds21969_monthly_ALB_HAI_list, max.level = 1)
str(filtered_ds21969_monthly_list_SCH, max.level = 1)

######################################################################
############## Build sub-lists of ds21969_monthly per region #########
######################################################################

#################### ALB #############################################
# 1. SMI 
smi_total_alb <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, ALB)
smi_upsoil_alb <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, ALB)

# 2. NDVI, NDWI, NirV
ndvi_alb <- filtered_ds21969_monthly_list$NDVI_ALB
ndwi_alb <- filtered_ds21969_monthly_list$NDWI_ALB
nirv_alb <- filtered_ds21969_monthly_list$NirV_ALB

# 3. Weather
weather_alb <- filtered_ds21969_monthly_list$weather %>% filter(region == "ALB")

# 4. ds21969 for ALB
ds21969_alb <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "ALB")

# 5. Create sub-list
ds21969_monthly_ALB <- list(
  SMI_total = smi_total_alb,
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDWI = ndwi_alb,
  NirV = nirv_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI ##########################################
# 1. SMI
smi_total_hai <- filtered_ds21969_monthly_list$SMI_total %>% dplyr::select(month, year, HAI)
smi_upsoil_hai <- filtered_ds21969_monthly_list$SMI_upsoil %>% dplyr::select(month, year, HAI)

# 2. NDVI, NDWI, NirV
ndvi_hai <- filtered_ds21969_monthly_list$NDVI_HAI
ndwi_hai <- filtered_ds21969_monthly_list$NDWI_HAI
nirv_hai <- filtered_ds21969_monthly_list$NirV_HAI

# 3. Weather
weather_hai <- filtered_ds21969_monthly_list$weather %>% filter(region == "HAI")

# 4. ds21969 for HAI
ds21969_hai <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "HAI")

# 5. Create sub-list
ds21969_monthly_HAI <- list(
  SMI_total = smi_total_hai,
  SMI_upsoil = smi_upsoil_hai,
  NDVI = ndvi_hai,
  NDWI = ndwi_hai,
  NirV = nirv_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH ##########################################
# 1. SMI_upsoil
smi_sch <- filtered_ds21969_monthly_list_SCH$SMI_upsoil %>% dplyr::select(month, year, SCH)

# 2. NDVI, NDWI, NirV
ndvi_sch <- filtered_ds21969_monthly_list_SCH$NDVI_SCH
ndwi_sch <- filtered_ds21969_monthly_list_SCH$NDWI_SCH
nirv_sch <- filtered_ds21969_monthly_list_SCH$NirV_SCH

# 3. Weather
weather_sch <- filtered_ds21969_monthly_list_SCH$weather %>% filter(region == "SCH")

# 4. ds21969 for SCH
ds21969_sch <- filtered_ds21969_monthly_list_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 5. Create sub-list
ds21969_monthly_SCH <- list(
  SMI_upsoil = smi_sch, 
  NDVI = ndvi_sch,
  NDWI = ndwi_sch,
  NirV = nirv_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch
)

#####################################################################

# -------------------------------
# ALB Updated Dataset
# -------------------------------

# 1. Starting point: original list
ds21969_monthly_ALB_updated <- ds21969_monthly_ALB

# 2. Prepare new rows from detrending_ALB_detr
new_rows_ALB <- detrending_ALB_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# 3. Prepare existing rows
existing_ALB <- ds21969_monthly_ALB_updated$ds21969 %>%
  mutate(month = as.character(month))

# 4. Add only rows that do not already exist
rows_to_add_ALB <- anti_join(new_rows_ALB, existing_ALB, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# 5. Merge
ds21969_monthly_ALB_updated$ds21969 <- bind_rows(existing_ALB, rows_to_add_ALB) %>%
  arrange(year, month, Exploratory, Family)

# -------------------------------
# Add insect data from diffed_datasets
# -------------------------------

# Old insect data
old_insect_ALB <- ds21969_monthly_ALB_updated$ds21969 %>%
  mutate(month = as.character(month))

# New insect data from diffed_datasets
new_insect_ALB <- diffed_datasets$ALB$insect %>%
  mutate(month = as.character(month))

# Merge: keep all rows, no duplicates removed
ds21969_monthly_ALB_updated$ds21969 <- bind_rows(old_insect_ALB, new_insect_ALB) %>%
  arrange(Exploratory, year, Family, month)

# -------------------------------
# Add weather data
# -------------------------------

# Old weather data
old_weather_ALB <- ds21969_monthly_ALB_updated$weather %>%
  mutate(month = as.character(month))

# New weather data
new_weather_ALB <- diffed_datasets$ALB$weather %>%
  mutate(month = as.character(month))

# Merge: keep all rows
ds21969_monthly_ALB_updated$weather <- bind_rows(old_weather_ALB, new_weather_ALB) %>%
  arrange(plotID, year, month)

# -------------------------------
# Check
# -------------------------------
cat("Rows in ds21969:", nrow(ds21969_monthly_ALB_updated$ds21969), "\n")
cat("Rows in weather:", nrow(ds21969_monthly_ALB_updated$weather), "\n")

############################################################################
# -------------------------------
# HAI Updated Dataset
# -------------------------------

ds21969_monthly_HAI_updated <- ds21969_monthly_HAI

# Prepare new rows from detrending_HAI_detr
new_rows_HAI <- detrending_HAI_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# Prepare existing rows
existing_HAI <- ds21969_monthly_HAI_updated$ds21969 %>%
  mutate(month = as.character(month))

# Add only rows that do not already exist
rows_to_add_HAI <- anti_join(new_rows_HAI, existing_HAI, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# Merge
ds21969_monthly_HAI_updated$ds21969 <- bind_rows(existing_HAI, rows_to_add_HAI) %>%
  arrange(year, month, Exploratory, Family)

# Add insect data from diffed_datasets
old_insect_HAI <- ds21969_monthly_HAI_updated$ds21969 %>%
  mutate(month = as.character(month))

new_insect_HAI <- diffed_datasets$HAI$insect %>%
  mutate(month = as.character(month))

ds21969_monthly_HAI_updated$ds21969 <- bind_rows(old_insect_HAI, new_insect_HAI) %>%
  arrange(Exploratory, year, Family, month)

# Add weather data
old_weather_HAI <- ds21969_monthly_HAI_updated$weather %>%
  mutate(month = as.character(month))

new_weather_HAI <- diffed_datasets$HAI$weather %>%
  mutate(month = as.character(month))

ds21969_monthly_HAI_updated$weather <- bind_rows(old_weather_HAI, new_weather_HAI) %>%
  arrange(plotID, year, month)

# Check
cat("Rows ds21969 HAI:", nrow(ds21969_monthly_HAI_updated$ds21969), "\n")
cat("Rows weather HAI:", nrow(ds21969_monthly_HAI_updated$weather), "\n")

###########################################################################

# -------------------------------
# SCH Updated Dataset
# -------------------------------

ds21969_monthly_SCH_updated <- ds21969_monthly_SCH

# Prepare new rows from detrending_SCH_detr
new_rows_SCH <- detrending_SCH_detr %>%
  dplyr::select(Exploratory, year, Family, month, NumberAdults_detrended) %>%
  rename(NumberAdults = NumberAdults_detrended) %>%
  mutate(month = as.character(month))

# Prepare existing rows
existing_SCH <- ds21969_monthly_SCH_updated$ds21969 %>%
  mutate(month = as.character(month))

# Add only rows that do not already exist
rows_to_add_SCH <- anti_join(new_rows_SCH, existing_SCH, 
                             by = c("Exploratory", "year", "Family", "month", "NumberAdults"))

# Merge
ds21969_monthly_SCH_updated$ds21969 <- bind_rows(existing_SCH, rows_to_add_SCH) %>%
  arrange(year, month, Exploratory, Family)

# Add insect data from diffed_datasets
old_insect_SCH <- ds21969_monthly_SCH_updated$ds21969 %>%
  mutate(month = as.character(month))

new_insect_SCH <- diffed_datasets$SCH$insect %>%
  mutate(month = as.character(month))

ds21969_monthly_SCH_updated$ds21969 <- bind_rows(old_insect_SCH, new_insect_SCH) %>%
  arrange(Exploratory, year, Family, month)

# Add weather data
old_weather_SCH <- ds21969_monthly_SCH_updated$weather %>%
  mutate(month = as.character(month))

new_weather_SCH <- diffed_datasets$SCH$weather %>%
  mutate(month = as.character(month))

ds21969_monthly_SCH_updated$weather <- bind_rows(old_weather_SCH, new_weather_SCH) %>%
  arrange(plotID, year, month)

# Add SMI_total from ds21969_both_SCH
ds21969_monthly_SCH_updated$SMI_total <- ds21969_both_SCH %>%
  rename(
    time = time,
    SCH_value = SCH,
    day = day,
    month_num = month,
    year = year,
    detrended = SCH_detrended,
    diffed_detrended = SCH_diffed_detrended
  )

# Check
cat("Rows ds21969 SCH:", nrow(ds21969_monthly_SCH_updated$ds21969), "\n")
cat("Rows weather SCH:", nrow(ds21969_monthly_SCH_updated$weather), "\n")
cat("Rows SMI_total SCH:", nrow(ds21969_monthly_SCH_updated$SMI_total), "\n")

#####################################################################################
######### GRANGER TEST DS21969 monthly ##############################################
########################## ALB ######################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_ALB_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  ds21969_monthly_ALB_updated$ds21969 %>%
    filter(Family == fam) %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(NumberAdults), .groups = "drop") %>%
    arrange(year, month)
}
str(ds21969_monthly_SCH_updated)

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  # Ensure month is integer
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% dplyr::select(year, month, NumberAdults_use),
    env_df %>% dplyr::select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# Test all families for SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_ALB_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "ALB")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_total", EnvColumn = "ALB") %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------------------------------------
# Test SMI_upsoil for all families
# -----------------------------------------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_ALB_updated$SMI_upsoil   # contains year, month, ALB
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "ALB")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "ALB"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Test NDVI
results_ndvi <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_ALB_updated$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NDVI",
      EnvColumn = "mean_NDVI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Test NDWI
results_ndwi <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_ALB_updated$NDWI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDWI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NDWI",
      EnvColumn = "mean_NDWI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Test NIRv
results_nirv <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_ALB_updated$NirV
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NIRv",
      EnvColumn = "mean_NIRv"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Weather variables to test
weather_vars <- names(ds21969_monthly_ALB_updated$weather)[
  sapply(ds21969_monthly_ALB_updated$weather, is.numeric) &
    !(names(ds21969_monthly_ALB_updated$weather) %in% c("year","month"))
]

# Test weather variables
results_weather <- map_dfr(weather_vars, function(varname) {
  
  env_df <- ds21969_monthly_ALB_updated$weather %>%
    dplyr::select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    
    insect_ts <- get_insect_ts_monthly(fam)
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = "weather",
        EnvColumn = varname
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 1. Combine all results
# -----------------------------
results_ds21969_monthly <- dplyr::bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_weather
)

# -----------------------------
# 2. Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 3. Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# 4. Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_ALB_2nd_round.csv", 
  row.names = FALSE
)

#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## HAI ######################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_HAI_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  ds21969_monthly_HAI_updated$ds21969 %>%
    filter(Family == fam) %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(NumberAdults), .groups = "drop") %>%
    arrange(year, month)
}

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  # Ensure month is integer
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% dplyr::select(year, month, NumberAdults_use),
    env_df %>% dplyr::select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# Test all families for SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_HAI_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "HAI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_total", EnvColumn = "HAI") %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test SMI_upsoil for all families
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_HAI_updated$SMI_upsoil   # contains year, month, HAI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "HAI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "HAI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Check first rows
head(results_smi_upsoil)

# Test NDVI
results_ndvi <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_HAI_updated$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NDVI",
      EnvColumn = "mean_NDVI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Test NDWI
results_ndwi <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_HAI_updated$NDWI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDWI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NDWI",
      EnvColumn = "mean_NDWI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Test NIRv
results_nirv <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_HAI_updated$NirV
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "NIRv",
      EnvColumn = "mean_NIRv"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# Weather variables to test
weather_vars <- names(ds21969_monthly_HAI_updated$weather)[
  sapply(ds21969_monthly_HAI_updated$weather, is.numeric) &
    !(names(ds21969_monthly_HAI_updated$weather) %in% c("year","month"))
]

# Test weather variables
results_weather <- map_dfr(weather_vars, function(varname) {
  
  env_df <- ds21969_monthly_HAI_updated$weather %>%
    dplyr::select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    
    insect_ts <- get_insect_ts_monthly(fam)
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = "weather",
        EnvColumn = varname
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 1. Combine all results
# -----------------------------
results_ds21969_monthly <- dplyr::bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_weather
)

# -----------------------------
# 2. Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 3. Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# 4. Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_HAI_2nd_round.csv", 
  row.names = FALSE
)

#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## SCH ######################################################
# Standardize month columns for each dataset in ds21969_monthly_SCH_updated

# NDVI, NirV, NDWI
ds21969_monthly_SCH_updated$NDVI <- ds21969_monthly_SCH_updated$NDVI %>%
  dplyr::rename(month_num = month)

ds21969_monthly_SCH_updated$NDWI <- ds21969_monthly_SCH_updated$NDWI %>%
  dplyr::rename(month_num = month)

ds21969_monthly_SCH_updated$NirV <- ds21969_monthly_SCH_updated$NirV %>%
  dplyr::rename(month_num = month)

# SMI_upsoil
ds21969_monthly_SCH_updated$SMI_upsoil <- ds21969_monthly_SCH_updated$SMI_upsoil %>%
  dplyr::rename(month_num = month)

# Weather
ds21969_monthly_SCH_updated$weather <- ds21969_monthly_SCH_updated$weather %>%
  dplyr::mutate(month_num = as.integer(month))

# Insect data
ds21969_monthly_SCH_updated$ds21969 <- ds21969_monthly_SCH_updated$ds21969 %>%
  dplyr::mutate(month_num = as.integer(month))

# -----------------------------
# 1. Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_SCH_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Create insect time series for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  ds21969_monthly_SCH_updated$ds21969 %>%
    dplyr::filter(Family == fam) %>%
    dplyr::group_by(year, month_num) %>%
    dplyr::summarise(NumberAdults_use = sum(NumberAdults), .groups = "drop") %>%
    dplyr::arrange(year, month_num)
}

# -----------------------------
# 3. Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  
  df <- dplyr::inner_join(
    dplyr::select(insect_df, year, month_num, NumberAdults_use),
    dplyr::select(env_df, year, month_num, !!sym(env_col)),
    by = c("year", "month_num")
  )
  
  # Keep only complete pairs
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1:3) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 5. Granger test for SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "diffed_detrended")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    dplyr::mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "diffed_detrended"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$SMI_upsoil
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "SCH")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    dplyr::mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "SCH"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDVI
# -----------------------------
results_ndvi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    dplyr::mutate(
      Family = fam,
      EnvDataset = "NDVI",
      EnvColumn = "mean_NDVI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDWI
# -----------------------------
results_ndwi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$NDWI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDWI")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    dplyr::mutate(
      Family = fam,
      EnvDataset = "NDWI",
      EnvColumn = "mean_NDWI"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NirV
# -----------------------------
results_nirv <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$NirV
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    dplyr::mutate(
      Family = fam,
      EnvDataset = "NirV",
      EnvColumn = "mean_NIRv"
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_SCH_updated$weather)[!(names(ds21969_monthly_SCH_updated$weather) %in% c("year","month","region","plotID","datetime"))]

results_weather <- map_dfr(weather_vars, function(varname) {
  
  env_ts <- ds21969_monthly_SCH_updated$weather %>%
    dplyr::select(year, month_num, !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    
    ts_list <- align_ts_monthly(insect_ts, env_ts, varname)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      dplyr::mutate(
        Family = fam,
        EnvDataset = "weather",
        EnvColumn = varname
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# Combine all results and add causality column
# -----------------------------
results_ds21969_monthly_SCH <- dplyr::bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_ndvi,
  results_ndwi,
  results_nirv,
  results_weather
) %>%
  dplyr::mutate(
    causality = dplyr::case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  )

# -----------------------------
# Save results as CSV
# -----------------------------
write.csv(results_ds21969_monthly_SCH, "D:/Masterarbeit/tables/final_tables/granger_test/results_ds21969_monthly_SCH_2nd_round.csv", row.names = FALSE)
