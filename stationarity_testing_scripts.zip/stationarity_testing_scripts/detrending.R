#######################DETRENDING; DIFFERENCING; BOTH################################
###################load packages###########################
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) #for stationary tests 


####################load data##############################
# and get same names for the "year" and "month" column

# SMI
SMI_total <- read.csv("D:/Masterarbeit/tables/smi_means_Gesamtboden.csv", sep=',', header=TRUE) %>% mutate(time = as.Date(time), 
                                                                                                           day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("D:/Masterarbeit/tables/smi_means_Oberboden.csv", sep=',', header=TRUE) %>% mutate(time = as.Date(time), 
                                                                                                          day = day(time), month = month(time), year = year(time))

# Satellite
NDVI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_ALB_2007_2019.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_HAI_all.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDVI/Landsat7_Monthly_NDVI_SCH_all.csv") %>% dplyr::select(-`system:index`)

NDWI_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_ALB_2007_2019.csv") %>% dplyr::select(-`system:index`)
NDWI_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_HAI_all.csv") %>% dplyr::select(-`system:index`)
NDWI_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NDWI/Landsat7_Monthly_NDWI_SCH_all.csv") %>% dplyr::select(-`system:index`)

NirV_ALB <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_ALB_2007_2019_norm.csv") %>% dplyr::select(-`system:index`)
NirV_HAI <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_HAI_all.csv") %>% dplyr::select(-`system:index`)
NirV_SCH <- read_csv("D:/Masterarbeit/GEE/data/Landsat7_NirV/Landsat7_Monthly_NIRv_SCH_all.csv") %>% dplyr::select(-`system:index`)

# Fertilization
Fertilization <- read.csv("D:/Masterarbeit/environmental_data/Cropland_Maps/Cropland_Maps/cropland_means_by_region.csv", sep=';', header=TRUE) %>% rename(year = Year)

# Mosaic
mosaic <- read_csv("D:/Masterarbeit/tables/mosaic_zones_area_weighted_means_251001.csv")

# Weather
weather <- read.csv("D:/Masterarbeit/environmental_data/bexis_climate_data_250818/plots.csv") %>% mutate(datetime = ym(datetime),
                                                                                                         year = year(datetime), month = month(datetime)) %>% mutate(region=case_when(
                                                                                                           str_starts(plotID,"A") ~ "ALB",
                                                                                                           str_starts(plotID,"H") ~ "HAI",
                                                                                                           str_starts(plotID,"S") ~ "SCH",
                                                                                                           TRUE ~ NA_character_
                                                                                                         ))


# Crop yield and area 
ALB_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_ALB_filled.csv")
HAI_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_HAI_filled.csv")
SCH_crop <- read.csv("D:/Masterarbeit/python/CORINE/merged_SCH_filled.csv")

# Insect datasets
ds21969 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/21969_13_data.csv") %>%  mutate(
  month_clean = str_trim(CollectionMonth),                     # Clean month string
  MonthNum = case_when(
    is.na(month_clean) ~ NA_character_,
    month_clean %in% month.abb ~ sprintf("%02d", match(month_clean, month.abb)), # Map abbreviation to month number
    TRUE ~ NA_character_                              
  )
) %>% rename(year = CollectionYear,
             month = MonthNum) 

# Function: extracting months out of "CollectionRun"
decode_collection_run <- function(run_letter){
  # A = April = 4, B = May = 5, ..., G = October = 10
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # NA if letter is not in mapping 
}

############################################################################################

# load ds22007 
ds22007 <- read_csv("C:/Users/Lesli/Desktop/Uni/Masterarbeit/R/scripts/data_description/Seibold2019/22007_11_data.csv") %>%
  mutate(
    # extract letter from CollectionRun
    run_letter = str_sub(CollectionRun, 1, 1),  
    # convert letter to month number
    month = decode_collection_run(run_letter),
    #optional: as character string
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),
    # year as numeric
    year = as.numeric(CollectionYear)
  ) %>%
  dplyr::select(-run_letter) 

#combined results from ADF/KPSS test - yearly 
stationarity_table_ds21969_yearly <- read.csv("D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds21969.csv", sep =",")
stationarity_table_ds22007_yearly <- read.csv("D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds22007.csv", sep =",")

stationarity_table_ds22007_monthly <- read.csv("D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep =",")
stationarity_table_ds21969_ALB_HAI_monthly <- read.csv("D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv" , sep =",")
stationarity_table_ds21969_SCH_monthly <- read.csv("D:/Masterarbeit/tables/final_tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv" , sep =",")

##############################list with data for easier handling##############
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, 
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH, 
  NDWI_ALB = NDWI_ALB,
  NDWI_HAI = NDWI_HAI,
  NDWI_SCH = NDWI_SCH,
  NirV_ALB = NirV_ALB,
  NirV_HAI = NirV_HAI,
  NirV_SCH = NirV_SCH,
  Fertilization = Fertilization, 
  mosaic = mosaic, 
  weather = weather, 
  ALB_crop = ALB_crop, 
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop, 
  ds21969 = ds21969, 
  ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDWI_ALB = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_HAI = list(type = "columns", cols = c("mean_NDWI")),
  NDWI_SCH = list(type = "columns", cols = c("mean_NDWI")),
  NirV_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NirV_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NirV_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped",group_cols = c("Croptype", "Fertilizer"),value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type ="grouped",group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds21969 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type ="grouped",group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)


#######################YEARLY AGGREGATION#####################################
# Function to aggregate datasets to yearly resolution.
# This is necessary for comparing data across years and performing 
# subsequent stationarity/detrending analysis.
aggregate_yearly <- function(df, dataset_name) {
  
  # Special case for *_crop datasets: weighted values are averaged
  # across combinations of year, crop type, and measure.
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE), .groups = "drop")
    )
  }
  
  # Define grouping and aggregation columns depending on dataset type
  group_col <- NULL
  sum_cols <- c()
  if (dataset_name %in% c("ds21969","ds22007")) {
    # Insect datasets: group by exploratory site and family
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"  # sum the number of adults per year
  }
  if (dataset_name == "weather") {
    # Weather data: group by region
    group_col <- "region"
    sum_cols <- names(df)[3:39]  # numeric weather variables
  }
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  # Identify all other columns to aggregate via mean
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # Perform the actual aggregation
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),  # mean for continuous variables
        across(all_of(sum_cols), sum, na.rm = TRUE),    # sum for counts
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################

# Prepare yearly aggregated datasets for ds21969 and ds22007

# Determine the range of years for each insect dataset
years_ds21969 <- range(ds21969$year, na.rm = TRUE)
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

# Apply yearly aggregation across all datasets
data_yearly <- lapply(names(data_list), function(name) {
  aggregate_yearly(data_list[[name]], name)
})
names(data_yearly) <- names(data_list)

# Trim datasets to their respective year ranges
data_for_ds21969 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2]))
data_for_ds22007 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds22007[1], year <= years_ds22007[2]))

# Remove other insect datasets to avoid duplication
data_for_ds21969 <- data_for_ds21969[!names(data_for_ds21969) %in% c("ds22007")]
data_for_ds22007 <- data_for_ds22007[!names(data_for_ds22007) %in% c("ds21969")]


##################################################################
##################SELECT ONLY STATIONARY VARIABLES#################
# Yearly ADF and KPSS tests results
ds21969_stationary_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_stationary_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

# Monthly stationary selection
ds22007_stationary_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

##################SELECT VARIABLES THAT REQUIRE DETRENDING#################
# Yearly variables where ADF indicates non-stationarity but KPSS is stationary
ds21969_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds22007_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

# Monthly datasets needing detrending
ds22007_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

#############################DETRENDING##################################################
# Filter insect dataset ds21969 for detrending

# -------------------------------------------------------------------
# Function to filter a dataset for detrending based on overview table
# Only retains variables that need detrending and relevant grouping columns
# -------------------------------------------------------------------
filter_ds21969_detrend <- function(df, dataset_name, detrend_overview) {
  
  # Check if dataset appears in detrending overview
  if(!dataset_name %in% unique(detrend_overview$dataset)) return(NULL)
  
  # Extract variables to detrend
  allowed_columns <- detrend_overview %>%
    dplyr::filter(dataset == dataset_name) %>%
    dplyr::pull(variable)
  
  # Possible grouping columns to retain
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Columns to keep in filtered dataset
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter rows by allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- detrend_overview %>%
      dplyr::filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      dplyr::pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite datasets (NDVI, NDWI, NirV)
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDWI_ALB","NDWI_HAI","NDWI_SCH",
                         "NirV_ALB","NirV_HAI","NirV_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering function to all ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_detrend <- imap(data_for_ds21969, function(df, name) {
  filter_ds21969_detrend(df, name, ds21969_detrend_yearly)
})

# Remove any NULL entries (datasets not needing detrending)
filtered_ds21969_detrend <- filtered_ds21969_detrend[!sapply(filtered_ds21969_detrend, is.null)]

# -----------------------------
# Test output
# -----------------------------
cat("Filtered datasets for detrending:\n")
print(names(filtered_ds21969_detrend))

cat("\nColumns in each dataset:\n")
for (name in names(filtered_ds21969_detrend)) {
  cat(paste0(name, ": "), paste(names(filtered_ds21969_detrend[[name]]), collapse=", "), "\n")
}

##################DETRENDING DS21969##################################

# -------------------------------------------------------------------
# Function to perform linear detrending for each time series column
# Removes linear temporal trends to improve stationarity
# -------------------------------------------------------------------
detrend_ts <- function(df, value_cols, time_col = "year") {
  
  df_detrended <- df
  
  for (col in value_cols) {
    if (col %in% names(df)) {
      # Check for sufficient non-missing data points
      if(sum(!is.na(df[[col]])) > 1) {
        fit <- lm(df[[col]] ~ df[[time_col]])
        df_detrended[[col]] <- residuals(fit)  # remove trend
      } else {
        df_detrended[[col]] <- NA
      }
    }
  }
  
  return(df_detrended)
}

# -------------------------------------------------------------------
# Apply detrending function to all filtered datasets
# -------------------------------------------------------------------
filtered_ds21969_detrended <- imap(filtered_ds21969_detrend, function(df, name) {
  
  # Determine which columns to detrend based on overview table
  value_cols <- ds21969_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts(df, value_cols, time_col = "year")
})

# -----------------------------
# Test output
# -----------------------------
cat("Detrended datasets:\n")
print(names(filtered_ds21969_detrended))

cat("\nExample: first rows of a dataset:\n")
print(head(filtered_ds21969_detrended[[1]]))
str(filtered_ds21969_detrended)


##################ADF-Test for ds21969 detrended#######################

######################################################################
# 1. Safe wrapper for ADF test
# Ensures the test handles missing data and small series gracefully
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  res <- tryCatch({
    test <- adf.test(x, k = 0)  # k=0: no lag (baseline)
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  return(res)
}

######################################################################
# 2. Configuration for ds21969: grouped by Exploratory site and family
configs_ds21969 <- list(
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

######################################################################
# 3. Run ADF Test for all detrended ds21969 datasets
# Iterates over datasets and groups, applying the safe ADF test
run_adf_tests_ds21969 <- function(detrended_list, configs) {
  
  results <- list()
  
  for (ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    if (is.null(cfg)) next
    
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_adf_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        for (v in vcols) {
          res <- safe_adf_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

######################################################################
# 4. Run the ADF tests
res_adf_ds21969_detrended <- run_adf_tests_ds21969(filtered_ds21969_detrended, configs_ds21969)

######################################################################
# 5. Preview results and optionally export
head(res_adf_ds21969_detrended)
#write.csv(res_adf_ds21969_detrended, "D:/Masterarbeit/tables/final_tables/stationarity_test/detrend_diff/adf_test_ds21969_detrended.csv", row.names = FALSE)

################## KPSS-Test for ds21969 detrended #######################

# Safe wrapper for KPSS test to handle missing values and short series
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# Run KPSS tests for grouped detrended datasets
run_kpss_tests_ds21969 <- function(detrended_list, configs) {
  results <- list()
  for(ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    if(is.null(cfg)) next
    if(cfg$type == "grouped") {
      gcols <- intersect(cfg$group_cols, names(df))
      vcols <- intersect(cfg$value_cols, names(df))
      if(length(gcols) > 0) {
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y) %>% mutate(across(everything(), as.character))
            res_rows <- lapply(vcols, function(v) cbind(dataset = ds_name, variable = v, safe_kpss_test(.x[[v]]), group_info))
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        results[[length(results)+1]] <- do.call(rbind, lapply(vcols, function(v) cbind(dataset = ds_name, variable = v, safe_kpss_test(df[[v]]))))
      }
    }
  }
  bind_rows(results)
}

# Execute KPSS test
res_kpss_ds21969_detrended <- run_kpss_tests_ds21969(filtered_ds21969_detrended, configs_ds21969)

# Combine ADF and KPSS results into a single table
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  tibble(
    status_adf  = ifelse(!is.na(adf_p) & adf_p < alpha, "stationary", "non-stationary"),
    status_kpss = ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  )
}

combined_stationarity_ds21969 <- res_adf_ds21969_detrended %>%
  rename(adf_statistic = statistic, adf_pvalue = p_value) %>%
  left_join(
    res_kpss_ds21969_detrended %>% rename(kpss_statistic = statistic, kpss_pvalue = p_value),
    by = c("dataset","variable", "Exploratory","Family")
  ) %>%
  rowwise() %>%
  mutate(status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))) %>%
  unnest(cols = c(status)) %>%
  ungroup()

# Preview and export
cat("Combined stationarity table for ds21969:\n")
print(head(combined_stationarity_ds21969))

write.csv(
  combined_stationarity_ds21969,
  "D:/Masterarbeit/tables/final_tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_yearly.csv",
  row.names = FALSE
)


################# TAKE ONLY DATASETS REQUIRING DIFFERENCING #################

# Yearly datasets needing differencing
ds21969_differencing_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds22007_differencing_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# Monthly datasets needing differencing
ds22007_differencing_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")


################## DIFFERENCING DS21969 ##############################

# -------------------------------------------------------------------
# Function: Filter ds21969 for differencing
# -------------------------------------------------------------------
filter_ds21969_diff <- function(df, dataset_name, diff_overview) {
  
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% select(any_of(columns_to_keep))
  
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Generate filtered list for differencing
# -------------------------------------------------------------------
filtered_ds21969_diff <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_diff(df, name, ds21969_differencing_yearly)
})

filtered_ds21969_diff <- filtered_ds21969_diff[!sapply(filtered_ds21969_diff, is.null)]

cat("Filtered datasets for differencing:\n")
print(names(filtered_ds21969_diff))


################## STATIONARITY TESTS FOR DIFFERENCED DS21969 #######################

# -------------------------------------------------------------------
# Safe wrapper for ADF test
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(statistic = as.numeric(test$statistic),
               p_value = as.numeric(test$p.value),
               status = ifelse(test$p.value < 0.05, "stationary", "non-stationary"))
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# -------------------------------------------------------------------
# Safe wrapper for KPSS test
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) return(data.frame(statistic = NA, p_value = NA, status = NA))
  tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(statistic = as.numeric(test$statistic),
               p_value = as.numeric(test$p.value),
               status = ifelse(test$p.value < 0.05, "non-stationary", "stationary"))
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
}

# -------------------------------------------------------------------
# Function: Differencing + ADF + KPSS tests
# -------------------------------------------------------------------
run_stationarity_tests_diff <- function(diff_list) {
  
  results <- list()
  
  for(ds_name in names(diff_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(group_cols)))
      res_list <- df_grouped %>%
        group_map(~{
          group_info <- as.data.frame(.y) %>% mutate(across(everything(), as.character))
          df_diff <- .x
          for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
          
          res_rows <- lapply(value_cols, function(col) {
            adf_res  <- safe_adf_test(df_diff[[col]])
            kpss_res <- safe_kpss_test(df_diff[[col]])
            cbind(dataset = ds_name, variable = col,
                  adf_statistic = adf_res$statistic, adf_pvalue = adf_res$p_value, status_adf = adf_res$status,
                  kpss_statistic = kpss_res$statistic, kpss_pvalue = kpss_res$p_value, status_kpss = kpss_res$status,
                  group_info, stringsAsFactors = FALSE)
          })
          do.call(rbind, res_rows)
        })
      results[[length(results)+1]] <- do.call(rbind, res_list)
    } else {
      df_diff <- df
      for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
      res_rows <- lapply(value_cols, function(col) {
        adf_res  <- safe_adf_test(df_diff[[col]])
        kpss_res <- safe_kpss_test(df_diff[[col]])
        cbind(dataset = ds_name, variable = col,
              adf_statistic = adf_res$statistic, adf_pvalue = adf_res$p_value, status_adf = adf_res$status,
              kpss_statistic = kpss_res$statistic, kpss_pvalue = kpss_res$p_value, status_kpss = kpss_res$status,
              stringsAsFactors = FALSE)
      })
      results[[length(results)+1]] <- do.call(rbind, res_rows)
    }
  }
  
  bind_rows(results)
}

# -------------------------------------------------------------------
# Execute stationarity tests on differenced data
# -------------------------------------------------------------------
res_stationarity_filtered_diff <- run_stationarity_tests_diff(filtered_ds21969_diff)

# Preview and export
head(res_stationarity_filtered_diff)

write.csv(
  res_stationarity_filtered_diff,
  "D:/Masterarbeit/tables/final_tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_yearly.csv",
  row.names = FALSE
)


################# TAKE ONLY DATASETS REQUIRING BOTH METHODS #################

# Yearly
ds21969_diff_and_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_diff_and_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

# Monthly
ds21969_diff_and_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_diff_and_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_diff_and_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")


######################## FILTER DS21969 FOR DIFFERENCING & DETRENDING ##################

filter_ds21969_diff_detrend <- function(df, dataset_name, overview_table) {
  if(!dataset_name %in% unique(overview_table$dataset)) return(NULL)
  
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% select(any_of(columns_to_keep))
  
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
  }
  
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH","NDWI_ALB","NDWI_HAI","NDWI_SCH","NirV_ALB","NirV_HAI","NirV_SCH")) {
    df_filtered <- df_filtered %>% select(-any_of("region"))
  }
  
  return(df_filtered)
}

filtered_ds21969_diff_detrend <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_diff_detrend(df, name, ds21969_diff_and_detrend_yearly)
})

filtered_ds21969_diff_detrend <- filtered_ds21969_diff_detrend[!sapply(filtered_ds21969_diff_detrend, is.null)]

cat("Filtered datasets for differencing + detrending:\n")
print(names(filtered_ds21969_diff_detrend))


######################## RUN ADF + KPSS TESTS ##################

run_stationarity_tests <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_detrend_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~{
        res_list <- list()
        
        for(val_col in value_cols) {
          ts_data <- .x %>% select(year, !!sym(val_col)) %>% filter(!is.na(.data[[val_col]]))
          if(nrow(ts_data) < 3) next
          
          detrended <- tryCatch(resid(lm(ts_data[[val_col]] ~ ts_data$year)), error = function(e) NULL)
          if(is.null(detrended) || length(detrended) < 2) next
          
          differenced <- diff(detrended)
          
          kpss_p <- tryCatch(tseries::kpss.test(differenced, null = "Level")$p.value, error = function(e) NA)
          adf_p  <- tryCatch(tseries::adf.test(differenced, alternative = "stationary")$p.value, error = function(e) NA)
          
          res_list[[val_col]] <- tibble(variable = val_col, adf_pvalue = adf_p, kpss_pvalue = kpss_p)
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

stationarity_results <- run_stationarity_tests(filtered_ds21969_diff_detrend)

cat("Stationarity test results:\n")
names(stationarity_results)


######################## COMBINE RESULTS INTO TABLE ##################
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  adf_status  <- ifelse(!is.na(adf_p) & adf_p < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  tibble(status_adf = adf_status, status_kpss = kpss_status)
}

stationarity_table_ds21969_both_yearly <- imap_dfr(stationarity_results, function(df, ds_name) {
  if(nrow(df) == 0) return(NULL)
  
  df %>%
    mutate(dataset = ds_name) %>%
    rowwise() %>%
    mutate(status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))) %>%
    unnest(cols = c(status)) %>%
    select(dataset, everything())
})

cat("Stationarity Table:\n")
print(stationarity_table_ds21969_both_yearly)

write.csv(
  stationarity_table_ds21969_both_yearly,
  "D:/Masterarbeit/tables/final_tables/detrend_diff_stationarity/stationarity_table_ds21969_both_yearly.csv",
  row.names = FALSE
)


####################### DS22007 ##############################
##################
# DETREND TABLES
##################
ds22007_detrend_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds22007_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

##################
# DIFFERENCING TABLES
##################
ds22007_diff_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds22007_diff_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

##################
# BOTH METHODS TABLES
##################
ds22007_both_yearly <- stationarity_table_ds22007_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds22007_both_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")



############################# DETREND DS22007_YEARLY ##############################

# -------------------------------------------------------------------
# 1 Filter function for detrending (analogous to ds21969)
# -------------------------------------------------------------------
filter_ds22007_detrend <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is listed in overview
  if(!dataset_name %in% detrend_overview$dataset) {
    cat("Dataset", dataset_name, "not in detrend overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Allowed columns
  allowed_columns <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns
  grouping_columns <- c("year","Croptype","Fertilizer","region","var","measure","Exploratory","Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Filter data frame
  df_filtered <- df %>% dplyr::select(any_of(unique(c(existing_group_cols, allowed_columns))))
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# 2 Create filtered list of all ds22007 yearly datasets
# -------------------------------------------------------------------
filtered_ds22007_detrend <- purrr::imap(
  data_for_ds22007,
  function(df, name) {
    filter_ds22007_detrend(df, name, ds22007_detrend_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_detrend <- filtered_ds22007_detrend[!sapply(filtered_ds22007_detrend, is.null)]

cat("\nFiltered datasets for detrending:\n")
print(names(filtered_ds22007_detrend))

# -------------------------------------------------------------------
# 3 Linear detrending function
# -------------------------------------------------------------------
detrend_ts <- function(df, value_cols, time_col = "year") {
  df_detrended <- df
  for (col in value_cols) {
    if (col %in% names(df)) {
      if(sum(!is.na(df[[col]])) > 1) {
        fit <- lm(df[[col]] ~ df[[time_col]])
        df_detrended[[col]] <- residuals(fit)
      } else {
        df_detrended[[col]] <- NA
      }
    }
  }
  return(df_detrended)
}

# -------------------------------------------------------------------
# 4 Apply detrending to filtered datasets
# -------------------------------------------------------------------
filtered_ds22007_detrended <- imap(filtered_ds22007_detrend, function(df, name) {
  value_cols <- ds22007_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts(df, value_cols, time_col = "year")
})

cat("\nDetrended datasets:\n")
print(names(filtered_ds22007_detrended))

# Example output
if(length(filtered_ds22007_detrended) > 0) {
  cat("\nExample: first rows of the first dataset:\n")
  print(head(filtered_ds22007_detrended[[1]]))
}

# -------------------------------------------------------------------
# 5 Safe ADF test function
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(
      ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA
    ))
  }
  res <- tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(
      ADF_statistic = as.numeric(test$statistic),
      ADF_pvalue = as.numeric(test$p.value),
      ADF_status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(
    ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA
  ))
  return(res)
}

# -------------------------------------------------------------------
# 5b Safe KPSS test function
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(
      KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA
    ))
  }
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      KPSS_statistic = as.numeric(test$statistic),
      KPSS_pvalue = as.numeric(test$p.value),
      KPSS_status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(
    KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA
  ))
  return(res)
}

# -------------------------------------------------------------------
# 7 Configuration for ds22007
# -------------------------------------------------------------------
configs_ds22007 <- list(
  ds22007 = list(
    type = "grouped",
    group_cols = c("Exploratory","Family"),
    value_cols = c("NumberAdults")
  )
)

# -------------------------------------------------------------------
# 8 Combined ADF and KPSS test runner
# -------------------------------------------------------------------
run_stationarity_tests_ds22007 <- function(detrended_list, configs) {
  results <- list()
  
  for(ds_name in names(detrended_list)) {
    cat("Checking dataset:", ds_name, "\n")
    df <- detrended_list[[ds_name]]
    cfg <- configs[[ds_name]]
    if(is.null(cfg)) next
    
    gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
    vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
    if(length(vcols) == 0) next
    
    if(length(gcols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(gcols)))
      
      res_list <- df_grouped %>% group_map(~ {
        group_info <- as.data.frame(.y)
        group_info[] <- lapply(group_info, as.character)
        
        res_rows <- list()
        for(v in vcols) {
          adf_res  <- safe_adf_test(.x[[v]])
          kpss_res <- safe_kpss_test(.x[[v]])
          
          full <- cbind(
            dataset = ds_name,
            variable = v,
            adf_res,
            kpss_res,
            group_info,
            stringsAsFactors = FALSE
          )
          res_rows[[length(res_rows) + 1]] <- full
        }
        
        do.call(rbind, res_rows)
      })
      
      results[[length(results) + 1]] <- do.call(rbind, res_list)
      
    } else {
      for(v in vcols) {
        adf_res  <- safe_adf_test(df[[v]])
        kpss_res <- safe_kpss_test(df[[v]])
        
        results[[length(results) + 1]] <- cbind(
          dataset = ds_name,
          variable = v,
          adf_res,
          kpss_res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  bind_rows(results)
}

# -------------------------------------------------------------------
# 9 Run tests
# -------------------------------------------------------------------
res_stationarity_ds22007_detrended <- run_stationarity_tests_ds22007(
  filtered_ds22007_detrended,
  configs_ds22007
)

# -------------------------------------------------------------------
# 10 Export
# -------------------------------------------------------------------
write.csv(
  res_stationarity_ds22007_detrended,
  "D:/Masterarbeit/tables/final_tables/stationarity_test/stationarity_table_ds22007_detrended_yearly.csv",
  row.names = FALSE
)


#############################
### DIFFERENCING DS22007_YEARLY
#############################

# -------------------------------------------------------------------
# Function: filter ds22007 dataset for differencing
# -------------------------------------------------------------------
filter_ds22007_diff <- function(df, dataset_name, diff_overview) {
  
  # Check whether dataset is listed in overview
  if(!dataset_name %in% unique(diff_overview$dataset)) {
    cat("Dataset", dataset_name, "not in differencing overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Extract variables to be differenced
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep only columns that exist in the data frame
  allowed_columns <- intersect(allowed_columns, names(df))
  cat("Allowed columns to difference (exist in df):", paste(allowed_columns, collapse = ", "), "\n")
  
  # Grouping columns
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region",
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  cat("Existing grouping columns in df:", paste(existing_group_cols, collapse = ", "), "\n")
  
  # Select existing columns only
  columns_to_keep <- intersect(unique(c(existing_group_cols, allowed_columns)), names(df))
  df_filtered <- df %>% dplyr::select(all_of(columns_to_keep))
  cat("Number of rows after column selection:", nrow(df_filtered), "\n")
  
  # Filter allowed values for grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite products
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDWI_ALB","NDWI_HAI","NDWI_SCH",
                         "NirV_ALB","NirV_HAI","NirV_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Create filtered list of all ds22007 yearly datasets
# -------------------------------------------------------------------
filtered_ds22007_diff <- purrr::imap(
  data_for_ds22007,
  function(df, name) {
    filter_ds22007_diff(df, name, ds22007_differencing_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_diff <- filtered_ds22007_diff[!sapply(filtered_ds22007_diff, is.null)]

cat("Filtered datasets for differencing:\n")
print(names(filtered_ds22007_diff))

#############################################
### ADF + KPSS TESTS FOR DIFFERENCED DS22007
#############################################

# -------------------------------------------------------------------
# SAFE KPSS TEST
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) {
    return(data.frame(KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA))
  }
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      KPSS_statistic = as.numeric(test$statistic),
      KPSS_pvalue = as.numeric(test$p.value),
      KPSS_status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(KPSS_statistic = NA, KPSS_pvalue = NA, KPSS_status = NA))
  return(res)
}

# -------------------------------------------------------------------
# SAFE ADF TEST
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3 || all(is.na(x))) {
    return(data.frame(ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA))
  }
  res <- tryCatch({
    test <- adf.test(x, alternative = "stationary")
    data.frame(
      ADF_statistic = as.numeric(test$statistic),
      ADF_pvalue = as.numeric(test$p.value),
      ADF_status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(ADF_statistic = NA, ADF_pvalue = NA, ADF_status = NA))
  return(res)
}

# -------------------------------------------------------------------
# Function: differencing with ADF and KPSS tests for all groups
# -------------------------------------------------------------------
run_stationarity_tests_diff <- function(diff_list) {
  results <- list()
  
  for(ds_name in names(diff_list)) {
    cat("Processing dataset:", ds_name, "\n")
    df <- diff_list[[ds_name]]
    
    # Identify numeric columns
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(group_cols)))
      
      res_list <- df_grouped %>% group_map(~ {
        group_info <- as.data.frame(.y)
        group_info[] <- lapply(group_info, as.character)
        res_rows <- list()
        
        # Differencing
        df_diff <- .x
        for(col in value_cols) {
          df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
        }
        
        # Run tests
        for(col in value_cols) {
          adf_res  <- safe_adf_test(df_diff[[col]])
          kpss_res <- safe_kpss_test(df_diff[[col]])
          
          full <- cbind(
            dataset = ds_name,
            variable = col,
            adf_res,
            kpss_res,
            group_info,
            stringsAsFactors = FALSE
          )
          res_rows[[length(res_rows)+1]] <- full
        }
        
        do.call(rbind, res_rows)
      })
      
      results[[length(results)+1]] <- do.call(rbind, res_list)
      
    } else {
      # No grouping
      df_diff <- df
      for(col in value_cols) df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
      
      res_rows <- lapply(value_cols, function(col) {
        adf_res  <- safe_adf_test(df_diff[[col]])
        kpss_res <- safe_kpss_test(df_diff[[col]])
        cbind(dataset = ds_name, variable = col, adf_res, kpss_res, stringsAsFactors = FALSE)
      })
      
      results[[length(results)+1]] <- do.call(rbind, res_rows)
    }
  }
  
  final_res <- bind_rows(results)
  return(final_res)
}

# -------------------------------------------------------------------
# RUN TESTS
# -------------------------------------------------------------------
res_stationarity_ds22007_diff <- run_stationarity_tests_diff(filtered_ds22007_diff)

# -------------------------------------------------------------------
# EXPORT
# -------------------------------------------------------------------
write.csv(
  res_stationarity_ds22007_diff,
  "D:/Masterarbeit/tables/final_tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_yearly.csv",
  row.names = FALSE
)

######################### DS22007 - YEARLY – DETRENDING + DIFFERENCING #########################

# =====================================================================================
# 1) Function to filter datasets (analogous to ds21969)
# =====================================================================================
filter_ds22007_diff_detrend <- function(df, dataset_name, overview_table) {
  
  # Proceed only if dataset is listed in overview table
  if(!dataset_name %in% unique(overview_table$dataset)) {
    cat("Dataset", dataset_name, "not found in overview\n")
    return(NULL)
  }
  
  # Extract variables to be processed
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns to retain
  grouping_columns <- c(
    "year", "Croptype", "Fertilizer", "region", 
    "var", "measure", "Exploratory", "Family"
  )
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Define columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% 
    dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter based on allowed combinations
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% 
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite data
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDWI_ALB","NDWI_HAI","NDWI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-dplyr::any_of("region"))
  }
  
  cat("Dataset", dataset_name, "filtered.\n")
  return(df_filtered)
}

# =====================================================================================
# 2) Apply to all ds22007 datasets
# =====================================================================================

filtered_ds22007_diff_detrend <- purrr::imap(
  data_for_ds22007,
  function(df, name){
    filter_ds22007_diff_detrend(df, name, ds22007_diff_and_detrend_yearly)
  }
)

# Remove NULL entries
filtered_ds22007_diff_detrend <- filtered_ds22007_diff_detrend[!sapply(filtered_ds22007_diff_detrend, is.null)]

cat("\nFiltered datasets for DS22007:\n")
print(names(filtered_ds22007_diff_detrend))

# =====================================================================================
# 3) Function for ADF + KPSS on differenced and detrended data
# =====================================================================================

run_stationarity_tests_ds22007 <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- diff_detrend_list[[ds_name]]
    
    # Identify numeric columns (excluding year)
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "year"]
    
    # Grouping columns
    group_cols <- names(df)[!names(df) %in% value_cols & names(df) != "year"]
    
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        
        res_list <- list()
        
        for(val_col in value_cols) {
          
          ts_data <- .x %>%
            dplyr::select(year, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 3) next
          
          #--------------------------------------------------------------
          # 1) detrending
          #--------------------------------------------------------------
          detrended <- tryCatch(resid(lm(ts_data[[val_col]] ~ ts_data$year)),
                                error = function(e) NULL)
          if(is.null(detrended) || length(detrended) < 2) next
          
          #--------------------------------------------------------------
          # 2) differencing
          #--------------------------------------------------------------
          differenced <- diff(detrended)
          
          #--------------------------------------------------------------
          # Stationarity tests
          #--------------------------------------------------------------
          kpss_p <- tryCatch(
            tseries::kpss.test(differenced, null = "Level")$p.value,
            error = function(e) NA
          )
          
          adf_p <- tryCatch(
            tseries::adf.test(differenced, alternative = "stationary")$p.value,
            error = function(e) NA
          )
          
          res_list[[val_col]] <- tibble(
            variable = val_col,
            adf_pvalue = adf_p,
            kpss_pvalue = kpss_p
          )
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

# =====================================================================================
# 4) Run tests
# =====================================================================================

stationarity_results_ds22007 <- run_stationarity_tests_ds22007(filtered_ds22007_diff_detrend)

cat("\nStationarity test results:\n")
print(names(stationarity_results_ds22007))

# =====================================================================================
# 5) Function to derive stationarity status (same as ds21969)
# =====================================================================================

get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  adf_status  <- ifelse(!is.na(adf_p)  & adf_p  < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  
  tibble(
    status_adf  = adf_status,
    status_kpss = kpss_status
  )
}

# =====================================================================================
# 6) Convert result list to table
# =====================================================================================

stationarity_table_ds22007_both_yearly <- purrr::imap_dfr(
  stationarity_results_ds22007,
  function(df, ds_name) {
    if(nrow(df) == 0) return(NULL)
    
    df %>%
      mutate(dataset = ds_name) %>%
      rowwise() %>%
      mutate(
        status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))
      ) %>%
      unnest(cols = c(status)) %>%
      dplyr::select(dataset, everything())
  }
)

# =====================================================================================
# 7) Output and export
# =====================================================================================

cat("\nStationarity Table DS22007:\n")
print(stationarity_table_ds22007_both_yearly)

write.csv(
  stationarity_table_ds22007_both_yearly,
  "D:/Masterarbeit/final_tables/tables/stationarity_test/stationarity_table_ds22007_both_yearly.csv",
  row.names = FALSE
)

