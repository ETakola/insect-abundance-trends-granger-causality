####################### ds21969 YEARLY ##################################
########################## 2nd Round Granger ############################
# 2. Performs Granger tests on all stationary insect data aggregated together

################### load packages #######################################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests

#################### load data #########################################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


##### Stationarity table from first round (used to build lists) ########
ds21969_stationary_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_yearly.csv", 
  sep =","
  ) %>% filter(status_adf == "stationary", status_kpss == "stationary")

##### Combined stationarity tables with transformed data ################
# ds21969 – yearly
ds21969_both_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_detrended_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_yearly.csv",
  sep = ","
) %>% filter(ADF_status == "stationary", KPSS_status == "stationary")

ds21969_differenced_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

############################## data list ################################
# Combine all datasets into a single list for easier handling
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  Fertilization = Fertilization,
  mosaic = mosaic,
  weather = weather,
  ALB_crop = ALB_crop,
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop,
  ds21969 = ds21969
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped", group_cols = c("Croptype", "Fertilizer"), value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type = "grouped", group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

####################### YEARLY AGGREGATION DS21969 #######################

# -----------------------------
# Function: Aggregate datasets yearly (except weather)
# -----------------------------
aggregate_yearly <- function(df, dataset_name) {
  
  # Filter for NDVI, NDMI, NIRv: only months April to October
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NIRv_ALB", "NIRv_HAI", "NIRv_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
  # Special handling for crop datasets
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
                  .groups = "drop") %>%
        mutate(year = as.integer(year))
    )
  }
  
  # Define grouping and sum columns
  group_col <- NULL
  sum_cols <- c()
  
  if (dataset_name %in% c("ds21969")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month", "day"))
  
  # Perform yearly aggregation
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      mutate(year = as.integer(year))
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      mutate(year = as.integer(year))
  }
  
  return(df_yearly)
}

# -----------------------------
# Special aggregation for weather
# -----------------------------
aggregate_weather <- function(weather_df) {
  
  sum_cols <- c("precipitation_radolan", "precipitation_radolan_rain_days")
  mean_cols <- c(
    "rH_200", "rH_200_max", "rH_200_min",
    "SM_10", "SM_20",
    "Ta_10", "Ta_10_max", "Ta_10_min",
    "Ta_200", "Ta_200_max", "Ta_200_min",
    "Ts_05", "Ts_05_max", "Ts_05_min",
    "Ts_10", "Ts_10_max", "Ts_10_min",
    "Ts_20", "Ts_20_max", "Ts_20_min",
    "Ts_50", "Ts_50_max", "Ts_50_min"
  )
  
  # Step 1: Aggregate per plot
  weather_annual <- weather_df %>%
    group_by(plotID, year) %>%
    summarise(
      region = first(region),
      across(all_of(sum_cols), sum, na.rm = TRUE),
      across(all_of(mean_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
  # Step 2: Aggregate per region
  weather_region <- weather_annual %>%
    group_by(region, year) %>%
    summarise(
      across(all_of(sum_cols), mean, na.rm = TRUE),  # Average sum columns
      across(all_of(mean_cols), mean, na.rm = TRUE), # Average mean columns
      .groups = "drop"
    ) %>%
    mutate(year = as.integer(year))
  
  return(weather_region)
}

# -----------------------------
# Year range for ds21969
# -----------------------------
years_ds21969 <- range(as.integer(ds21969$year), na.rm = TRUE)

# -----------------------------
# Aggregate all datasets yearly
# -----------------------------
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    aggregate_weather(data_list[[name]])
  } else {
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# -----------------------------
# Filter datasets to ds21969 years
# -----------------------------
data_for_ds21969 <- lapply(
  data_yearly,
  function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2])
)

# -----------------------------
# Ensure all years are integer
# -----------------------------
data_for_ds21969 <- lapply(data_for_ds21969, function(df) {
  if("year" %in% names(df)) df$year <- as.integer(df$year)
  df
})

################################SORT each data set#################################
###build new list
data_for_ds21969_stationary <- list()

#put in SMI 
data_for_ds21969_stationary$SMI_total <- data_for_ds21969$SMI_total

# -----------------------------
# Detrend Function
# -----------------------------
detrend_ts <- function(df, cols) {
  for (col in cols) {
    if (col %in% names(df)) {
      fit <- stats::lm(df[[col]] ~ df$year)
      df[[col]] <- df[[col]] - fit$fitted.values
    }
  }
  df
}

# -----------------------------
# Differencing Function
# -----------------------------
diff_ts <- function(df, cols) {
  for (col in cols) {
    if (col %in% names(df)) {
      df[[col]] <- c(NA, diff(df[[col]]))
    }
  }
  df
}

# -----------------------------
# Detrend + Differencing
# -----------------------------
detrend_diff_ts <- function(df, cols) {
  for (col in cols) {
    if (col %in% names(df)) {
      fit <- stats::lm(df[[col]] ~ df$year)
      detrended <- df[[col]] - fit$fitted.values
      df[[col]] <- c(NA, diff(detrended))
    }
  }
  df
}


##########SMI_total############
vars_both <- ds21969_both_yearly %>%
  filter(dataset == "SMI_total") %>%
  pull(variable)


df <- data_for_ds21969$SMI_total

# detrended + diff
df4 <- detrend_diff_ts(df, vars_both) %>%
  select(year, any_of(vars_both))


data_for_ds21969_stationary$SMI_total <- df4

#####SMI_upsoil###########

vars_smi_upsoil <- ds21969_stationary_yearly %>% 
  dplyr::filter(dataset == "SMI_upsoil") %>%
  dplyr::pull(variable) %>%
  unique()

SMI_upsoil_raw <- data_for_ds21969$SMI_upsoil

SMI_upsoil_stationary <- SMI_upsoil_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_smi_upsoil)
  )

data_for_ds21969_stationary$SMI_upsoil <- SMI_upsoil_stationary


########## NDVI_ALB ##########
vars_ndvi_alb <- ds21969_stationary_yearly %>%
  dplyr::filter(dataset == "NDVI_ALB") %>%
  dplyr::pull(variable) %>%
  unique()

NDVI_ALB_raw <- data_for_ds21969$NDVI_ALB

NDVI_ALB_stationary <- NDVI_ALB_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_ndvi_alb)
  )

data_for_ds21969_stationary$NDVI_ALB <- NDVI_ALB_stationary

########## NDVI_HAI ##########
vars_ndvi_hai <- ds21969_stationary_yearly %>%
  dplyr::filter(dataset == "NDVI_HAI") %>%
  dplyr::pull(variable) %>%
  unique()

NDVI_HAI_raw <- data_for_ds21969$NDVI_HAI

NDVI_HAI_stationary <- NDVI_HAI_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_ndvi_hai)
  )

data_for_ds21969_stationary$NDVI_HAI <- NDVI_HAI_stationary

########## NDVI_SCH ##########
vars_ndvi_sch <- ds21969_stationary_yearly %>%
  dplyr::filter(dataset == "NDVI_SCH") %>%
  dplyr::pull(variable) %>%
  unique()

NDVI_SCH_raw <- data_for_ds21969$NDVI_SCH

NDVI_SCH_stationary <- NDVI_SCH_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_ndvi_sch)
  )

data_for_ds21969_stationary$NDVI_SCH <- NDVI_SCH_stationary


########## NIRv_ALB ##########
vars_nirv_alb <- ds21969_stationary_yearly %>%
  dplyr::filter(dataset == "NIRv_ALB") %>%
  dplyr::pull(variable) %>%
  unique()

NIRv_ALB_raw <- data_for_ds21969$NIRv_ALB

NIRv_ALB_stationary <- NIRv_ALB_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_nirv_alb)
  )

data_for_ds21969_stationary$NIRv_ALB <- NIRv_ALB_stationary

########## NIRv_SCH ##########
vars_nirv_sch <- ds21969_stationary_yearly %>%
  dplyr::filter(dataset == "NIRv_SCH") %>%
  dplyr::pull(variable) %>%
  unique()

NIRv_SCH_raw <- data_for_ds21969$NIRv_SCH

NIRv_SCH_stationary <- NIRv_SCH_raw %>%
  dplyr::select(
    year,
    dplyr::any_of(vars_nirv_sch)
  )

data_for_ds21969_stationary$NIRv_SCH <- NIRv_SCH_stationary
###########mosaic######################

# Stationary variables for mosaic
stationary_mosaic <- ds21969_stationary_yearly %>%
  filter(dataset == "mosaic") %>%
  filter(status_adf == "stationary", status_kpss == "stationary") %>%
  select(variable, region)

# Raw data
mosaic_raw <- data_for_ds21969$mosaic

# Long format, filter, then back to wide
mosaic_stationary <- mosaic_raw %>%
  pivot_longer(cols = -c(year, region), names_to = "variable", values_to = "value") %>%
  semi_join(stationary_mosaic, by = c("variable", "region")) %>%
  pivot_wider(names_from = "variable", values_from = "value")

# Save result to the list
data_for_ds21969_stationary$mosaic <- mosaic_stationary


########weather#######################
# Stationary variables for weather
stationary_weather <- ds21969_stationary_yearly %>%
  filter(dataset == "weather") %>%
  filter(status_adf == "stationary", status_kpss == "stationary") %>%
  select(variable, region)

# Raw data
weather_raw <- data_for_ds21969$weather

# Long format, filter, then back to wide
weather_stationary <- weather_raw %>%
  pivot_longer(cols = -c(year, region), names_to = "variable", values_to = "value") %>%
  semi_join(stationary_weather, by = c("variable", "region")) %>%
  pivot_wider(names_from = "variable", values_from = "value")

# Save result to the list
data_for_ds21969_stationary$weather <- weather_stationary


########## Fertilization ##########
# -----------------------------
# Columns to be processed
# -----------------------------
cols_to_transform <- c("ALB", "HAI", "SCH")

# -----------------------------
# Filter stationary
# -----------------------------
fert_stationary <- data_for_ds21969$Fertilization %>%
  semi_join(
    ds21969_stationary_yearly %>% 
      filter(variable %in% cols_to_transform),
    by = c("Croptype", "Fertilizer")
  )

# -----------------------------
# Filter both and process
# -----------------------------
fert_both <- data_for_ds21969$Fertilization %>%
  semi_join(
    ds21969_both_yearly %>% 
      filter(variable %in% cols_to_transform),
    by = c("Croptype", "Fertilizer")
  )

# detrended + differenced on the selected columns
fert_both <- detrend_diff_ts(fert_both, cols_to_transform)

# -----------------------------
# Merge
# -----------------------------
fert_final <- bind_rows(
  fert_stationary,
  fert_both
) %>%
  arrange(Croptype, Fertilizer, year)

# -----------------------------
# Save to the list
# -----------------------------
data_for_ds21969_stationary$Fertilization <- fert_final

#########ds21969####################
# Subset for detrended
subset_detrended <- semi_join(
  data_for_ds21969$ds21969,
  ds21969_detrended_yearly %>% filter(dataset == "ds21969", variable == "NumberAdults"),
  by = c("Exploratory", "Family") # only these two, because year is identical in both
)

if(nrow(subset_detrended) > 0){
  subset_detrended <- detrend_diff_ts(subset_detrended, cols = c("NumberAdults"))
} else {
  warning("No rows for detrended available – skipped")
}

# Subset for differenced
subset_diff <- semi_join(
  data_for_ds21969$ds21969,
  ds21969_differenced_yearly %>% filter(dataset == "ds21969", variable == "NumberAdults"),
  by = c("Exploratory", "Family")
)

if(nrow(subset_diff) > 0){
  subset_diff <- detrend_diff_ts(subset_diff, cols = c("NumberAdults"))
} else {
  warning("No rows for differenced available – skipped")
}

# Stationary remains unchanged
subset_stationary <- semi_join(
  data_for_ds21969$ds21969,
  ds21969_stationary_yearly %>% filter(dataset == "ds21969", variable == "NumberAdults"),
  by = c("Exploratory", "Family")
)

# Result into the list
data_for_ds21969_stationary$ds21969 <- bind_rows(
  subset_stationary,
  subset_detrended,
  subset_diff
)

#########################################################################
# Build lists

# Determine per dataset how many new families need to be added to the family list

# data_for_ds21969 is the original list for the Granger causality analysis
# Columns from other dataset lists need to be added to these datasets
# How can this be done?

# Originally, Granger tests were performed on regionally separated lists, as in
# script "granger_causality_test_251111"

######## PREPARE FOR FURTHER FILTERING - ds21969  - YEARLY ######
############################################################################

############ ds21969 #######################################################
# Take stationary results from pre-tests, keep only stationary time-series in the list




###################### ds21969 #########################################
# Create sub-lists per region

# ---------------------------------------------------------------
# 1. SMI_upsoil for ALB
# ---------------------------------------------------------------
smi_alb <- data_for_ds21969_stationary$SMI_upsoil %>% dplyr::select(year, ALB)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv for ALB
# ---------------------------------------------------------------
ndvi_alb <- data_for_ds21969_stationary$NDVI_ALB
nirv_alb <- data_for_ds21969_stationary$NIRv_ALB

# ---------------------------------------------------------------
# 3. Fertilization for ALB
# ---------------------------------------------------------------
fert_alb <- data_for_ds21969_stationary$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, ALB)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for ALB
# ---------------------------------------------------------------
mosaic_alb <- data_for_ds21969_stationary$mosaic %>% filter(region == "ALB")
weather_alb <- data_for_ds21969_stationary$weather %>% filter(region == "ALB")

# ---------------------------------------------------------------
# 5. ds21969 for ALB
# ---------------------------------------------------------------
ds21969_alb <- data_for_ds21969_stationary$ds21969 %>% filter(Exploratory == "ALB")

# ---------------------------------------------------------------
# 6. Create sub-list for ALB
# ---------------------------------------------------------------
ds21969_stationary_ALB <- list(
  smi_upsoil = smi_alb,
  NDVI = ndvi_alb,
  NIRv = nirv_alb,
  Fertilization = fert_alb,
  mosaic = mosaic_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

# Optional: check
names(ds21969_stationary_ALB)
lapply(ds21969_stationary_ALB, names)

############ ds21969 - sort for HAI ###############################################

# ---------------------------------------------------------------
# 1. SMI_upsoil for HAI
# ---------------------------------------------------------------
smi_upsoil_hai <- data_for_ds21969_stationary$SMI_upsoil %>% dplyr::select(year, HAI)
smi_total_hai <- data_for_ds21969_stationary$SMI_total %>% dplyr::select(year, HAI)
# ---------------------------------------------------------------
# 2. NDVI, NIRv for HAI
# ---------------------------------------------------------------
ndvi_hai <- data_for_ds21969_stationary$NDVI_HAI

# ---------------------------------------------------------------
# 2. Fertilization for HAI
# ---------------------------------------------------------------
fert_hai <- data_for_ds21969_stationary$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, HAI)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for HAI
# ---------------------------------------------------------------
mosaic_hai <- data_for_ds21969_stationary$mosaic %>% filter(region == "HAI")
weather_hai <- data_for_ds21969_stationary$weather %>% filter(region == "HAI")

# ---------------------------------------------------------------
# 4. ds21969 for HAI
# ---------------------------------------------------------------
ds21969_hai <- data_for_ds21969_stationary$ds21969 %>% filter(Exploratory == "HAI")

# ---------------------------------------------------------------
# 5. Create sub-list for HAI
# ---------------------------------------------------------------
ds21969_stationary_HAI <- list(
  smi_upsoil = smi_upsoil_hai,
  smi_total = smi_total_hai, 
  NDVI = ndvi_hai,
  NIRv = nirv_hai,
  Fertilization = fert_hai,
  mosaic = mosaic_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

# Optional: check
names(ds21969_stationary_HAI)
lapply(ds21969_stationary_HAI, names)

############ ds21969 - sort for SCH ###############################################

# ---------------------------------------------------------------
# 1. NDVI, NDMI, NIRv for SCH
# ---------------------------------------------------------------
ndvi_sch <- data_for_ds21969_stationary$NDVI_SCH
nirv_sch <- data_for_ds21969_stationary$NIRv_SCH

# ---------------------------------------------------------------
# 2. Fertilization for SCH
# ---------------------------------------------------------------
fert_sch <- data_for_ds21969_stationary$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, SCH)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for SCH
# ---------------------------------------------------------------
mosaic_sch <- data_for_ds21969_stationary$mosaic %>% filter(region == "SCH")
weather_sch <- data_for_ds21969_stationary$weather %>% filter(region == "SCH")

# ---------------------------------------------------------------
# 4. ds21969 for SCH
# ---------------------------------------------------------------
ds21969_sch <- data_for_ds21969_stationary$ds21969 %>% filter(Exploratory == "SCH")

# ---------------------------------------------------------------
# 5. Create sub-list for SCH
# ---------------------------------------------------------------
ds21969_stationary_SCH <- list(
  Fertilization = fert_sch,
  mosaic = mosaic_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch,
  ndvi_sch = ndvi_sch,
  nirv_sch = nirv_sch
)

# Optional: check
names(ds21969_stationary_SCH)
lapply(ds21969_stationary_SCH, names)

################## GRANGER ANALYSIS ######################
################ DS21969_ALB_YEARLY ######################
ds21969_stationary_ALB$ds21969
# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(ds21969_stationary_ALB$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe for ds21969_stationary_ALB
# -----------------------------
get_insect_ts_df <- function(fam) {
  ds21969_stationary_ALB$ds21969 %>%
    filter(Family == fam) %>%     # filtere nach Insektenfamilie
    arrange(year) %>%             # sortiere nach Jahr
    dplyr::select(year, NumberAdults) %>%  # wähle Jahr und Zahl der Erwachsenen
    rename(NumberAdults_use = NumberAdults) # einheitlicher Name für Granger-Funktion
}

# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, ds21969_stationary_ALB$smi_upsoil, "ALB")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_upsoil",
           EnvColumn = "ALB",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(ds21969_stationary_ALB$NDVI, "NDVI", "mean_NDVI")
results_nirv <- run_granger_env_vars(ds21969_stationary_ALB$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 3. Fertilization (ALB)
# -----------------------------
fert_data <- ds21969_stationary_ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, ALB_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "ALB") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = ds21969_stationary_ALB$mosaic,
  weather = ds21969_stationary_ALB$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 5. ALB_crop
# -----------------------------
alb_crop <- ds21969_stationary_ALB$ALB_crop

results_crop <- map_dfr(unique(alb_crop$var), function(varname) {
  map_dfr(unique(alb_crop$measure), function(measurename) {
    subset_data <- alb_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "ALB_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_ALB <- bind_rows(
  results_smi_upsoil,
  results_ndvi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_ALB

results_ALB$causality <- with(results_ALB,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_ALB, "./tables/granger_test/results_ds21969_ALB_2nd_round.csv", row.names = FALSE)


################## GRANGER ANALYSIS ######################
################ DS21969_HAI_YEARLY ######################

# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(ds21969_stationary_HAI$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  ds21969_stationary_HAI$ds21969 %>%
    filter(Family == fam) %>%     # filter for family
    arrange(year) %>%             # sort for year 
    dplyr::select(year, NumberAdults) %>%  # select year and Number of Adults 
    rename(NumberAdults_use = NumberAdults) 
}
# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_SMI_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, ds21969_stationary_HAI$smi_upsoil, "HAI")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_upsoil",
           EnvColumn = "HAI",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, ds21969_stationary_HAI$smi_total, "HAI")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_total",
           EnvColumn = "HAI",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(ds21969_stationary_HAI$NDVI, "NDVI", "mean_NDVI")

# -----------------------------
# 3. Fertilization (HAI)
# -----------------------------
fert_data <- ds21969_stationary_HAI$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(HAI_list = list(HAI), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, HAI_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "HAI") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = ds21969_stationary_HAI$mosaic,
  weather = ds21969_stationary_HAI$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})


# -----------------------------
# 6. Combine all results
# -----------------------------
results_HAI <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_fert,
  results_mw
)

results_HAI

results_HAI$causality <- with(results_HAI,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_HAI, "./tables/granger_test/results_ds21969_HAI_2nd_round.csv", row.names = FALSE)


########################### SCH ##################################
################## GRANGER ANALYSIS ##############################

# -----------------------------
# 1. List of families & lags
# -----------------------------
families <- unique(ds21969_stationary_SCH$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Extract insect time series as dataframe
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}



# -----------------------------
# 3. Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 6. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(ds21969_stationary_SCH$ndvi_sch, "ndvi", "mean_NDVI")
results_nirv <- run_granger_env_vars(ds21969_stationary_SCH$nirv_sch, "nirv", "mean_NIRv")

# -----------------------------
# 7. Fertilization (SCH)
# -----------------------------
fert_data <- ds21969_stationary_SCH$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(SCH_list = list(SCH), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, SCH_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "SCH") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 8. Mosaic & Weather
# -----------------------------

run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = ds21969_stationary_SCH$mosaic,
  weather = ds21969_stationary_SCH$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 10. Combine all results & label causality
# -----------------------------
results_SCH <- bind_rows(
  results_ndvi,
  results_nirv,
  results_fert,
  results_mw,
)

results_SCH

results_SCH$causality <- with(results_SCH,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_SCH, "./tables/granger_test/results_ds21969_SCH_2nd_round.csv", row.names = FALSE)

