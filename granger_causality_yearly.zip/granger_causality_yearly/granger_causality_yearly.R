############## GRANGER CAUSALITY TEST #######################
# 1. Load datasets and standardize relevant columns
# 2. Perform Granger causality tests

################### Load packages ###########################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries)

#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Crop yield and area data
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


# Load previously computed ADF/KPSS results
stationarity_table_ds21969 <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_yearly.csv", sep =",")
stationarity_table_ds22007 <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_yearly.csv", sep =",")

############################## Organize datasets for easier handling ##########################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, NDVI_HAI = NDVI_HAI, NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB, NDMI_HAI = NDMI_HAI, NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB, NIRv_HAI = NIRv_HAI, NIRv_SCH = NIRv_SCH,
  Fertilization = Fertilization, 
  mosaic = mosaic, 
  weather = weather, 
  ALB_crop = ALB_crop, HAI_crop = HAI_crop, SCH_crop = SCH_crop, 
  ds21969 = ds21969, ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped", group_cols = c("Croptype", "Fertilizer"), value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type = "grouped", group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type = "grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

######################################################################
# Function: Aggregate datasets on a yearly basis
aggregate_yearly <- function(df, dataset_name) {
  
  # ---------------------------
  # 1. Filter for seasonal datasets (NDVI, NDWI, NirV)
  # Only keep months April (4) to October (10)
  # ---------------------------
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NirV_ALB", "NirV_HAI", "NirV_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
  # ---------------------------
  # 2. Special handling for crop datasets
  # ---------------------------
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
                  .groups = "drop")
    )
  }
  
  # ---------------------------
  # 3. Define grouping and aggregation columns
  # ---------------------------
  group_col <- NULL
  sum_cols <- c()
  
  # Insect datasets: sum adults, grouped by Exploratory & Family
  if (dataset_name %in% c("ds21969","ds22007")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  # Fertilization and mosaic datasets
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  # Columns to average (exclude year, grouping, sum, month/day)
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # ---------------------------
  # 4. Aggregate other datasets
  # ---------------------------
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################
# Special aggregation for the weather dataset (per plot → per region)
aggregate_weather <- function(weather_df) {
  
  sum_cols <- c("precipitation_radolan", "precipitation_radolan_rain_days")
  mean_cols <- c(
    "rH_200", "rH_200_max", "rH_200_min",
    "SM_10", "SM_20",
    "Ta_10", "Ta_10_max", "Ta_10_min",
    "Ta_200", "Ta_200_max", "Ta_200_min",
    "Ts_05", "Ts_05_max", "Ts_05_min",
    "Ts_10", "Ts_10_max", "Ts_10_min",
    "Ts_20", "Ts_20_max", "Ts_20_min",
    "Ts_50", "Ts_50_max", "Ts_50_min"
  )
  
  # Step 1: Aggregate per plot
  weather_annual <- weather_df %>%
    group_by(plotID, year) %>%
    summarise(
      region = first(region),
      across(all_of(sum_cols), sum, na.rm = TRUE),
      across(all_of(mean_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
  # Step 2: Aggregate per region
  weather_region <- weather_annual %>%
    group_by(region, year) %>%
    summarise(
      across(all_of(sum_cols), mean, na.rm = TRUE),  # Average the sum columns
      across(all_of(mean_cols), mean, na.rm = TRUE), # Average the mean columns
      .groups = "drop"
    )
  
  return(weather_region)
}

######################################################################
# 4. Prepare yearly aggregated data for insect datasets ds21969 and ds22007

# Determine the year ranges of each insect dataset
years_ds21969 <- range(ds21969$year, na.rm = TRUE)
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

# Aggregate all datasets on a yearly basis
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    # Use the special weather aggregation
    aggregate_weather(data_list[[name]])
  } else {
    # Use the aggregation function for other datasets
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# Filter datasets to the corresponding year ranges for each insect dataset
data_for_ds21969 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2]))
data_for_ds22007 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds22007[1], year <= years_ds22007[2]))

# Remove the other insect dataset from each list to avoid duplication
data_for_ds21969 <- data_for_ds21969[!names(data_for_ds21969) %in% c("ds22007")]
data_for_ds22007 <- data_for_ds22007[!names(data_for_ds22007) %in% c("ds21969")]

################## Filter only stationary datasets #################
ds21969_stationary <- stationarity_table_ds21969 %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_stationary <- stationarity_table_ds22007 %>%
  filter(status_adf == "stationary", status_kpss == "stationary")


########################## GRANGER TEST ####################################
############################################################################

############ ds21969 #######################################################
### Keep only stationary time-series from pre-tests, create list of stationary datasets for ds21969 

# -------------------------------------------------------------------
# Function: filter ds21969 dataset, remove region column for certain datasets
# -------------------------------------------------------------------
filter_ds21969_dataset <- function(df, dataset_name, overview_ds21969) {
  
  # Check if dataset exists in overview
  if(!dataset_name %in% unique(overview_ds21969$dataset)) return(NULL)
  
  # Allowed variables according to overview
  allowed_columns <- overview_ds21969 %>%
    dplyr::filter(dataset == dataset_name) %>%
    dplyr::pull(variable)
  
  # Automatically keep grouping columns
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Combine all columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  # Reduce DataFrame to these columns
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter rows: only keep allowed values in grouping columns, keep year intact
  for(col in setdiff(existing_group_cols, "year")){
    allowed_values <- overview_ds21969 %>%
      dplyr::filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      dplyr::pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI, NDMI, NIRv datasets
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")){
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Filter entire ds21969 list
# -------------------------------------------------------------------
filtered_ds21969_list <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_dataset(df, name, ds21969_stationary)
})
filtered_ds21969_list <- filtered_ds21969_list[!sapply(filtered_ds21969_list, is.null)]


#################### ds22007 ###########################################

# -------------------------------------------------------------------
# Function: filter ds22007 dataset, remove region column for certain datasets
# -------------------------------------------------------------------
filter_ds22007_dataset <- function(df, dataset_name, overview_ds22007) {
  
  # Check if dataset exists in overview
  if(!dataset_name %in% unique(overview_ds22007$dataset)) return(NULL)
  
  # Allowed variables according to overview
  allowed_columns <- overview_ds22007 %>%
    dplyr::filter(dataset == dataset_name) %>%
    dplyr::pull(variable)
  
  # Automatically keep grouping columns
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Combine all columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  # Reduce DataFrame to these columns
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter rows: only keep allowed values in grouping columns, keep year intact
  for(col in setdiff(existing_group_cols, "year")){
    allowed_values <- overview_ds22007 %>%
      dplyr::filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      dplyr::pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% dplyr::filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI, NDMI, NIRv datasets (if relevant)
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")){
    df_filtered <- df_filtered %>% dplyr::select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Filter entire ds22007 list
# -------------------------------------------------------------------
filtered_ds22007_list <- imap(data_for_ds22007, function(df, name){
  filter_ds22007_dataset(df, name, ds22007_stationary)
})
filtered_ds22007_list <- filtered_ds22007_list[!sapply(filtered_ds22007_list, is.null)]

# -------------------------------------------------------------------
# Example: inspect filtered ds22007 dataset
# -------------------------------------------------------------------
filtered_ds22007_list$ds22007

###################### GRANGER ANALYSIS ################################
########################################################################
###################### ds21969 #########################################

# ---------------------------------------------------------------
# 1. SMI_upsoil
# ---------------------------------------------------------------
smi_alb <- filtered_ds21969_list$SMI_upsoil %>% dplyr::select(year, ALB)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv
# ---------------------------------------------------------------
ndvi_alb <- filtered_ds21969_list$NDVI_ALB
nirv_alb <- filtered_ds21969_list$NIRv_ALB

# ---------------------------------------------------------------
# 3. Fertilization ALB
# ---------------------------------------------------------------
fert_alb <- filtered_ds21969_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, ALB)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for ALB
# ---------------------------------------------------------------
mosaic_alb <- filtered_ds21969_list$mosaic %>% filter(region == "ALB")
weather_alb <- filtered_ds21969_list$weather %>% filter(region == "ALB")

# ---------------------------------------------------------------
# 5. ds21969 for ALB
# ---------------------------------------------------------------
ds21969_alb <- filtered_ds21969_list$ds21969 %>% filter(Exploratory == "ALB")

# ---------------------------------------------------------------
# 6. Create sub-list for ALB
# ---------------------------------------------------------------
ds21969_stationary_ALB <- list(
  SMI_upsoil = smi_alb,
  NDVI = ndvi_alb,
  NIRv = nirv_alb,
  Fertilization = fert_alb,
  mosaic = mosaic_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

# Optional: inspect
names(ds21969_stationary_ALB)
lapply(ds21969_stationary_ALB, names)


####################### DS21969 - ALB, Granger Analysis, lags = 1-3 ###############
################### COMPLETE GRANGER TEST: DS21969 - MULTIPLE LAGS #################

# -----------------------------
# 0. Safe Granger test for multiple lags
# -----------------------------
granger_safe_lags <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(na.omit(y)) < 2 || var(y, na.rm = TRUE) == 0) {
      tibble(Lag = lag, F_stat = NA, p_value = NA)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA, p_value = NA))
    }
  })
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_stationary_ALB$ds21969$Family)
lags <- c(1, 2, 3)  # Specify desired lag values

# -----------------------------
# 2. SMI_upsoil
# -----------------------------
results_smi <- map_dfr(families, function(fam) {
  insect_ts <- ds21969_stationary_ALB$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    pull(NumberAdults)
  
  env_ts <- ds21969_stationary_ALB$SMI_upsoil$ALB
  
  res <- granger_safe_lags(insect_ts, env_ts, lags = lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "ALB",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. NDVI, NDMI, NIRv
# -----------------------------
env_vars <- list(
  NDVI = ds21969_stationary_ALB$NDVI$mean_NDVI,
  NIRv = ds21969_stationary_ALB$NIRv$mean_NIRv
)

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_ts <- ds21969_stationary_ALB$ds21969 %>%
      filter(Family == fam) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- env_vars[[varname]]
    
    res <- granger_safe_lags(insect_ts, env_ts, lags = lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = varname,
        EnvColumn = varname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 4. Fertilization (ALB), including Croptype + Fertilizer
# -----------------------------
fert_data <- ds21969_stationary_ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_ts <- ds21969_stationary_ALB$ds21969 %>%
      filter(Family == Family) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- ALB_list[[1]]
    
    if(all(is.na(env_ts)) || length(na.omit(env_ts)) < 2 || var(env_ts, na.rm = TRUE) == 0) {
      tibble(Lag = lags, F_stat = NA, p_value = NA)
    } else {
      granger_safe_lags(insect_ts, env_ts, lags = lags)
    }
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(
    EnvDataset = "Fertilization",
    EnvColumn = "ALB"
  ) %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 5. Mosaic & Weather (drop region)
# -----------------------------
mosaic_weather <- list(
  mosaic = ds21969_stationary_ALB$mosaic %>% dplyr::select(-year, -region),
  weather = ds21969_stationary_ALB$weather %>% dplyr::select(-year, -region)
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]]), function(colname) {
    map_dfr(families, function(fam) {
      insect_ts <- ds21969_stationary_ALB$ds21969 %>%
        filter(Family == fam) %>%
        arrange(year) %>%
        pull(NumberAdults)
      
      env_ts <- mosaic_weather[[dsname]][[colname]]
      
      res <- granger_safe_lags(insect_ts, env_ts, lags = lags)
      
      res %>%
        mutate(
          Family = fam,
          EnvDataset = dsname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_ds21969_ALB <- bind_rows(
  results_smi,
  results_env,
  results_fert,
  results_mw
)

# Result
results_ds21969_ALB 

#################################################################################
############ ds21969 - subset for HAI ###########################################

# ---------------------------------------------------------------
# 1. SMI_upsoil
# ---------------------------------------------------------------
smi_hai <- filtered_ds21969_list$SMI_upsoil %>% dplyr::select(year, HAI)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv
# ---------------------------------------------------------------
ndvi_hai <- filtered_ds21969_list$NDVI_HAI
nirv_hai <- filtered_ds21969_list$NIRv_HAI

# ---------------------------------------------------------------
# 3. Fertilization HAI
# ---------------------------------------------------------------
fert_hai <- filtered_ds21969_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, HAI)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for HAI
# ---------------------------------------------------------------
mosaic_hai <- filtered_ds21969_list$mosaic %>% filter(region == "HAI")
weather_hai <- filtered_ds21969_list$weather %>% filter(region == "HAI")

# ---------------------------------------------------------------
# 5. ds21969 for HAI 
# ---------------------------------------------------------------
ds21969_hai <- filtered_ds21969_list$ds21969 %>% filter(Exploratory == "HAI")

# ---------------------------------------------------------------
# 5. Create sub-list for HAI
# ---------------------------------------------------------------
ds21969_stationary_HAI <- list(
  SMI_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NIRv = nirv_hai,
  Fertilization = fert_hai,
  mosaic = mosaic_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

# optional: inspect
names(ds21969_stationary_HAI)

lapply(ds21969_stationary_HAI, names)

#################################################################################
############### GRANGER-CAUSALITY ANALYSIS — DS21969 (Region = HAI) #############
#################################################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y))) 
    return(tibble(F_stat = NA, p_value = NA))
  if (var(y, na.rm = TRUE) == 0)
    return(tibble(F_stat = NA, p_value = NA))
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
  }, error = function(e) tibble(F_stat = NA, p_value = NA))
}

# -----------------------------
# 1. Parameters
# -----------------------------
lags <- 1:3
families <- unique(ds21969_stationary_HAI$ds21969$Family)

# -----------------------------
# 2. SMI_upsoil
# -----------------------------
results_smi <- map_dfr(families, function(fam) {
  insect_ts <- ds21969_stationary_HAI$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    pull(NumberAdults)
  
  env_ts <- ds21969_stationary_HAI$SMI_upsoil$HAI
  
  map_dfr(lags, function(lag) {
    res <- granger_safe(insect_ts, env_ts, lag = lag)
    tibble(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "HAI",
      lag = lag,
      F_stat = res$F_stat,
      p_value = res$p_value,
      Croptype = NA_character_,
      Fertilizer = NA_character_
    )
  })
})

# -----------------------------
# 3. NDVI, NDMI, NIRv
# -----------------------------
env_vars <- list(
  NDVI = ds21969_stationary_HAI$NDVI$mean_NDVI,
  NIRv = ds21969_stationary_HAI$NIRv$mean_NIRv
)

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_ts <- ds21969_stationary_HAI$ds21969 %>%
      filter(Family == fam) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- env_vars[[varname]]
    
    res <- granger_safe_lags(insect_ts, env_ts, lags = lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = varname,
        EnvColumn = varname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 4. Fertilization (HAI)
# -----------------------------
fert_data <- ds21969_stationary_HAI$Fertilization

results_fert <- crossing(
  Croptype = unique(fert_data$Croptype),
  Fertilizer = unique(fert_data$Fertilizer),
  Family = families,
  lag = lags
) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_ts <- ds21969_stationary_HAI$ds21969 %>%
      filter(Family == Family) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- fert_data %>%
      filter(Croptype == Croptype, Fertilizer == Fertilizer) %>%
      arrange(year) %>%
      pull(HAI)
    
    if (length(env_ts) < lag + 1 || var(env_ts, na.rm = TRUE) < 1e-5) {
      tibble(F_stat = NA, p_value = NA)
    } else {
      granger_safe(insect_ts, env_ts, lag = lag)
    }
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "HAI") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, lag, F_stat, p_value)

# -----------------------------
# 5. Mosaic & Weather
# -----------------------------
mosaic_weather <- list(
  mosaic = ds21969_stationary_HAI$mosaic %>% dplyr::select(-year, -region),
  weather = ds21969_stationary_HAI$weather %>% dplyr::select(-year, -region)
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]]), function(colname) {
    map_dfr(families, function(fam) {
      insect_ts <- ds21969_stationary_HAI$ds21969 %>%
        filter(Family == fam) %>%
        arrange(year) %>%
        pull(NumberAdults)
      
      env_ts <- mosaic_weather[[dsname]][[colname]]
      
      map_dfr(lags, function(lag) {
        res <- granger_safe(insect_ts, env_ts, lag = lag)
        tibble(
          Family = fam,
          EnvDataset = dsname,
          EnvColumn = colname,
          lag = lag,
          F_stat = res$F_stat,
          p_value = res$p_value,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        )
      })
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_ds21969_HAI <- bind_rows(
  results_smi,
  results_env,
  results_fert,
  results_mw
)

# -----------------------------
# 7. Overview
# -----------------------------
head(results_ds21969_HAI)

#################################################################################
############ ds21969 - subset for SCH ###########################################


# ---------------------------------------------------------------
# 1. NDVI, NDMI, NIRv
# ---------------------------------------------------------------
ndvi_sch <- filtered_ds21969_list$NDVI_SCH
nirv_sch <- filtered_ds21969_list$NIRv_SCH

# ---------------------------------------------------------------
# 2. Fertilization SCH
# ---------------------------------------------------------------
fert_sch <- filtered_ds21969_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, SCH)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for SCH
# ---------------------------------------------------------------
mosaic_sch <- filtered_ds21969_list$mosaic %>% filter(region == "SCH")
weather_sch <- filtered_ds21969_list$weather %>% filter(region == "SCH")

# ---------------------------------------------------------------
# 4. ds21969 for SCH 
# ---------------------------------------------------------------
ds21969_sch <- filtered_ds21969_list$ds21969 %>% filter(Exploratory == "SCH")

# ---------------------------------------------------------------
# 5. Create sub-list for SCH
# ---------------------------------------------------------------
ds21969_stationary_SCH <- list(
  
  Fertilization = fert_sch,
  NDVI = ndvi_sch,
  NIRv = nirv_sch,
  mosaic = mosaic_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch
)

# optional: inspect
names(ds21969_stationary_SCH)

lapply(ds21969_stationary_SCH, names)

#################################################################################
############### GRANGER-CAUSALITY ANALYSIS — DS21969 (Region = SCH) #############
#################################################################################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y))) 
    return(tibble(F_stat = NA, p_value = NA))
  if (var(y, na.rm = TRUE) == 0)
    return(tibble(F_stat = NA, p_value = NA))
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
  }, error = function(e) tibble(F_stat = NA, p_value = NA))
}

# -----------------------------
# 1. Define parameters
# -----------------------------
lags <- 1:3
families <- unique(ds21969_stationary_SCH$ds21969$Family)

# -----------------------------
# 2. Granger test for NDVI, NDMI, NIRv
# -----------------------------
env_vars <- list(
  NDVI = filtered_ds21969_list$NDVI_SCH$mean_NDVI,
  NIRv = filtered_ds21969_list$NIRv_SCH$mean_NIRv
)

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_ts <- ds21969_stationary_SCH$ds21969 %>%
      filter(Family == fam) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- env_vars[[varname]]
    
    map_dfr(lags, function(lag) {
      res <- granger_safe(insect_ts, env_ts, lag = lag)
      tibble(
        Family = fam,
        EnvDataset = varname,
        EnvColumn = varname,
        lag = lag,
        F_stat = res$F_stat,
        p_value = res$p_value,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      )
    })
  })
})

# -----------------------------
# 3. Granger test for Fertilization (SCH)
# -----------------------------
fert_data <- ds21969_stationary_SCH$Fertilization

results_fert <- crossing(
  Croptype = unique(fert_data$Croptype),
  Fertilizer = unique(fert_data$Fertilizer),
  Family = families,
  lag = lags
) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_ts <- ds21969_stationary_SCH$ds21969 %>%
      filter(Family == Family) %>%
      arrange(year) %>%
      pull(NumberAdults)
    
    env_ts <- fert_data %>%
      filter(Croptype == Croptype, Fertilizer == Fertilizer) %>%
      arrange(year) %>%
      pull(SCH)
    
    if (length(env_ts) < lag + 1 || var(env_ts, na.rm = TRUE) < 1e-5) {
      tibble(F_stat = NA, p_value = NA)
    } else {
      granger_safe(insect_ts, env_ts, lag = lag)
    }
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "SCH") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, lag, F_stat, p_value)

# -----------------------------
# 4. Granger test for Mosaic & Weather
# -----------------------------
mosaic_weather <- list(
  mosaic = ds21969_stationary_SCH$mosaic %>% 
    dplyr::select(dendrites, relation),
  weather = ds21969_stationary_SCH$weather %>% 
    dplyr::select(-year, -region)
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]]), function(colname) {
    map_dfr(families, function(fam) {
      insect_ts <- ds21969_stationary_SCH$ds21969 %>%
        filter(Family == fam) %>%
        arrange(year) %>%
        pull(NumberAdults)
      
      env_ts <- mosaic_weather[[dsname]][[colname]]
      
      map_dfr(lags, function(lag) {
        res <- granger_safe(insect_ts, env_ts, lag = lag)
        tibble(
          Family = fam,
          EnvDataset = dsname,
          EnvColumn = colname,
          lag = lag,
          F_stat = res$F_stat,
          p_value = res$p_value,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        )
      })
    })
  })
})

# -----------------------------
# 5. Combine all results
# -----------------------------
results_ds21969_SCH <- bind_rows(
  results_env,
  results_fert,
  results_mw
)
results_ds21969_SCH

# -----------------------------
# 6. Overview
# -----------------------------
head(results_ds21969_SCH)


############### WHICH TIME-SERIES OF DS21969 ARE GRANGER-CAUSAL? #################

# ---------------------------------------------------------------
# Label causality in all result datasets
# ---------------------------------------------------------------
mark_causality <- function(df, alpha = 0.05) {
  df %>%
    mutate(
      causal_label = case_when(
        is.na(p_value) ~ "no_test",
        p_value < alpha ~ "causal",
        TRUE ~ "non-causal"
      )
    )
}

# Apply to all three result datasets
results_ds21969_ALB <- mark_causality(results_ds21969_ALB)
results_ds21969_HAI <- mark_causality(results_ds21969_HAI)
results_ds21969_SCH <- mark_causality(results_ds21969_SCH)

# Optional: summary of counts
cat("=== Causality Summary ===\n")
list(
  ALB = table(results_ds21969_ALB$causal_label, useNA = "ifany"),
  HAI = table(results_ds21969_HAI$causal_label, useNA = "ifany"),
  SCH = table(results_ds21969_SCH$causal_label, useNA = "ifany")
)

write.csv(results_ds21969_ALB, "./tables/granger_test/results_ds21969_ALB.csv", row.names = FALSE)
write.csv(results_ds21969_HAI, "./tables/granger_test/results_ds21969_HAI.csv", row.names = FALSE)
write.csv(results_ds21969_SCH, "./tables/granger_test/results_ds21969_SCH.csv", row.names = FALSE)

##################################################################################
############### GRANGER TEST DS22007 ############################################

############### FIRST SORT FOR 3 DIFFERENT REGIONS - ALB, HAI, SCH #################

# ---------------------------------------------------------------
# 1. SMI_upsoil for ALB
# ---------------------------------------------------------------
smi_alb <- filtered_ds22007_list$SMI_upsoil %>% dplyr::select(year, ALB)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv for ALB
# ---------------------------------------------------------------
ndvi_alb <- filtered_ds22007_list$NDVI_ALB
nirv_alb <- filtered_ds22007_list$NIRv_ALB

# ---------------------------------------------------------------
# 3. Fertilization ALB
# ---------------------------------------------------------------
fert_alb <- filtered_ds22007_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, ALB)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for ALB
# ---------------------------------------------------------------
mosaic_alb <- filtered_ds22007_list$mosaic %>% filter(region == "ALB")
weather_alb <- filtered_ds22007_list$weather %>% filter(region == "ALB")

# ---------------------------------------------------------------
# 5. ds22007 for ALB
# ---------------------------------------------------------------
ds22007_alb <- filtered_ds22007_list$ds22007 %>% filter(Exploratory == "ALB")

# ---------------------------------------------------------------
# 6. Create sub-list for ALB
# ---------------------------------------------------------------
ds22007_stationary_ALB <- list(
  SMI_upsoil = smi_alb,
  NDVI = ndvi_alb,
  NIRv = nirv_alb,
  Fertilization = fert_alb,
  mosaic = mosaic_alb,
  weather = weather_alb,
  ds22007 = ds22007_alb
)

# Optional: inspect
names(ds22007_stationary_ALB)

lapply(ds22007_stationary_ALB, names)

#################### DS22007 - SORT FOR HAI #######################################
#################################################################################

# ---------------------------------------------------------------
# 1. SMI_upsoil for HAI
# ---------------------------------------------------------------
smi_hai <- filtered_ds22007_list$SMI_upsoil %>% dplyr::select(year, HAI)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv for ALB
# ---------------------------------------------------------------
ndvi_hai <- filtered_ds22007_list$NDVI_HAI
nirv_hai <- filtered_ds22007_list$NIRv_HAI

# ---------------------------------------------------------------
# 2. Fertilization HAI
# ---------------------------------------------------------------
fert_hai <- filtered_ds22007_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, HAI)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for HAI
# ---------------------------------------------------------------
mosaic_hai <- filtered_ds22007_list$mosaic %>% filter(region == "HAI")
weather_hai <- filtered_ds22007_list$weather %>% filter(region == "HAI")

# ---------------------------------------------------------------
# 4. ds22007 for HAI
# ---------------------------------------------------------------
ds22007_hai <- filtered_ds22007_list$ds22007 %>% filter(Exploratory == "HAI")

# ---------------------------------------------------------------
# 5. Create sub-list for HAI
# ---------------------------------------------------------------
ds22007_stationary_HAI <- list(
  SMI_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NIRv = nirv_hai,
  Fertilization = fert_hai,
  mosaic = mosaic_hai,
  weather = weather_hai,
  ds22007 = ds22007_hai
)

# Optional: inspect
names(ds22007_stationary_HAI)

lapply(ds22007_stationary_HAI, names)


#################### SORT FOR SCH ##########################################

# ---------------------------------------------------------------
# 1. NDVI, NDMI, NIRv
# ---------------------------------------------------------------
ndvi_sch <- filtered_ds22007_list$NDVI_SCH
nirv_sch <- filtered_ds22007_list$NIRv_SCH

# ---------------------------------------------------------------
# 2. Fertilization SCH
# ---------------------------------------------------------------
fert_sch <- filtered_ds22007_list$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, SCH)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for SCH
# ---------------------------------------------------------------
mosaic_sch <- filtered_ds22007_list$mosaic %>% filter(region == "SCH")
weather_sch <- filtered_ds22007_list$weather %>% filter(region == "SCH")

# ---------------------------------------------------------------
# 4. ds22007 for SCH
# ---------------------------------------------------------------
ds22007_sch <- filtered_ds22007_list$ds22007 %>% filter(Exploratory == "SCH")

# ---------------------------------------------------------------
# 5. Create sub-list for SCH
# ---------------------------------------------------------------
ds22007_stationary_SCH <- list(
  Fertilization = fert_sch,
  NDVI = ndvi_sch,
  NIRv = nirv_sch,
  mosaic = mosaic_sch,
  weather = weather_sch,
  ds22007 = ds22007_sch
)

# Optional: inspect
names(ds22007_stationary_SCH)
lapply(ds22007_stationary_SCH, names)


######################### GRANGER TEST FOR DS22007 - ALB ##################
lags <- 1:3
families <- unique(ds22007_stationary_ALB$ds22007$Family)

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) < lag + 2 || length(y) < lag + 2) return(tibble(F_stat = NA, p_value = NA))
  if(var(x, na.rm = TRUE) == 0 || var(y, na.rm = TRUE) == 0) return(tibble(F_stat = NA, p_value = NA))
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
  }, error = function(e) tibble(F_stat = NA, p_value = NA))
}

# -----------------------------
# Helper function: align insect and env series by year
# -----------------------------
align_ts <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df %>% select(year, NumberAdults) %>% rename(insect = NumberAdults),
    env_df %>% select(year, all_of(env_col)) %>% rename(env = all_of(env_col)),
    by = "year"
  )
  df <- df %>% filter(!is.na(insect) & !is.na(env))
  list(insect = df$insect, env = df$env)
}

# -----------------------------
# 1. SMI_upsoil
# -----------------------------
results_smi <- map_dfr(families, function(fam) {
  insect_df <- ds22007_stationary_ALB$ds22007 %>%
    filter(Family == fam) %>% arrange(year)
  env_df <- ds22007_stationary_ALB$SMI_upsoil
  
  map_dfr(lags, function(lag) {
    ts <- align_ts(insect_df, env_df, "ALB")
    res <- granger_safe(ts$insect, ts$env, lag = lag)
    tibble(Family = fam,
           EnvDataset = "SMI_upsoil",
           EnvColumn = "ALB",
           lag = lag,
           F_stat = res$F_stat,
           p_value = res$p_value,
           Croptype = NA_character_,
           Fertilizer = NA_character_)
  })
})

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_df <- ds22007_stationary_ALB$ds22007 %>%
      filter(Family == fam) %>% arrange(year)
    env_df <- env_vars[[varname]]
    
    map_dfr(lags, function(lag) {
      ts <- align_ts(insect_df, env_df, paste0("mean_", varname))  # <- nur Spaltenname als String
      res <- granger_safe(ts$insect, ts$env, lag = lag)
      tibble(Family = fam,
             EnvDataset = varname,
             EnvColumn = paste0("mean_", varname),
             lag = lag,
             F_stat = res$F_stat,
             p_value = res$p_value,
             Croptype = NA_character_,
             Fertilizer = NA_character_)
    })
  })
})

# -----------------------------
# 3. Fertilization
# -----------------------------
fert_data <- ds22007_stationary_ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families, lag = lags) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- ds22007_stationary_ALB$ds22007 %>%
      filter(Family == Family) %>% arrange(year)
    env_df <- tibble(year = insect_df$year, ALB = ALB_list[[1]])
    ts <- align_ts(insect_df, env_df, "ALB")
    granger_safe(ts$insect, ts$env, lag = lag)
  })) %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "ALB") %>%
  select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
mosaic_weather <- list(
  mosaic = ds22007_stationary_ALB$mosaic,
  weather = ds22007_stationary_ALB$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]] %>% select(-year, -region)), function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- ds22007_stationary_ALB$ds22007 %>%
        filter(Family == fam) %>% arrange(year)
      env_df <- mosaic_weather[[dsname]] %>%
        select(year, all_of(colname)) %>% rename(env = all_of(colname))
      
      map_dfr(lags, function(lag) {
        ts <- align_ts(insect_df, env_df, "env")
        res <- granger_safe(ts$insect, ts$env, lag = lag)
        tibble(Family = fam,
               EnvDataset = dsname,
               EnvColumn = colname,
               lag = lag,
               F_stat = res$F_stat,
               p_value = res$p_value,
               Croptype = NA_character_,
               Fertilizer = NA_character_)
      })
    })
  })
})

# -----------------------------
# 5. Combine all results and mark causality
# -----------------------------
results_ds22007_ALB <- bind_rows(results_smi, results_env, results_fert, results_mw) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

head(results_ds22007_ALB)

######################### GRANGER TEST FOR DS22007 - HAI ##################
lags <- 1:3
families <- unique(ds22007_stationary_HAI$ds22007$Family)

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) < lag + 2 || length(y) < lag + 2) return(tibble(F_stat = NA, p_value = NA))
  if(var(y, na.rm = TRUE) == 0 || var(x, na.rm = TRUE) == 0) return(tibble(F_stat = NA, p_value = NA))
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
  }, error = function(e) tibble(F_stat = NA, p_value = NA))
}

# -----------------------------
# Helper function: align insect and env series by year
# -----------------------------
align_ts <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df %>% select(year, NumberAdults) %>% rename(insect = NumberAdults),
    env_df %>% select(year, all_of(env_col)) %>% rename(env = all_of(env_col)),
    by = "year"
  )
  df <- df %>% filter(!is.na(insect) & !is.na(env))
  list(insect = df$insect, env = df$env)
}

# -----------------------------
# 1. SMI_upsoil
# -----------------------------
results_smi <- map_dfr(families, function(fam) {
  insect_df <- ds22007_stationary_HAI$ds22007 %>%
    filter(Family == fam) %>% arrange(year)
  
  env_df <- ds22007_stationary_HAI$SMI_upsoil
  
  map_dfr(lags, function(lag) {
    ts <- align_ts(insect_df, env_df, "HAI")
    res <- granger_safe(ts$insect, ts$env, lag = lag)
    tibble(Family = fam,
           EnvDataset = "SMI_upsoil",
           EnvColumn = "HAI",
           lag = lag,
           F_stat = res$F_stat,
           p_value = res$p_value,
           Croptype = NA_character_,
           Fertilizer = NA_character_)
  })
})

# -----------------------------
# 2. NDVI (HAI)
# -----------------------------
env_vars <- list(
  NDVI = ds22007_stationary_HAI$NDVI
)

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_df <- ds22007_stationary_HAI$ds22007 %>%
      filter(Family == fam) %>% arrange(year)
    
    env_df <- env_vars[[varname]]
    
    map_dfr(lags, function(lag) {
      ts <- align_ts(insect_df, env_df, "mean_NDVI")
      res <- granger_safe(ts$insect, ts$env, lag = lag)
      tibble(Family = fam,
             EnvDataset = varname,
             EnvColumn = "mean_NDVI",
             lag = lag,
             F_stat = res$F_stat,
             p_value = res$p_value,
             Croptype = NA_character_,
             Fertilizer = NA_character_)
    })
  })
})

# -----------------------------
# 3. Fertilization
# -----------------------------
fert_data <- ds22007_stationary_HAI$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(HAI_list = list(HAI), .groups = "drop") %>%
  crossing(Family = families, lag = lags) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- ds22007_stationary_HAI$ds22007 %>%
      filter(Family == Family) %>% arrange(year)
    env_df <- tibble(year = insect_df$year, HAI = HAI_list[[1]])
    
    ts <- align_ts(insect_df, env_df, "HAI")
    
    granger_safe(ts$insect, ts$env, lag = lag)
  })) %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "HAI") %>%
  select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, lag, F_stat, p_value)

# -----------------------------
# 3. Mosaic and Weather
# -----------------------------
results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]]), function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- ds22007_stationary_HAI$ds22007 %>%
        filter(Family == fam) %>% arrange(year)
      
      # Proper Year Alignment
      env_df <- ds22007_stationary_HAI[[dsname]] %>%
        select(year, all_of(colname)) %>%
        rename(env = all_of(colname))
      
      map_dfr(lags, function(lag) {
        ts <- align_ts(insect_df, env_df, "env")
        res <- granger_safe(ts$insect, ts$env, lag = lag)
        tibble(Family = fam,
               EnvDataset = dsname,
               EnvColumn = colname,
               lag = lag,
               F_stat = res$F_stat,
               p_value = res$p_value,
               Croptype = NA_character_,
               Fertilizer = NA_character_)
      })
    })
  })
})

# -----------------------------
# 5. Combine all results and mark causality
# -----------------------------
results_ds22007_HAI <- bind_rows(results_smi, results_env, results_fert, results_mw) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

results_ds22007_HAI

######################### GRANGER TEST FOR DS22007 - SCH ##################

lags <- 1:3
families <- unique(ds22007_stationary_SCH$ds22007$Family)

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) < lag + 2 || length(y) < lag + 2) return(tibble(F_stat = NA, p_value = NA))
  if(var(x, na.rm = TRUE) == 0 || var(y, na.rm = TRUE) == 0) return(tibble(F_stat = NA, p_value = NA))
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
  }, error = function(e) tibble(F_stat = NA, p_value = NA))
}

# -----------------------------
# Helper function: align insect and env series by year
# -----------------------------
align_ts <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df %>% select(year, NumberAdults) %>% rename(insect = NumberAdults),
    env_df %>% select(year, all_of(env_col)) %>% rename(env = all_of(env_col)),
    by = "year"
  )
  df <- df %>% filter(!is.na(insect) & !is.na(env))
  list(insect = df$insect, env = df$env)
}

# -----------------------------
# 1. NDVI / NIRv
# -----------------------------
env_vars <- list(
  NDVI = ds22007_stationary_SCH$NDVI,
  NIRv = ds22007_stationary_SCH$NIRv
)

results_env <- map_dfr(names(env_vars), function(varname) {
  map_dfr(families, function(fam) {
    insect_df <- ds22007_stationary_SCH$ds22007 %>%
      filter(Family == fam) %>% arrange(year)
    env_df <- env_vars[[varname]]
    
    map_dfr(lags, function(lag) {
      ts <- align_ts(insect_df, env_df, paste0("mean_", varname))
      res <- granger_safe(ts$insect, ts$env, lag = lag)
      tibble(Family = fam,
             EnvDataset = varname,
             EnvColumn = paste0("mean_", varname),
             lag = lag,
             F_stat = res$F_stat,
             p_value = res$p_value,
             Croptype = NA_character_,
             Fertilizer = NA_character_)
    })
  })
})

# -----------------------------
# 2. Fertilization
# -----------------------------
fert_data <- ds22007_stationary_SCH$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(SCH_list = list(SCH), .groups = "drop") %>%
  crossing(Family = families, lag = lags) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- ds22007_stationary_SCH$ds22007 %>%
      filter(Family == Family) %>% arrange(year)
    env_df <- tibble(year = insect_df$year, SCH = SCH_list[[1]])
    ts <- align_ts(insect_df, env_df, "SCH")
    granger_safe(ts$insect, ts$env, lag = lag)
  })) %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "SCH") %>%
  select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, lag, F_stat, p_value)

# -----------------------------
# 3. Mosaic & Weather
# -----------------------------
mosaic_weather <- list(
  mosaic = ds22007_stationary_SCH$mosaic,
  weather = ds22007_stationary_SCH$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  map_dfr(names(mosaic_weather[[dsname]] %>% select(-year, -region)), function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- ds22007_stationary_SCH$ds22007 %>%
        filter(Family == fam) %>% arrange(year)
      env_df <- mosaic_weather[[dsname]] %>%
        select(year, all_of(colname)) %>% rename(env = all_of(colname))
      
      map_dfr(lags, function(lag) {
        ts <- align_ts(insect_df, env_df, "env")
        res <- granger_safe(ts$insect, ts$env, lag = lag)
        tibble(Family = fam,
               EnvDataset = dsname,
               EnvColumn = colname,
               lag = lag,
               F_stat = res$F_stat,
               p_value = res$p_value,
               Croptype = NA_character_,
               Fertilizer = NA_character_)
      })
    })
  })
})

# -----------------------------
# 4. Combine all results and mark causality
# -----------------------------
results_ds22007_SCH <- bind_rows(results_env, results_fert, results_mw) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

head(results_ds22007_SCH)


########################## CAUSALITY COUNTS FOR DS22007 #################
# Count causal vs non-causal time series per region
results_ds22007_ALB %>%
  dplyr::count(causal_label)

results_ds22007_HAI %>%
  dplyr::count(causal_label)

results_ds22007_SCH %>%
  dplyr::count(causal_label)

# Export results
write.csv(results_ds22007_ALB, "./tables/granger_test/results_ds22007_ALB.csv", row.names = FALSE)
write.csv(results_ds22007_HAI, "./tables/granger_test/results_ds22007_HAI.csv", row.names = FALSE)
write.csv(results_ds22007_SCH, "./tables/granger_test/results_ds22007_SCH.csv", row.names = FALSE)


##################################################################
######### COMPARISON OF DS21969 AND DS22007 ####################
# Load yearly Granger results for both datasets
results_yearly_ds21969_ALB <- read.csv("./tables/granger_test/results_ds21969_ALB.csv", sep=",")
results_yearly_ds21969_HAI <- read.csv("./tables/granger_test/results_ds21969_HAI.csv", sep=",")
results_yearly_ds21969_SCH <- read.csv("./tables/granger_test/results_ds21969_SCH.csv", sep=",")

results_yearly_ds22007_ALB <- read.csv("./tables/granger_test/results_ds22007_ALB.csv", sep=",")
results_yearly_ds22007_HAI <- read.csv("./tables/granger_test/results_ds22007_HAI.csv", sep=",")
results_yearly_ds22007_SCH <- read.csv("./tables/granger_test/results_ds22007_SCH.csv", sep=",")

# Function: count causal labels and return data frame
count_causal <- function(df, region, dataset) {
  df %>%
    dplyr::count(causal_label) %>%
    mutate(Region = region, Dataset = dataset)
}

# ds21969 counts
counts_21969 <- bind_rows(
  count_causal(results_yearly_ds21969_ALB, "ALB", "ds21969"),
  count_causal(results_yearly_ds21969_HAI, "HAI", "ds21969"),
  count_causal(results_yearly_ds21969_SCH, "SCH", "ds21969")
)

# ds22007 counts
counts_22007 <- bind_rows(
  count_causal(results_yearly_ds22007_ALB, "ALB", "ds22007"),
  count_causal(results_yearly_ds22007_HAI, "HAI", "ds22007"),
  count_causal(results_yearly_ds22007_SCH, "SCH", "ds22007")
)

# Combine both datasets and reshape
comparison_table <- bind_rows(counts_21969, counts_22007) %>%
  tidyr::pivot_wider(names_from = causal_label, values_from = n, values_fill = 0) %>%
  dplyr::arrange(Dataset, Region)

comparison_table

# Export comparison
write.csv(comparison_table, "./tables/granger_test/comparison_table_yearly.csv", row.names = FALSE)
