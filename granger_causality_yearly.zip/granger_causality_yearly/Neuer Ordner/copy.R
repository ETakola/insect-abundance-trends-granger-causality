####################### ds21969 YEARLY ##################################

########################## 2nd Round Granger ############################
# Performs Granger tests on detrended/differenced (stationary) data
# 1. Uses the lists created in the scripts
#    "detrending_251118" and "detrending_ds21969_monthly_261127"
# 2. Performs Granger tests on all stationary insect data aggregated together

################### load packages #######################################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests

#################### load data #########################################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Crop yield and area data
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


##### Stationarity table from first round (used to build lists) ########
stationarity_table_ds21969_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_yearly.csv", sep =",")

##### Combined stationarity tables with transformed data ################
# ds21969 – yearly
ds21969_both_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_detrended_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

# ds22007 – yearly
ds22007_both_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_yearly.csv",
  sep = ","
) %>% filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")


ds22007_detrended_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_yearly.csv",
  sep = ","
) %>% filter(ADF_status == "stationary", KPSS_status == "stationary", Family != "Fam.")

ds22007_differenced_yearly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_yearly.csv",
  sep = ","
) %>% filter(ADF_status == "stationary", KPSS_status == "stationary", Family != "Fam.")

############################## data list ################################
# Combine all datasets into a single list for easier handling
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  Fertilization = Fertilization,
  mosaic = mosaic,
  weather = weather,
  ALB_crop = ALB_crop,
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop,
  ds21969 = ds21969
)


####################### YEARLY AGGREGATION DS21969 #######################

# -----------------------------
# Function: Aggregate datasets yearly (except weather)
# -----------------------------
aggregate_yearly <- function(df, dataset_name) {
  
  # Filter for NDVI, NDMI, NIRv: only months April to October
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NIRv_ALB", "NIRv_HAI", "NIRv_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
  # Special handling for crop datasets
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
                  .groups = "drop") %>%
        mutate(year = as.integer(year))
    )
  }
  
  # Define grouping and sum columns
  group_col <- NULL
  sum_cols <- c()
  
  if (dataset_name %in% c("ds21969")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month", "day"))
  
  # Perform yearly aggregation
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      mutate(year = as.integer(year))
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      ) %>%
      mutate(year = as.integer(year))
  }
  
  return(df_yearly)
}

# -----------------------------
# Special aggregation for weather
# -----------------------------
aggregate_weather <- function(weather_df) {
  
  sum_cols <- c("precipitation_radolan", "precipitation_radolan_rain_days")
  mean_cols <- c(
    "rH_200", "rH_200_max", "rH_200_min",
    "SM_10", "SM_20",
    "Ta_10", "Ta_10_max", "Ta_10_min",
    "Ta_200", "Ta_200_max", "Ta_200_min",
    "Ts_05", "Ts_05_max", "Ts_05_min",
    "Ts_10", "Ts_10_max", "Ts_10_min",
    "Ts_20", "Ts_20_max", "Ts_20_min",
    "Ts_50", "Ts_50_max", "Ts_50_min"
  )
  
  # Step 1: Aggregate per plot
  weather_annual <- weather_df %>%
    group_by(plotID, year) %>%
    summarise(
      region = first(region),
      across(all_of(sum_cols), sum, na.rm = TRUE),
      across(all_of(mean_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
  # Step 2: Aggregate per region
  weather_region <- weather_annual %>%
    group_by(region, year) %>%
    summarise(
      across(all_of(sum_cols), mean, na.rm = TRUE),  # Average sum columns
      across(all_of(mean_cols), mean, na.rm = TRUE), # Average mean columns
      .groups = "drop"
    ) %>%
    mutate(year = as.integer(year))
  
  return(weather_region)
}

# -----------------------------
# Year range for ds21969
# -----------------------------
years_ds21969 <- range(as.integer(ds21969$year), na.rm = TRUE)

# -----------------------------
# Aggregate all datasets yearly
# -----------------------------
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    aggregate_weather(data_list[[name]])
  } else {
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# -----------------------------
# Filter datasets to ds21969 years
# -----------------------------
data_for_ds21969 <- lapply(
  data_yearly,
  function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2])
)

# -----------------------------
# Ensure all years are integer
# -----------------------------
data_for_ds21969 <- lapply(data_for_ds21969, function(df) {
  if("year" %in% names(df)) df$year <- as.integer(df$year)
  df
})


###################################################################
################## SELECT ONLY STATIONARY RESULTS #################
# Yearly stationary datasets
ds21969_stationary_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DETRENDING #################
# Yearly
ds21969_detrend_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

################## DETRENDING DS21969 #################################

# -------------------------------------------
# Function: safe filtering for detrending
# -------------------------------------------
filter_ds21969_detrend_safe <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is listed in the detrending table
  if(!dataset_name %in% unique(detrend_overview$dataset)) return(NULL)
  
  # Identify variables that need to be detrended
  value_cols <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns only if they exist in the data frame
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Filter by Family + Exploratory (allowed combinations only)
  allowed_combinations <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  df_filtered <- df %>% dplyr::select(any_of(c(existing_group_cols, value_cols)))
  
  if("Family" %in% names(df_filtered) & "Exploratory" %in% names(df_filtered)) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family", "Exploratory"))
  }
  
  # Optional: remove region column for selected datasets
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}


detrend_ts_with_suffix <- function(df, value_cols, time_col = "year", suffix = "_detrended") {
  df_out <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      if(sum(!is.na(df[[col]])) > 1) {
        
        # Fit nur für vorhandene Werte
        fit <- lm(df[[col]] ~ df[[time_col]])
        
        # Erstelle leeren Vektor mit NA
        resid_vec <- rep(NA, nrow(df))
        
        # Setze Residuen nur dort ein, wo df[[col]] nicht NA ist
        resid_vec[!is.na(df[[col]])] <- residuals(fit)
        
        # Weist die Residuen zu
        df_out[[paste0(col, suffix)]] <- resid_vec
        
      } else {
        df_out[[paste0(col, suffix)]] <- NA
      }
    }
  }
  
  return(df_out)
}

# -------------------------------------------
# Filter and detrend the full dataset list
# -------------------------------------------
filtered_ds21969_detrended_safe <- imap(data_for_ds21969, function(df, name) {
  
  df_filtered <- filter_ds21969_detrend_safe(df, name, ds21969_detrend_yearly)
  
  if(is.null(df_filtered)) return(NULL)
  
  value_cols <- ds21969_detrend_yearly %>%
    filter(dataset == name) %>%
    pull(variable)
  
  detrend_ts_with_suffix(df_filtered, value_cols, time_col = "year", suffix = "_detrended")
})

# Remove NULL entries
filtered_ds21969_detrended_safe <- filtered_ds21969_detrended_safe[!sapply(filtered_ds21969_detrended_safe, is.null)]

# Test output
cat("Filtered and detrended datasets:\n")
print(names(filtered_ds21969_detrended_safe))



################## SELECT DATASETS REQUIRING DIFFERENCING #################
# Yearly
ds21969_differencing_yearly <- stationarity_table_ds21969_yearly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# DIFFERENCING

# -------------------------------------------------------------------
# Function: first differencing per time series
# -------------------------------------------------------------------
difference_ts <- function(df, value_cols, time_col = "year") {
  df_diff <- df
  for(col in value_cols) {
    if(col %in% names(df)) {
      # Apply differencing within the column
      df_diff[[col]] <- c(NA, diff(df[[col]]))
    }
  }
  return(df_diff)
}

# -------------------------------------------------------------------
# Function: safely filter ds21969 datasets and apply differencing
# -------------------------------------------------------------------
filter_ds21969_diff_safe <- function(df, dataset_name, diff_overview) {
  
  # Check whether dataset is listed in the overview table
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  # Extract variables that need to be differenced
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns if they exist
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only relevant columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only allowed Family + Exploratory combinations
  allowed_combinations <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Apply differencing to the selected variables
  df_diff <- difference_ts(df_filtered, allowed_columns, time_col = "year")
  
  return(df_diff)
}

# -------------------------------------------------------------------
# Apply filtering and differencing to the full ds21969 dataset list
# -------------------------------------------------------------------
filtered_ds21969_diffed_safe <- imap(data_for_ds21969, function(df, name) {
  filter_ds21969_diff_safe(df, name, ds21969_differencing_yearly)
})

# Remove NULL entries
filtered_ds21969_diffed_safe <- filtered_ds21969_diffed_safe[!sapply(filtered_ds21969_diffed_safe, is.null)]

# -----------------------------
# Test output
# -----------------------------
cat("Differenced datasets:\n")
print(names(filtered_ds21969_diffed_safe))

cat("\nExample: first rows of one dataset:\n")
print(head(filtered_ds21969_diffed_safe[[1]]))
str(filtered_ds21969_diffed_safe)


#########################################################################
# Build lists

# Determine per dataset how many new families need to be added to the family list

# data_for_ds21969 is the original list for the Granger causality analysis
# Columns from other dataset lists need to be added to these datasets
# How can this be done?

# Originally, Granger tests were performed on regionally separated lists, as in
# script "granger_causality_test_251111"

######## PREPARE FOR FURTHER FILTERING - ds21969  - YEARLY ######
############################################################################

############ ds21969 #######################################################
# Take stationary results from pre-tests, keep only stationary time-series in the list

# ---------------------------------------------------------------
# Function: filter ds21969 datasets, keep only stationary series (robust)
# ---------------------------------------------------------------
filter_ds21969_stationary_safe <- function(df, dataset_name, overview_stationary) {
  
  # Skip if dataset not in overview table
  if(!dataset_name %in% unique(overview_stationary$dataset)) return(NULL)
  
  # Allowed variables according to overview
  allowed_columns <- overview_stationary %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Keep grouping columns if present
  grouping_columns <- c("year", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Combine all columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter rows: keep only allowed values in grouping columns (except year)
  for(col in setdiff(existing_group_cols, "year")){
    allowed_values <- overview_stationary %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only stationary Family + Exploratory combinations
  allowed_combinations <- overview_stationary %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family", "Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Remove region column for NDVI, NDMI, NIRv datasets
  if(dataset_name %in% c("NDVI_ALB","NDVI_HAI","NDVI_SCH",
                         "NDMI_ALB","NDMI_HAI","NDMI_SCH",
                         "NIRv_ALB","NIRv_HAI","NIRv_SCH")){
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# ---------------------------------------------------------------
# Apply filtering to the entire ds21969 list
# ---------------------------------------------------------------
filtered_ds21969_list_safe <- imap(data_for_ds21969, function(df, name){
  filter_ds21969_stationary_safe(df, name, ds21969_stationary_yearly)
})
filtered_ds21969_list_safe <- filtered_ds21969_list_safe[!sapply(filtered_ds21969_list_safe, is.null)]

# Test output
cat("Filtered stationary ds21969 datasets:\n")
print(names(filtered_ds21969_list_safe))


###################### ds21969 #########################################
# Create sub-lists per region

# ---------------------------------------------------------------
# 1. SMI_upsoil for ALB
# ---------------------------------------------------------------
smi_alb <- filtered_ds21969_list_safe$SMI_upsoil %>% dplyr::select(year, ALB)

# ---------------------------------------------------------------
# 2. NDVI, NDMI, NIRv for ALB
# ---------------------------------------------------------------
ndvi_alb <- filtered_ds21969_list_safe$NDVI_ALB
nirv_alb <- filtered_ds21969_list_safe$NIRv_ALB

# ---------------------------------------------------------------
# 3. Fertilization for ALB
# ---------------------------------------------------------------
fert_alb <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, ALB)

# ---------------------------------------------------------------
# 4. Mosaic & Weather for ALB
# ---------------------------------------------------------------
mosaic_alb <- filtered_ds21969_list_safe$mosaic %>% filter(region == "ALB")
weather_alb <- filtered_ds21969_list_safe$weather %>% filter(region == "ALB")

# ---------------------------------------------------------------
# 5. ds21969 for ALB
# ---------------------------------------------------------------
ds21969_alb <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "ALB")

# ---------------------------------------------------------------
# 6. Create sub-list for ALB
# ---------------------------------------------------------------
ds21969_stationary_ALB <- list(
  smi_upsoil = smi_alb,
  NDVI = ndvi_alb,
  NIRv = nirv_alb,
  Fertilization = fert_alb,
  mosaic = mosaic_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

# Optional: check
names(ds21969_stationary_ALB)
lapply(ds21969_stationary_ALB, names)

############ ds21969 - sort for HAI ###############################################

# ---------------------------------------------------------------
# 1. SMI_upsoil for HAI
# ---------------------------------------------------------------
smi_hai <- filtered_ds21969_list_safe$SMI_upsoil %>% dplyr::select(year, HAI)

# ---------------------------------------------------------------
# 2. NDVI, NIRv for HAI
# ---------------------------------------------------------------
ndvi_hai <- filtered_ds21969_list_safe$NDVI_HAI
nirv_hai <- filtered_ds21969_list_safe$NIRv_HAI

# ---------------------------------------------------------------
# 2. Fertilization for HAI
# ---------------------------------------------------------------
fert_hai <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, HAI)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for HAI
# ---------------------------------------------------------------
mosaic_hai <- filtered_ds21969_list_safe$mosaic %>% filter(region == "HAI")
weather_hai <- filtered_ds21969_list_safe$weather %>% filter(region == "HAI")

# ---------------------------------------------------------------
# 4. ds21969 for HAI
# ---------------------------------------------------------------
ds21969_hai <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "HAI")

# ---------------------------------------------------------------
# 5. Create sub-list for HAI
# ---------------------------------------------------------------
ds21969_stationary_HAI <- list(
  smi_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NIRv = nirv_hai,
  Fertilization = fert_hai,
  mosaic = mosaic_hai,
  weather = weather_hai,
  ds21969 = ds21969_hai
)

# Optional: check
names(ds21969_stationary_HAI)
lapply(ds21969_stationary_HAI, names)

############ ds21969 - sort for SCH ###############################################

# ---------------------------------------------------------------
# 1. NDVI, NDMI, NIRv for SCH
# ---------------------------------------------------------------
ndvi_sch <- filtered_ds21969_list_safe$NDVI_SCH
nirv_sch <- filtered_ds21969_list_safe$NIRv_SCH

# ---------------------------------------------------------------
# 2. Fertilization for SCH
# ---------------------------------------------------------------
fert_sch <- filtered_ds21969_list_safe$Fertilization %>%
  dplyr::select(year, Croptype, Fertilizer, SCH)

# ---------------------------------------------------------------
# 3. Mosaic & Weather for SCH
# ---------------------------------------------------------------
mosaic_sch <- filtered_ds21969_list_safe$mosaic %>% filter(region == "SCH")
weather_sch <- filtered_ds21969_list_safe$weather %>% filter(region == "SCH")

# ---------------------------------------------------------------
# 4. ds21969 for SCH
# ---------------------------------------------------------------
ds21969_sch <- filtered_ds21969_list_safe$ds21969 %>% filter(Exploratory == "SCH")

# ---------------------------------------------------------------
# 5. Create sub-list for SCH
# ---------------------------------------------------------------
ds21969_stationary_SCH <- list(
  Fertilization = fert_sch,
  mosaic = mosaic_sch,
  weather = weather_sch,
  ds21969 = ds21969_sch,
  ndvi_sch = ndvi_sch,
  nirv_sch = nirv_sch
)

# Optional: check
names(ds21969_stationary_SCH)
lapply(ds21969_stationary_SCH, names)


########################### FILTER ds21969 2nd time #######################
# ---------------------------------------------
# Helper: merge weather datasets column-wise
# ---------------------------------------------
merge_weather_columns <- function(old, new) {
  
  if (is.null(old) && is.null(new)) return(NULL)
  if (is.null(old)) return(new)
  if (is.null(new)) return(old)
  
  # Ensure correct types
  old <- old %>% dplyr::mutate(year = as.integer(year))
  new <- new %>% dplyr::mutate(year = as.integer(year))
  
  dplyr::full_join(
    old,
    new,
    by = c("region", "year")
  ) %>%
    dplyr::arrange(region, year)
}

##############################ALB #####################################
str(ds21969_stationary_ALB) 

# Target list: ds21969_stationary_ALB
target <- ds21969_stationary_ALB

# ---------------------------------------------
# 1) HELPER FUNCTIONS
# ---------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new, drop_cols = NULL) {
  if (!is.null(drop_cols)) new <- dplyr::select(new, -all_of(drop_cols))
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}

# ---------------------------------------------
# 2) FILTERED_DS21969_DETRENDED
# ---------------------------------------------

src <- filtered_ds21969_detrended_safe

## SMI_total (drop SCH)
if ("SMI_total" %in% names(src)) {
  new_data <- src$SMI_total |> dplyr::select(-SCH_detrended, -SCH)
  target$SMI_total <- merge_columns_simple(target$SMI_total, new_data)
}

## Fertilization$ALB (grouped)
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |> 
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique_fixed(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region == "ALB")
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "ALB")
  target$mosaic <- merge_grouped_unique_fixed(
    target$mosaic,
    new_mosaic,
    c("region")
  )
}

## weather (region == "ALB") – detrended
if ("weather" %in% names(filtered_ds21969_detrended_safe)) {
  
  new_weather <- filtered_ds21969_detrended_safe$weather %>%
    dplyr::filter(region == "ALB")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}


## ALB_crop
if ("ALB_crop" %in% names(src)) {
  target$ALB_crop <- merge_grouped_unique_fixed(
    target$ALB_crop,
    src$ALB_crop,
    c("var", "measure", "year")
  )
}

## ds21969 (region == "ALB")
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "ALB")
  target$ds21969 <- merge_grouped_unique_fixed(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}


# ---------------------------------------------
# 3) FILTERED_DS21969_DIFFED
# ---------------------------------------------

src <- filtered_ds21969_diffed_safe

## Fertilization$ALB
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |>
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique_fixed(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "ALB") – diffed
if ("weather" %in% names(filtered_ds21969_diffed_safe)) {
  
  new_weather <- filtered_ds21969_diffed_safe$weather %>%
    dplyr::filter(region == "ALB")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}


# ---------------------------------------------
# 4) FILTERED_DS21969_DIFFED_DETRENDED
# ---------------------------------------------

src <- filtered_ds21969_diffed_detrended_safe

## Fertilization$ALB
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |> 
    dplyr::select(Croptype, Fertilizer, year, ALB) |>
    dplyr::filter(!is.na(ALB))
  
  target$Fertilization <- merge_grouped_unique_fixed(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_ALB <- target

str(updated_ds21969_stationary_ALB)

##########################################################################
ds21969_stationary_HAI

# Target list
target <- ds21969_stationary_HAI


# ---------------------------------------------------
# Helper functions
# ---------------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new) {
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}



# ===================================================
# 1) FILTERED_DS21969_DETRENDED
# ===================================================

src <- filtered_ds21969_detrended_safe

## NDVI_HAI
if ("NDVI_HAI" %in% names(src)) {
  target$NDVI_HAI <- merge_columns_simple(target$NDVI_HAI, src$NDVI_HAI)
}

## NDMI_HAI
if ("NDMI_HAI" %in% names(src)) {
  target$NDMI_HAI <- merge_columns_simple(target$NDMI_HAI, src$NDMI_HAI)
}

## NIRv_HAI
if ("NIRv_HAI" %in% names(src)) {
  target$NIRv_HAI <- merge_columns_simple(target$NIRv_HAI, src$NIRv_HAI)
}

## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region = HAI)
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "HAI")
  target$mosaic <- merge_grouped_unique(
    target$mosaic,
    new_mosaic,
    c("region")
  )
}

## weather (region == "HAI") 
if ("weather" %in% names(filtered_ds21969_detrended_safe)) {
  
  new_weather <- filtered_ds21969_detrended_safe$weather %>%
    dplyr::filter(region == "HAI")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}

## ds21969 (Exploratory = HAI)
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "HAI")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 2) FILTERED_DS21969_DIFFED
# ===================================================

src <- filtered_ds21969_diffed_safe


## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "HAI") – diffed
if ("weather" %in% names(filtered_ds21969_diffed_safe)) {
  
  new_weather <- filtered_ds21969_diffed_safe$weather %>%
    dplyr::filter(region == "HAI")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}

## ds21969 (Exploratory = "HAI")
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "HAI")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 3) FILTERED_DS21969_DIFFED_DETRENDED
# ===================================================

src <- filtered_ds21969_diffed_detrended_safe

## SMI_total
if ("SMI_total" %in% names(src)) {
  
  smi <- src$SMI_total %>%
    dplyr::rename(HAI_diff_detrended = HAI)   # <-- New standardized column name
  
  target$SMI_total <- merge_columns_simple(
    target$SMI_total,
    smi
  )
}

## Fertilization$HAI
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, HAI) |>
    dplyr::filter(!is.na(HAI))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## HAI_crop
if ("HAI_crop" %in% names(src)) {
  target$HAI_crop <- merge_grouped_unique(
    target$HAI_crop,
    src$HAI_crop,
    c("var", "measure", "year")
  )
}

## weather (region == "HAI") – diffed + detrended
if ("weather" %in% names(filtered_ds21969_diffed_detrended_safe)) {
  
  new_weather <- filtered_ds21969_diffed_detrended_safe$weather %>%
    dplyr::filter(region == "HAI")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}


# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_HAI <- target

#####################################################################

# Target list
target <- ds21969_stationary_SCH

# ---------------------------------------------------
# Helper functions
# ---------------------------------------------------

merge_grouped_unique <- function(old, new, group_cols) {
  out <- dplyr::bind_rows(old, new)
  out <- dplyr::distinct(out)
  if ("year" %in% names(out)) out <- dplyr::arrange(out, year)
  out
}

merge_columns_simple <- function(old, new) {
  dplyr::bind_rows(old, new) |> dplyr::distinct()
}



# ===================================================
# 1) FILTERED_DS21969_DETRENDED
# ===================================================

src <- filtered_ds21969_detrended_safe

## SMI_total (exclude ALB)
if ("SMI_total" %in% names(src)) {
  new_smi <- src$SMI_total |> dplyr::select(-ALB_detrended, -ALB)
  target$SMI_total <- merge_columns_simple(target$SMI_total, new_smi)
}

## SMI_upsoil
if ("SMI_upsoil" %in% names(src)) {
  target$SMI_upsoil <- merge_columns_simple(target$SMI_upsoil, src$SMI_upsoil)
}

## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## mosaic (region = SCH)
if ("mosaic" %in% names(src)) {
  new_mosaic <- src$mosaic |> dplyr::filter(region == "SCH")
  target$mosaic <- merge_grouped_unique(target$mosaic, new_mosaic, c("region"))
}

## weather (region == "SCH") 
if ("weather" %in% names(filtered_ds21969_detrended_safe)) {
  
  new_weather <- filtered_ds21969_detrended_safe$weather %>%
    dplyr::filter(region == "SCH")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}

## SCH_crop
if ("SCH_crop" %in% names(src)) {
  target$SCH_crop <- merge_grouped_unique(
    target$SCH_crop,
    src$SCH_crop,
    c("var", "measure", "year")
  )
}

## ds21969 (Exploratory = SCH)
if ("ds21969" %in% names(src)) {
  new_insects <- src$ds21969 |> dplyr::filter(Exploratory == "SCH")
  target$ds21969 <- merge_grouped_unique(
    target$ds21969,
    new_insects,
    c("Exploratory", "Family", "year")
  )
}



# ===================================================
# 2) FILTERED_DS21969_DIFFED
# ===================================================

src <- filtered_ds21969_diffed_safe


## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "SCH") – diffed
if ("weather" %in% names(filtered_ds21969_diffed_safe)) {
  
  new_weather <- filtered_ds21969_diffed_safe$weather %>%
    dplyr::filter(region == "SCH")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}



# ===================================================
# 3) FILTERED_DS21969_DIFFED_DETRENDED
# ===================================================

src <- filtered_ds21969_diffed_detrended_safe


## Fertilization$SCH
if ("Fertilization" %in% names(src)) {
  new_fert <- src$Fertilization |>
    dplyr::select(Croptype, Fertilizer, year, SCH) |>
    dplyr::filter(!is.na(SCH))
  
  target$Fertilization <- merge_grouped_unique(
    target$Fertilization,
    new_fert,
    c("Croptype", "Fertilizer", "year")
  )
}

## weather (region == "SCH") – diffed + detrended
if ("weather" %in% names(filtered_ds21969_diffed_detrended_safe)) {
  
  new_weather <- filtered_ds21969_diffed_detrended_safe$weather %>%
    dplyr::filter(region == "SCH")
  
  target$weather <- merge_weather_columns(
    target$weather,
    new_weather
  )
}


# ---------------------------------------------
# OUTPUT
# ---------------------------------------------

updated_ds21969_stationary_SCH <- target
str(updated_ds21969_stationary_SCH$weather)

################## GRANGER ANALYSIS ######################
################ DS21969_ALB_YEARLY ######################

# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_ALB$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_ALB$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_ALB$smi_upsoil, "ALB")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_upsoil",
           EnvColumn = "ALB",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_ALB$SMI_total, "ALB")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "ALB",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_ALB$NDVI, "NDVI", "mean_NDVI")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_ALB$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 3. Fertilization (ALB)
# -----------------------------
fert_data <- updated_ds21969_stationary_ALB$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(ALB_list = list(ALB), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, ALB_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "ALB") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_ALB$mosaic,
  weather = updated_ds21969_stationary_ALB$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 5. ALB_crop
# -----------------------------
alb_crop <- updated_ds21969_stationary_ALB$ALB_crop

results_crop <- map_dfr(unique(alb_crop$var), function(varname) {
  map_dfr(unique(alb_crop$measure), function(measurename) {
    subset_data <- alb_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "ALB_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_ALB <- bind_rows(
  results_smi_upsoil,
  results_SMI_total,
  results_ndvi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_ALB

results_ALB$causality <- with(results_ALB,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_ALB, "./tables/granger_test/results_ds21969_ALB_2nd_round.csv", row.names = FALSE)


################## GRANGER ANALYSIS ######################
################ DS21969_HAI_YEARLY ######################

# -----------------------------
# List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_HAI$ds21969$Family)
lags <- 1:3

# -----------------------------
# Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_HAI$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test (handles short or constant series)
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI
# -----------------------------
results_SMI_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_HAI$smi_upsoil, "HAI")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "smi_upsoil",
           EnvColumn = "HAI",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_HAI$SMI_total, "HAI_diff_detrended")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "HAI_diff_detrended",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_HAI$NDVI, "NDVI", "mean_NDVI")
results_ndmi <- run_granger_env_vars(updated_ds21969_stationary_HAI$NDMI_HAI, "NDMI", "mean_NDMI_detrended")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_HAI$NIRv_HAI, "NIRv", "mean_NIRv_detrended")

# -----------------------------
# 3. Fertilization (HAI)
# -----------------------------
fert_data <- updated_ds21969_stationary_HAI$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(HAI_list = list(HAI), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, HAI_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "HAI") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 4. Mosaic & Weather
# -----------------------------
run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_HAI$mosaic,
  weather = updated_ds21969_stationary_HAI$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 5. HAI_crop
# -----------------------------
hai_crop <- updated_ds21969_stationary_HAI$HAI_crop

results_crop <- map_dfr(unique(hai_crop$var), function(varname) {
  map_dfr(unique(hai_crop$measure), function(measurename) {
    subset_data <- hai_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "HAI_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 6. Combine all results
# -----------------------------
results_HAI <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_HAI

results_HAI$causality <- with(results_HAI,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_HAI, "./tables/granger_test/results_ds21969_HAI_2nd_round.csv", row.names = FALSE)


########################### SCH ##################################
################## GRANGER ANALYSIS ##############################

# -----------------------------
# 1. List of families & lags
# -----------------------------
families <- unique(updated_ds21969_stationary_SCH$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Extract insect time series as dataframe
# -----------------------------
get_insect_ts_df <- function(fam) {
  updated_ds21969_stationary_SCH$ds21969 %>%
    filter(Family == fam) %>%
    arrange(year) %>%
    mutate(NumberAdults_use = ifelse(!is.na(NumberAdults_detrended),
                                     NumberAdults_detrended,
                                     NumberAdults)) %>%
    dplyr::select(year, NumberAdults_use)
}

# -----------------------------
# 3. Align time series by year
# -----------------------------
align_ts_year <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    dplyr::select(insect_df, year, NumberAdults_use),
    dplyr::select(env_df, year, !!sym(env_col)),
    by = "year"
  )
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 5. SMI
# -----------------------------
results_SMI_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_SCH$SMI_upsoil, "SCH")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_upsoil",
           EnvColumn = "SCH",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

results_SMI_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df(fam)
  ts <- align_ts_year(insect_df, updated_ds21969_stationary_SCH$SMI_total, "SCH")
  
  res <- granger_safe(ts$insect, ts$env, lags)
  
  res %>%
    mutate(Family = fam,
           EnvDataset = "SMI_total",
           EnvColumn = "SCH",
           Croptype = NA_character_,
           Fertilizer = NA_character_) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 6. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df(fam)
    ts <- align_ts_year(insect_df, env_df, colname)
    
    res <- granger_safe(ts$insect, ts$env, lags)
    
    res %>%
      mutate(Family = fam,
             EnvDataset = envname,
             EnvColumn = colname,
             Croptype = NA_character_,
             Fertilizer = NA_character_) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars(updated_ds21969_stationary_SCH$ndvi_sch, "ndvi", "mean_NDVI")
results_nirv <- run_granger_env_vars(updated_ds21969_stationary_SCH$nirv_sch, "nirv", "mean_NIRv")

# -----------------------------
# 7. Fertilization (SCH)
# -----------------------------
fert_data <- updated_ds21969_stationary_SCH$Fertilization

results_fert <- fert_data %>%
  group_by(Croptype, Fertilizer) %>%
  summarise(SCH_list = list(SCH), .groups = "drop") %>%
  crossing(Family = families) %>%
  rowwise() %>%
  mutate(test_res = list({
    insect_df <- get_insect_ts_df(Family)
    granger_safe(insect_df$NumberAdults_use, SCH_list[[1]], lags)
  })) %>%
  ungroup() %>%
  unnest(test_res) %>%
  mutate(EnvDataset = "Fertilization",
         EnvColumn = "SCH") %>%
  dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)

# -----------------------------
# 8. Mosaic & Weather
# -----------------------------

run_granger_env <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, env_df, colname)
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = envname,
               EnvColumn = colname,
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

mosaic_weather <- list(
  mosaic = updated_ds21969_stationary_SCH$mosaic,
  weather = updated_ds21969_stationary_SCH$weather
)

results_mw <- map_dfr(names(mosaic_weather), function(dsname) {
  run_granger_env(mosaic_weather[[dsname]], dsname)
})

# -----------------------------
# 9. SCH_crop
# -----------------------------
sch_crop <- updated_ds21969_stationary_SCH$SCH_crop

results_crop <- map_dfr(unique(sch_crop$var), function(varname) {
  map_dfr(unique(sch_crop$measure), function(measurename) {
    subset_data <- sch_crop %>% filter(var == varname, measure == measurename)
    env_ts <- subset_data$weighted_value_sum
    
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df(fam)
      ts <- align_ts_year(insect_df, subset_data, "weighted_value_sum")
      
      res <- granger_safe(ts$insect, ts$env, lags)
      
      res %>%
        mutate(Family = fam,
               EnvDataset = "SCH_crop",
               EnvColumn = paste(varname, measurename, sep = "_"),
               Croptype = NA_character_,
               Fertilizer = NA_character_) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
})

# -----------------------------
# 10. Combine all results & label causality
# -----------------------------
results_SCH <- bind_rows(
  results_SMI_upsoil,
  results_SMI_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_fert,
  results_mw,
  results_crop
)

results_SCH

results_SCH$causality <- with(results_SCH,
                              ifelse(is.na(p_value), "no_test",
                                     ifelse(p_value < 0.05, "causal", "non-causal"))
)

write.csv(results_SCH, "./tables/granger_test/results_ds21969_SCH_2nd_round.csv", row.names = FALSE)

