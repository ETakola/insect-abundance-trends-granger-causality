############################################################
############# Intrinsic growth rate (rt) ##############
############## Heatmaps for ds21969 and ds22007 #############
############################################################

#################### Load required packages ################
library(tidyverse)
library(pheatmap)

#################### Load and prepare data #################

# Dataset ds21969 (already pre-filtered)
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv")

# Helper function: decode collection run letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])
}

# Dataset ds22007
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),
    month = decode_collection_run(run_letter),
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),
    year = as.numeric(CollectionYear)
  ) %>%
  select(-run_letter)

##########################
# Remove spider families from ds21969
##########################
spider_families <- c(
  "Araneidae", "Dictynidae", "Linyphiidae", "Lycosidae",
  "Philodromidae", "Salticidae", "Tetragnathidae",
  "Theridiidae", "Thomisidae"
)

ds21969 <- ds21969 %>%
  filter(!Family %in% spider_families)

##########################
# Create output directories
##########################
dir.create("./plots/rt_heatmaps/families/ds21969", recursive = TRUE, showWarnings = FALSE)
dir.create("./plots/rt_heatmaps/families/ds22007", recursive = TRUE, showWarnings = FALSE)
dir.create("./plots/rt_heatmaps/species/ds21969", recursive = TRUE, showWarnings = FALSE)
dir.create("./plots/rt_heatmaps/species/ds22007", recursive = TRUE, showWarnings = FALSE)

dataset_label <- function(dataset) {
  case_when(
    dataset == "ds21969" ~ "Grassland Plots",
    dataset == "ds22007" ~ "Forest Plots",
    TRUE ~ dataset
  )
}

##########################
# Heatmap saving functions
##########################

# Family-level heatmaps
save_family_heatmap <- function(mat, dataset, site,
                                width_px = 2480, height_px = 4000) {
  if (is.null(mat) || nrow(mat) == 0) return()
  
  min_val <- min(mat, na.rm = TRUE)
  max_val <- max(mat, na.rm = TRUE)
  lim <- max(abs(min_val), abs(max_val))
  breaks <- seq(-lim, lim, length.out = 101)
  
  png(
    filename = paste0(
      "./plots/rt_heatmaps/families/", dataset, "/",
      dataset, "_Family_", site, ".png"
    ),
    width = width_px,
    height = height_px,
    res = 300
  )
  
  pheatmap(
    mat,
    main = paste(
      "Intrinsic Growth Rate (rt) –",
      dataset_label(dataset), "– Families –", site
    ),
    color = colorRampPalette(c("blue", "white", "red"))(100),
    breaks = breaks,
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    na_col = "gray20",
    fontsize = 12,
    fontfamily = "sans",
    cellwidth = 12,
    cellheight = 12
  )
  dev.off()
}

# Species-level heatmaps
save_species_heatmap <- function(mat, dataset, fam, site) {
  if (is.null(mat) || nrow(mat) == 0) return()
  
  min_val <- min(mat, na.rm = TRUE)
  max_val <- max(mat, na.rm = TRUE)
  lim <- max(abs(min_val), abs(max_val))
  breaks <- seq(-lim, lim, length.out = 101)
  
  png(
    filename = paste0(
      "./plots/rt_heatmaps/species/", dataset, "/",
      dataset, "_Species_", fam, "_", site, ".png"
    ),
    width = 2480,
    height = 3508,
    res = 300
  )
  
  pheatmap(
    mat,
    main = paste(
      "Intrinsic Growth Rate (rt) –",
      dataset_label(dataset), "–", fam, "–", site
    ),
    color = colorRampPalette(c("blue", "white", "red"))(100),
    breaks = breaks,
    cluster_rows = FALSE,
    cluster_cols = FALSE,
    na_col = "gray20",
    fontsize = 12,
    fontfamily = "sans",
    cellwidth = 12,
    cellheight = 12
  )
  dev.off()
}

##########################
# Helper functions: matrix creation
##########################

make_family_rt_matrix <- function(df, site) {
  df_site <- df %>%
    filter(Exploratory == site) %>%
    select(Family, Interval, rt)
  
  if (nrow(df_site) == 0) return(NULL)
  
  mat <- df_site %>%
    pivot_wider(names_from = Interval, values_from = rt) %>%
    column_to_rownames("Family")
  
  mat <- mat[, order(as.numeric(sub("-.*", "", colnames(mat)))), drop = FALSE]
  as.matrix(mat)
}

make_species_rt_matrix <- function(df, fam, site) {
  
  df_site <- df %>%
    filter(Family == fam, Exploratory == site) %>%
    group_by(Species) %>%
    filter(n() >= 3) %>%    
    ungroup() %>%
    select(Species, Interval, rt)
  
  if (nrow(df_site) == 0) return(NULL)
  
  mat <- df_site %>%
    pivot_wider(names_from = Interval, values_from = rt) %>%
    column_to_rownames("Species")
  
  mat <- mat[, order(as.numeric(sub("-.*", "", colnames(mat)))), drop = FALSE]
  as.matrix(mat)
}


############################################################
################ FAMILY HEATMAPS – DS21969 #################
############################################################

sites <- unique(ds21969$Exploratory)

ds_family_rt <- ds21969 %>%
  filter(Family != "Fam.") %>%
  group_by(Family, Exploratory, year) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  arrange(Family, Exploratory, year) %>%
  group_by(Family, Exploratory) %>%
  mutate(
    Nt = NumberAdults,
    Nt1 = lead(NumberAdults),
    Interval = paste0(year, "-", lead(year)),
    rt = ifelse((lead(year) - year) == 1, log(Nt1 / Nt), NA_real_)
  ) %>%
  ungroup() %>%
  filter(!is.na(rt)) %>%
  group_by(Family, Exploratory) %>%
  filter(n() >= 3) %>%   # ≥ 3 valid rt values
  ungroup()

for (site in sites) {
  mat <- make_family_rt_matrix(ds_family_rt, site)
  save_family_heatmap(mat, "ds21969", site)
}

############################################################
################ FAMILY HEATMAPS – DS22007 #################
############################################################

sites <- unique(ds22007$Exploratory)

ds_family_rt <- ds22007 %>%
  filter(Family != "Fam.") %>%
  group_by(Family, Exploratory, year) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  arrange(Family, Exploratory, year) %>%
  group_by(Family, Exploratory) %>%
  mutate(
    Nt = NumberAdults,
    Nt1 = lead(NumberAdults),
    Interval = paste0(year, "-", lead(year)),
    rt = ifelse((lead(year) - year) == 1, log(Nt1 / Nt), NA_real_)
  ) %>%
  ungroup() %>%
  filter(!is.na(rt)) %>%
  group_by(Family, Exploratory) %>%
  filter(n() >= 3) %>%   # ≥ 3 valid rt values
  ungroup()

for (site in sites) {
  mat <- make_family_rt_matrix(ds_family_rt, site)
  save_family_heatmap(mat, "ds22007", site, height_px = 4500)
}

############################################################
################ SPECIES HEATMAPS – DS21969 ################
############################################################

ds_rt_species <- ds21969 %>%
  filter(Family != "Fam.") %>%
  group_by(Family, Species, Exploratory, year) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  arrange(Family, Species, Exploratory, year) %>%
  group_by(Family, Species, Exploratory) %>%
  mutate(
    Nt = NumberAdults,
    Nt1 = lead(NumberAdults),
    Interval = paste0(year, "-", lead(year)),
    rt = ifelse((lead(year) - year) == 1, log(Nt1 / Nt), NA_real_)
  ) %>%
  ungroup() %>%
  filter(!is.na(rt)) %>%
  group_by(Family, Species, Exploratory) %>%
  filter(n() >= 3) %>%   # ≥ 3 valid rt values
  ungroup()

top_families <- ds_rt_species %>%
  group_by(Family) %>%
  summarise(Total = n()) %>%
  slice_max(Total, n = 5) %>%
  pull(Family)

for (fam in top_families) {
  sites <- unique(ds_rt_species$Exploratory[ds_rt_species$Family == fam])
  for (site in sites) {
    mat <- make_species_rt_matrix(ds_rt_species, fam, site)
    save_species_heatmap(mat, "ds21969", fam, site)
  }
}

############################################################
################ SPECIES HEATMAPS – DS22007 ################
############################################################

ds_rt_species <- ds22007 %>%
  filter(Family != "Fam.") %>%
  group_by(Family, Species, Exploratory, year) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
  arrange(Family, Species, Exploratory, year) %>%
  group_by(Family, Species, Exploratory) %>%
  mutate(
    Nt = NumberAdults,
    Nt1 = lead(NumberAdults),
    Interval = paste0(year, "-", lead(year)),
    rt = ifelse((lead(year) - year) == 1, log(Nt1 / Nt), NA_real_)
  ) %>%
  ungroup() %>%
  filter(!is.na(rt)) %>%
  group_by(Family, Species, Exploratory) %>%
  filter(n() >= 3) %>%   # ≥ 3 valid rt values
  ungroup()

top_families <- ds_rt_species %>%
  group_by(Family) %>%
  summarise(Total = n()) %>%
  slice_max(Total, n = 5) %>%
  pull(Family)

for (fam in top_families) {
  sites <- unique(ds_rt_species$Exploratory[ds_rt_species$Family == fam])
  for (site in sites) {
    mat <- make_species_rt_matrix(ds_rt_species, fam, site)
    save_species_heatmap(mat, "ds22007", fam, site)
  }
}

