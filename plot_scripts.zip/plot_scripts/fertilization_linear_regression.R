#######LOG-LINEAR REGRESSION PLOTS FOR FAMILIES AND FERTILIZATION DATASET########

# Load packages 
library(dplyr)
library(readr)
library(stringr)
library(tidyr)
library(ggplot2)
library(ggrepel)

## Load data 
# Fertilization 
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)
# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters into numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable


########## Results 2nd round ######################################
# Results from Granger causality test
#results from granger test
granger_results_ds21969_ALB <- read.csv("./tables/granger_test/results_ds21969_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_HAI <- read.csv("./tables/granger_test/results_ds21969_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_SCH <- read.csv("./tables/granger_test/results_ds21969_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds22007_ALB <- read.csv("./tables/granger_test/results_ds22007_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds22007_HAI <- read.csv("./tables/granger_test/results_ds22007_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds22007_SCH <- read.csv("./tables/granger_test/results_ds22007_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds21969_ALB_monthly <- read.csv("./tables/granger_test/results_ds21969_monthly_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_HAI_monthly <- read.csv("./tables/granger_test/results_ds21969_monthly_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_SCH_monthly <- read.csv("./tables/granger_test/results_ds21969_monthly_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds22007_ALB_monthly <- read.csv("./tables/granger_test/results_ds22007_ALB_monthly_clean_Kopie.csv", sep=",")
granger_results_ds22007_HAI_monthly <- read.csv("./tables/granger_test/results_ds22007_HAI_monthly_clean_Kopie.csv", sep=",")
granger_results_ds22007_SCH_monthly <- read.csv("./tables/granger_test/results_ds22007_SCH_monthly_clean_Kopie.csv", sep=",")

############################FILTERING#################################
# Causal families per dataset per region 
granger_results <- list(
  ds21969_ALB = granger_results_ds21969_ALB,
  ds21969_HAI = granger_results_ds21969_HAI,
  ds21969_SCH = granger_results_ds21969_SCH,
  ds22007_ALB = granger_results_ds22007_ALB,
  ds22007_HAI = granger_results_ds22007_HAI,
  ds22007_SCH = granger_results_ds22007_SCH,
  ds22007_ALB_monthly = granger_results_ds22007_ALB_monthly,
  ds22007_HAI_monthly = granger_results_ds22007_HAI_monthly,
  ds22007_SCH_monthly = granger_results_ds22007_SCH_monthly,
  ds21969_ALB_monthly = granger_results_ds21969_ALB_monthly,
  ds21969_HAI_monthly = granger_results_ds21969_HAI_monthly,
  ds21969_SCH_monthly = granger_results_ds21969_SCH_monthly
) 


############################## Organize datasets for easier handling ##########################
data_list <- list(
  Fertilization = Fertilization, 
  ds21969 = ds21969, ds22007 = ds22007
)

configs <- list(
  Fertilization = list(type = "grouped", group_cols = c("Croptype", "Fertilizer"), value_cols = c("ALB", "HAI", "SCH")),
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

######################################################################
# Function: Aggregate datasets on a yearly basis
aggregate_yearly <- function(df, dataset_name) {
  
  # ---------------------------
  # 3. Define grouping and aggregation columns
  # ---------------------------
  group_col <- NULL
  sum_cols <- c()
  
  # Insect datasets: sum adults, grouped by Exploratory & Family
  if (dataset_name %in% c("ds21969","ds22007")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  # Fertilization and mosaic datasets
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  
  # Columns to average (exclude year, grouping, sum, month/day)
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # ---------------------------
  # 4. Aggregate other datasets
  # ---------------------------
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

# 4. Prepare yearly aggregated data for insect datasets ds21969 and ds22007

# Determine the year ranges of each insect dataset
years_ds21969 <- range(ds21969$year, na.rm = TRUE)
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

# Aggregate all datasets on a yearly basis
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    # Use the special weather aggregation
    aggregate_weather(data_list[[name]])
  } else {
    # Use the aggregation function for other datasets
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# Filter datasets to the corresponding year ranges for each insect dataset
data_for_ds21969 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2]))
data_for_ds22007 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds22007[1], year <= years_ds22007[2]))

# Remove the other insect dataset from each list to avoid duplication
data_for_ds21969 <- data_for_ds21969[!names(data_for_ds21969) %in% c("ds22007")]
data_for_ds22007 <- data_for_ds22007[!names(data_for_ds22007) %in% c("ds21969")]


#### Filter causal families #########

causal_granger_all <- bind_rows(lapply(granger_results, function(df) {
  df %>% filter(causality == "causal")
})) 

causal_families <- causal_granger_all$Family %>%
  unique() %>%
  setdiff("Fam.")
print(sort(causal_families))

# Remove spiders 
spider_families <- c(
  "Araneidae",
  "Dictynidae",
  "Linyphiidae",
  "Philodromidae",
  "Tetragnathidae",
  "Theridiidae",
  "Thomisidae"
)

causal_families_no_spiders <-
  causal_families[!causal_families %in% spider_families]
print(sort(unique(causal_families_no_spiders)))

##################################################################################

fert_data <- data_for_ds22007$Fertilization
insect_data <- data_for_ds22007$ds22007_causal

regions <- c("ALB", "HAI", "SCH")
plot_data <- list()

trophic_groups <- data.frame(
  Family = c(
    "Acanthosomatidae","Alleculidae","Anobiidae","Anthocoridae",
    "Anthribidae","Aphodiidae","Apionidae","Aradidae",
    "Berytidae","Byturidae","Cantharidae","Carabidae",
    "Cerambycidae","Cerylonidae","Cholevidae","Chrysomelidae",
    "Cicadellidae","Cimberidae","Cisidae","Clambidae",
    "Cleridae","Coccinellidae","Colydiidae","Coreidae",
    "Corylophidae","Cryptophagidae","Curculionidae","Delphacidae",
    "Dermestidae","Dytiscidae","Elateridae","Endomychidae",
    "Erotylidae","Eucnemidae","Histeridae","Hydrophilidae",
    "Laemophloeidae","Lampyridae","Latridiidae","Leiodidae",
    "Lucanidae","Lycidae","Lygaeidae","Lymexylonidae",
    "Malachidae","Melandryidae","Melyridae","Microphysidae",
    "Miridae","Mordellidae","Mycetophagidae","Nabidae",
    "Nitidulidae","Oedemeridae","Omalisidae","Pentatomidae",
    "Phalacridae","Piesmatidae","Pselaphidae","Ptiliidae",
    "Ptinidae","Pyrochroidae","Rhizophagidae","Rhopalidae",
    "Rhynchitidae","Rhyparochromidae","Salpingidae","Scarabaeidae",
    "Scirtidae","Scolytidae","Scraptiidae","Scutelleridae",
    "Scydmaenidae","Silphidae","Staphylinidae","Tenebrionidae",
    "Tetratomidae","Tetrigidae","Throscidae","Thyreocoridae"
  ),
  TrophicGroup = c(
    "Herbivore","Herbivore","Wood-borer","Predator",
    "Fungivore","Coprophage","Herbivore","Fungivore",
    "Herbivore","Herbivore","Predator","Predator",
    "Wood-borer","Fungivore","Detritivore","Herbivore",
    "Herbivore","Herbivore","Fungivore","Fungivore",
    "Predator","Predator","Fungivore","Herbivore",
    "Fungivore","Fungivore","Herbivore","Herbivore",
    "Necrophage","Predator","Mixed","Fungivore",
    "Fungivore","Wood-borer","Predator","Detritivore",
    "Fungivore","Predator","Fungivore","Detritivore",
    "Wood-borer","Detritivore","Herbivore","Wood-borer",
    "Predator","Fungivore","Predator","Predator",
    "Mixed","Herbivore","Fungivore","Predator",
    "Mixed","Herbivore","Predator","Herbivore",
    "Fungivore","Herbivore","Predator","Fungivore",
    "Detritivore","Wood-borer","Predator","Herbivore",
    "Herbivore","Herbivore","Fungivore","Mixed",
    "Detritivore","Wood-borer","Fungivore","Herbivore",
    "Predator","Necrophage","Mixed","Detritivore",
    "Fungivore","Herbivore","Wood-borer","Herbivore"
  )
)
uniqueLtrophic_groups_no_spiders <- data.frame(
  Family = c(
    "Acanthosomatidae","Alleculidae","Anobiidae","Anthocoridae",
    "Anthribidae","Aphodiidae","Apionidae","Aradidae",
    "Berytidae","Byturidae","Cantharidae","Carabidae",
    "Cerambycidae","Cerylonidae","Cholevidae","Chrysomelidae",
    "Cicadellidae","Cimberidae","Cisidae","Clambidae",
    "Cleridae","Coccinellidae","Colydiidae","Coreidae",
    "Corylophidae","Cryptophagidae","Curculionidae","Delphacidae",
    "Dermestidae","Dytiscidae","Elateridae","Endomychidae",
    "Erotylidae","Eucnemidae","Histeridae","Hydrophilidae",
    "Laemophloeidae","Lampyridae","Latridiidae","Leiodidae",
    "Lucanidae","Lycidae","Lygaeidae","Lymexylonidae",
    "Malachidae","Melandryidae","Melyridae","Microphysidae",
    "Miridae","Mordellidae","Mycetophagidae","Nabidae",
    "Nitidulidae","Oedemeridae","Omalisidae","Pentatomidae",
    "Phalacridae","Piesmatidae","Pselaphidae","Ptiliidae",
    "Ptinidae","Pyrochroidae","Rhizophagidae","Rhopalidae",
    "Rhynchitidae","Rhyparochromidae","Salpingidae","Scarabaeidae",
    "Scirtidae","Scolytidae","Scraptiidae","Scutelleridae",
    "Scydmaenidae","Silphidae","Staphylinidae","Tenebrionidae",
    "Tetratomidae","Tetrigidae","Throscidae","Thyreocoridae"
  ),
  TrophicGroup = c(
    "Herbivore","Herbivore","Wood-borer","Predator",
    "Fungivore","Coprophage","Herbivore","Fungivore",
    "Herbivore","Herbivore","Predator","Predator",
    "Wood-borer","Fungivore","Detritivore","Herbivore",
    "Herbivore","Herbivore","Fungivore","Fungivore",
    "Predator","Predator","Fungivore","Herbivore",
    "Fungivore","Fungivore","Herbivore","Herbivore",
    "Necrophage","Predator","Mixed","Fungivore",
    "Fungivore","Wood-borer","Predator","Detritivore",
    "Fungivore","Predator","Fungivore","Detritivore",
    "Wood-borer","Detritivore","Herbivore","Wood-borer",
    "Predator","Fungivore","Predator","Predator",
    "Mixed","Herbivore","Fungivore","Predator",
    "Mixed","Herbivore","Predator","Herbivore",
    "Fungivore","Herbivore","Predator","Fungivore",
    "Detritivore","Wood-borer","Predator","Herbivore",
    "Herbivore","Herbivore","Fungivore","Mixed",
    "Detritivore","Wood-borer","Fungivore","Herbivore",
    "Predator","Necrophage","Mixed","Detritivore",
    "Fungivore","Herbivore","Wood-borer","Herbivore"
  )
)

######################## Log-linear regression insects #############################
#Change data set names for plot labels
dataset_labels <- c(
  ds21969 = "Grassland",
  ds22007 = "Forest"
)

# --------------------------------------------------
# FUNCTION: LOG-LINEAR REGRESSION + % LABELS
# --------------------------------------------------#
create_loglinear_plot <- function(causal_data, dataset_name) {
  
  causal_data <- causal_data %>%
    mutate(Family = as.character(Family)) %>%
    filter(NumberAdults > 0)
  
  trophic_groups_local <- trophic_groups %>%
    mutate(Family = as.character(Family))
  
  # ---- Add Trophic Groups
  causal_data <- causal_data %>%
    left_join(trophic_groups_local, by = "Family") %>%
    mutate(
      Region = factor(Exploratory, levels = c("ALB","HAI","SCH")),
      TrophicGroup = factor(
        TrophicGroup,
        levels = c("Coprophage","Detritivore","Fungivore","Herbivore","Mixed","Necrophage","Predator","Wood-borer")
      )
    )
  
  # ---- Log-linear models + % change
  trend_labels <- causal_data %>%
    group_by(Region, TrophicGroup) %>%
    summarise(
      n_points = n(),
      model = list(if(n_points > 1) lm(log10(NumberAdults) ~ year, data = cur_data()) else NULL),
      .groups = "drop"
    ) %>%
    rowwise() %>%
    mutate(
      perc_change = if(!is.null(model)) {
        beta <- coef(model)[2]
        (10^beta - 1) * 100
      } else {
        NA_real_  # Kein Label, wenn nur ein Punkt
      },
      year = max(causal_data$year) + 0.5,
      NumberAdults = if(!is.null(model)) {
        10^(predict(model, newdata = data.frame(year = max(causal_data$year))))
      } else {
        NA_real_  # Kein Label, wenn nur ein Punkt
      }
    ) %>%
    filter(!is.na(NumberAdults)) %>%  # entfernt alle Zeilen ohne Label
    ungroup()
  
  
  # ---- Plot
  ggplot(causal_data, aes(x = year, y = NumberAdults, color = TrophicGroup)) +
    geom_point(alpha = 0.7) +
    geom_smooth(
      method = "lm",
      formula = y ~ x,
      se = FALSE,
      linewidth = 0.8
    ) +
    geom_text_repel(
      data = trend_labels,
      aes(
        x = year,
        y = NumberAdults,
        label = paste0(
          ifelse(perc_change > 0, "+", ""),
          round(perc_change, 1), "% / yr"
        )
      ),
      hjust = 0,
      size = 4,
      show.legend = FALSE,
      direction = "y"
    ) +
    scale_y_log10() +
    facet_wrap(~Region, ncol = 1, scales = "free_y") +
    scale_x_continuous(breaks = unique(causal_data$year)) +
    scale_color_manual(
      values = c(
        "Coprophage"   = "#E41A1C",  
        "Detritivore"  = "#377EB8",  
        "Fungivore"    = "#4DAF4A",  
        "Herbivore"    = "#FF7F00",  
        "Mixed"        = "#984EA3",  
        "Necrophage"   = "darkblue",  
        "Predator"     = "#A65628",  
        "Wood-borer"   = "#F781BF"   
      )
    ) + 
    labs(
      title = paste0(dataset_labels[dataset_name], " – Log-linear trends by Trophic Group"),
      x = "Year",
      y = "Number of Adults (log scale)",
      color = "Trophic Group"
    ) +
    theme_light(base_size = 14) +
    theme(
      strip.text = element_text(face="bold", size=14),
      plot.title = element_text(size=18, face="bold"),
      axis.text.x = element_text(angle=45, hjust=1),
      legend.position = "bottom"
    )
}

# --------------------------------------------------
# ds22007
# --------------------------------------------------
ds22007_causal <- data_for_ds22007$ds22007 %>%
  filter(Family %in% causal_families_no_spiders)

plot_ds22007 <- create_loglinear_plot(ds22007_causal, "ds22007")

# --------------------------------------------------
# ds21969
# --------------------------------------------------
ds21969_causal <- data_for_ds21969$ds21969 %>%
  filter(Family %in% causal_families_no_spiders)

plot_ds21969 <- create_loglinear_plot(ds21969_causal, "ds21969")

# --------------------------------------------------
# SAVE PLOTS
# --------------------------------------------------
ggsave(
  filename = "./plots/linear_regression/ds22007_loglinear_percent_new.png",
  plot = plot_ds22007,
  width = 8.27, height = 11.69, units = "in", dpi = 300
)

ggsave(
  filename = "./plots/linear_regression/ds21969_loglinear_percent_new.png",
  plot = plot_ds21969,
  width = 8.27, height = 11.69, units = "in", dpi = 300
)


####################### Log-linear regression fertilizer #####################

selected_croptypes <- c("Wheat", "Other Cereals", "Other Oilseeds")

Fertilization_filtered <- data_for_ds22007$Fertilization %>%
  filter(year >= 2008 & year <= 2019) %>%
  filter(Croptype %in% selected_croptypes) %>%
  pivot_longer(
    cols = c(ALB, HAI, SCH),
    names_to = "Region",
    values_to = "Value"
  ) %>%
  group_by(Croptype, Region, Fertilizer) %>%
  filter(max(Value, na.rm = TRUE) > 0.5) %>%
  ungroup() %>%
  mutate(
    Region = factor(Region, levels = c("ALB", "HAI", "SCH")),
    Croptype = factor(Croptype, levels = selected_croptypes)
  )

# ---- Log-linear models + % change
trend_labels <- Fertilization_filtered %>%
  group_by(Region, Croptype, Fertilizer) %>%
  summarise(
    model = list(lm(log10(Value) ~ year, data = cur_data())),
    .groups = "drop"
  ) %>%
  rowwise() %>%
  mutate(
    beta = coef(model)[2],
    perc_change = (10^beta - 1) * 100,
    year = max(Fertilization_filtered$year) + 0.3,  # Label slightly shifted to the right
    Value = 10^(predict(model, newdata = data.frame(year = max(Fertilization_filtered$year))))
  ) %>%
  ungroup()

# ---- Plot
fert_plot <- ggplot(Fertilization_filtered, aes(x = year, y = Value, color = Fertilizer)) +
  geom_line(linewidth = 1) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, linetype = "dashed", linewidth = 0.8) +
  geom_text_repel(
    data = trend_labels,
    aes(
      x = year,
      y = Value,
      label = paste0(ifelse(perc_change > 0, "+", ""), round(perc_change, 1), "% / yr")
    ),
    size = 3,
    show.legend = FALSE,
    direction = "y"
  ) +
  facet_grid(Region ~ Croptype, scales = "free_y") +
  scale_x_continuous(breaks = seq(2008, 2019, by = 1)) +
  scale_y_log10() +
  labs(
    title = "Fertilizer Application Rates – Log-linear Trends",
    x = "Year",
    y = "Application Rate [kg/ha] (log scale)",
    color = "Fertilizer"
  ) +
  theme_light(base_size = 14) +
  theme(
    strip.text = element_text(face = "bold", size = 10),
    plot.title = element_text(face = "bold", size = 16),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  )

# ---- Save Plot
ggsave(
  filename = "./plots/linear_regression/Fertilization_selected_Crops_loglinear_percent_DINA4.png",
  plot = fert_plot,
  width = 11.69, height = 8.27, units = "in", dpi = 300
)

