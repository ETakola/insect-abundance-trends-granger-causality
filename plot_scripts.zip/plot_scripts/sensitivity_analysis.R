###############################SENSITIVITY ANALYSIS################################
#Two objectives: 
#1) Lag sensitivity: Is Granger Causality sensitive to lags? 
#2) Time Aggregation Sensitivity: Does a causal relationship appear at multiple temporal resolution?
###################################################################################

############################## load packages ################################
library(dplyr)
library(ggplot2)
library(tidyr)
library(forcats)
library(scales)
library(stringr)
library(grid)  # for unit()

#####stationarity tables  from first round to build the lists ###############
#combined results from ADF/KPSS test - yearly 
stationarity_table_ds21969_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_yearly.csv", sep =";")
stationarity_table_ds22007_yearly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_yearly.csv", sep =";")

stationarity_table_ds22007_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep =",")
stationarity_table_ds21969_ALB_HAI_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv" , sep =",")
stationarity_table_ds21969_SCH_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv" , sep =",")

#####combined stationarity tables with detrended/differenced data#######
##ds21969
#yearly
ds21969_both_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_yearly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds21969_detrended_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_yearly_Kopie.csv", sep =",") %>%
  filter(ADF_status == "stationary", KPSS_status == "stationary")
ds21969_differenced_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_yearly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

#monthly
ds21969_both_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_monthly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds21969_detrended_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_monthly_ALL.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds21969_differenced_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_monthly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

##ds22007
#yearly
ds22007_both_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_yearly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds22007_detrended_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_yearly_Kopie.csv", sep =",") %>%
  filter(ADF_status == "stationary", KPSS_status == "stationary")
ds22007_differenced_yearly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_yearly.csv", sep =",") %>%
  filter(ADF_status == "stationary", KPSS_status == "stationary")
#monthly
ds22007_both_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_monthly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds22007_detrended_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_monthly.csv", sep =",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")
ds22007_differenced_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_monthly.csv", sep =",") %>%
  filter(adf_status == "stationary", kpss_status == "stationary")

##########results 2nd round######################################
#results from granger test
granger_results_ds21969_ALB_2nd_round <- read.csv("./tables/granger_test/results_ds21969_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_HAI_2nd_round <- read.csv("./tables/granger_test/results_ds21969_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_SCH_2nd_round <- read.csv("./tables/granger_test/results_ds21969_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds22007_ALB_2nd_round <- read.csv("./tables/granger_test/results_ds22007_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds22007_HAI_2nd_round <- read.csv("./tables/granger_test/results_ds22007_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds22007_SCH_2nd_round <- read.csv("./tables/granger_test/results_ds22007_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds21969_ALB_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_ALB_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_HAI_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_HAI_2nd_round_Kopie.csv", sep=",")
granger_results_ds21969_SCH_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds21969_monthly_SCH_2nd_round_Kopie.csv", sep=",")

granger_results_ds22007_ALB_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_ALB_monthly_clean_Kopie.csv", sep=",")
granger_results_ds22007_HAI_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_HAI_monthly_clean_Kopie.csv", sep=",")
granger_results_ds22007_SCH_monthly_2nd_round <- read.csv("./tables/granger_test/results_ds22007_SCH_monthly_clean_Kopie.csv", sep=",")


################################################################
#--------------------------------------------
# Sensitivity Analysis for ds21969 & ds22007
#--------------------------------------------

#--------------------------------------------
# Put all Granger Data together
#--------------------------------------------
all_granger_2nd <- bind_rows(
  # ds21969
  granger_results_ds21969_ALB_2nd_round %>% mutate(Dataset = "ds21969", EnvColumn="ALB"),
  granger_results_ds21969_HAI_2nd_round %>% mutate(Dataset = "ds21969", EnvColumn="HAI"),
  granger_results_ds21969_SCH_2nd_round %>% mutate(Dataset = "ds21969", EnvColumn="SCH"),
  granger_results_ds21969_ALB_monthly_2nd_round %>% mutate(Dataset = "ds21969_monthly", EnvColumn="ALB"),
  granger_results_ds21969_HAI_monthly_2nd_round %>% mutate(Dataset = "ds21969_monthly", EnvColumn="HAI"),
  granger_results_ds21969_SCH_monthly_2nd_round %>% mutate(Dataset = "ds21969_monthly", EnvColumn="SCH"),
  
  # ds22007
  granger_results_ds22007_ALB_2nd_round %>% mutate(Dataset = "ds22007", EnvColumn="ALB"),
  granger_results_ds22007_HAI_2nd_round %>% mutate(Dataset = "ds22007", EnvColumn="HAI"),
  granger_results_ds22007_SCH_2nd_round %>% mutate(Dataset = "ds22007", EnvColumn="SCH"),
  granger_results_ds22007_ALB_monthly_2nd_round %>% mutate(Dataset = "ds22007_monthly", EnvColumn="ALB"),
  granger_results_ds22007_HAI_monthly_2nd_round %>% mutate(Dataset = "ds22007_monthly", EnvColumn="HAI"),
  granger_results_ds22007_SCH_monthly_2nd_round %>% mutate(Dataset = "ds22007_monthly", EnvColumn="SCH")
)

#######################REMOVE PLACE HOLDER + SPIDER FAMILIES################
spider_families <- c(
  "Araneidae",
  "Dictynidae",
  "Linyphiidae",
  "Lycosidae",
  "Philodromidae",
  "Salticidae",
  "Tetragnathidae",
  "Theridiidae",
  "Thomisidae"
)
remove_families <- c(spider_families, "Fam.")

all_granger_2nd_clean <- subset(all_granger_2nd,!Family %in% remove_families)

##############################LAG SENSITIVITY###############################

# Filter only causal Granger Tests
granger <- all_granger_2nd_clean %>%
  mutate(Region = EnvColumn)  # extract region from EnvColumn 

# Calculate proportions of causality categories per dataset, lag and region
granger_summary <- granger %>%
  group_by(Dataset, Region, Lag, causality) %>%
  summarise(count = n(), .groups = "drop") %>%
  group_by(Dataset, Region, Lag) %>%
  mutate(percent = count / sum(count) * 100)

granger_summary$causality <- factor(
  granger_summary$causality,
  levels = c("no_test", "causal", "non-causal")  
)

# Plot
lag <- ggplot(granger_summary, aes(x = factor(Lag), y = percent, fill = causality)) +
  geom_bar(stat = "identity") +
  facet_grid(Region ~ Dataset) +  # vertikal: Region, horizontal: Dataset
  scale_y_continuous(labels = percent_format(scale = 1)) +
  scale_fill_manual(values = c(
    "causal" = "#0072B2",
    "non-causal" = "#D55E00",
    "no_test" = "grey90"
  )) +
  ggtitle("Distribution of Causality Categories by Lag, Dataset, and Region") +
  labs(
    x = "Lag",
    y = "Relative frequency of Causality Categories [%]",
    fill = "Causality Category"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 18),          
    axis.title = element_text(size = 15),                       
    axis.text = element_text(size = 13),      
    legend.title = element_text(size = 13),                     
    legend.text = element_text(size = 13),                      
    strip.text = element_text(size = 15)                       
  )

lag

# Save as .png
ggsave(
  "./plots/sensitivity_analysis/lag_sensitivity_plot_.png",
  lag,
  width = 15,
  height = 11,
  dpi = 300,
  bg = "white"
)


##################### TIME AGGREGATION SENSITIVITY ####################
# 1. Dataset for Facets
all_granger_2nd <- all_granger_2nd_clean %>%
  mutate(
    Dataset_facet = case_when(
      Dataset %in% c("ds21969", "ds21969_monthly") ~ "ds21969",
      Dataset %in% c("ds22007", "ds22007_monthly") ~ "ds22007",
      TRUE ~ Dataset
    ),
    time_res = case_when(
      Dataset %in% c("ds21969", "ds22007") ~ "Yearly",
      Dataset %in% c("ds21969_monthly", "ds22007_monthly") ~ "Monthly",
      TRUE ~ NA_character_
    )
  )

# 2. calculate procentual proportions per Dataset_facet / Region / time_res / causality 

  group_by(Dataset_facet, EnvColumn, time_res, causality) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(Dataset_facet,EnvColumn, time_res) %>%
  mutate(percent = n / sum(n) * 100) %>%
  ungroup()

# 3. Factor levels for causality and dataset_facet 
plot_data$causality <- factor(
  plot_data$causality,
  levels = c("no_test", "causal", "non-causal")
)

plot_data$Dataset_facet <- factor(plot_data$Dataset_facet, levels = c("ds21969", "ds22007"))

# 4. stapled barplot
p_causality <- ggplot(plot_data, aes(x = time_res, y = percent, fill = causality)) +
  geom_bar(stat = "identity", width = 0.7) +
  facet_grid(Dataset_facet ~ EnvColumn) +  # nur 2 Facets vertikal
  scale_y_continuous(labels = scales::percent_format(scale = 1), limits = c(0,100)) +
  scale_fill_manual(values = c(
    "causal" = "#0072B2",
    "non-causal" = "#D55E00",
    "no_test" = "grey90"
  )) +
  labs(
    title = "Causality Distribution by Time Resolution, Dataset, and Region",
    x = "Time Resolution",
    y = "Proportion of Causality Categories [%]",
    fill = "Causality Category"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 16, face = "bold"),
    axis.title.y = element_text(size = 16, face = "bold"),
    axis.text.x = element_text(size = 14, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 14),
    strip.text.x = element_text(size = 16, face = "bold"),
    strip.text.y = element_text(size = 16, face = "bold"),
    legend.title = element_text(size = 16),
    legend.text = element_text(size = 14),
    panel.spacing = unit(2, "lines"),
    panel.grid.major = element_line(color = "grey80", linewidth = 0.5),
    panel.grid.minor = element_line(color = "grey90", linewidth = 0.3),
    plot.background = element_rect(fill = "white", color = NA)
  )

p_causality

# 5. Save 
ggsave(
  filename = "stacked_causality_time_res_2facets.png",
  path = "./plots/sensitivity_analysis",
  plot = p_causality,
  width = 15,
  height = 11,
  dpi = 300,
  bg = "white"
)
