################################# CREATE FACETPLOTS ######################################
############################
## LOAD REQUIRED PACKAGES
############################
library(tidyverse)

############################
## LOAD DATASETS
############################
# Load datasets and standardize temporal columns (year and month)

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite-derived vegetation indices: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite-derived vegetation indices: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite-derived vegetation indices: NIRv (Near Infrared Reflectance of Vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means per plot)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: convert datetime to year/month and assign regional labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Crop yield and cultivated area datasets
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset ds21969 (already filtered)
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters into numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun letters to numeric months
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Map letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable

############################
## SETTINGS
############################
YEAR_MIN <- 2008
YEAR_MAX <- 2019

FIG_DIR <- "./plots/facetplots"
dir.create(FIG_DIR, recursive = TRUE, showWarnings = FALSE)


############################
## RENAME COLUMNS TO INCLUDE UNITS
############################

new_names <- names(weather)

# Precipitation
new_names <- gsub("^precipitation_radolan_rain_days$", 
                  "rain_days [days]", new_names)
new_names <- gsub("^precipitation_radolan$", 
                  "precipitation [mm]", new_names)

# Relative humidity
new_names <- gsub("^rH_200$", "rH_200 [%]", new_names)
new_names <- gsub("^rH_200_max$", "rH_200_max [%]", new_names)
new_names <- gsub("^rH_200_min$", "rH_200_min [%]", new_names)

# Soil moisture
new_names <- gsub("^SM_10$", "SM_10 [%]", new_names)
new_names <- gsub("^SM_20$", "SM_20 [%]", new_names)

# Air temperature
new_names <- gsub("^Ta_10$", "Ta_10 [°C]", new_names)
new_names <- gsub("^Ta_10_max$", "Ta_10_max [°C]", new_names)
new_names <- gsub("^Ta_10_min$", "Ta_10_min [°C]", new_names)
new_names <- gsub("^Ta_200$", "Ta_200 [°C]", new_names)
new_names <- gsub("^Ta_200_max$", "Ta_200_max [°C]", new_names)
new_names <- gsub("^Ta_200_min$", "Ta_200_min [°C]", new_names)

# Soil temperature
new_names <- gsub("^Ts_05$", "Ts_05 [°C]", new_names)
new_names <- gsub("^Ts_05_max$", "Ts_05_max [°C]", new_names)
new_names <- gsub("^Ts_05_min$", "Ts_05_min [°C]", new_names)
new_names <- gsub("^Ts_10$", "Ts_10 [°C]", new_names)
new_names <- gsub("^Ts_10_max$", "Ts_10_max [°C]", new_names)
new_names <- gsub("^Ts_10_min$", "Ts_10_min [°C]", new_names)
new_names <- gsub("^Ts_20$", "Ts_20 [°C]", new_names)
new_names <- gsub("^Ts_20_max$", "Ts_20_max [°C]", new_names)
new_names <- gsub("^Ts_20_min$", "Ts_20_min [°C]", new_names)
new_names <- gsub("^Ts_50$", "Ts_50 [°C]", new_names)
new_names <- gsub("^Ts_50_max$", "Ts_50_max [°C]", new_names)
new_names <- gsub("^Ts_50_min$", "Ts_50_min [°C]", new_names)

names(weather) <- new_names

# Mosaic dataset
new_names <- names(mosaic)
new_names <- gsub("normal", "normal [–]", new_names)
new_names <- gsub("cellsize", "cellsize [ha]", new_names)
new_names <- gsub("dendrites", "dendrites [–]", new_names)
new_names <- gsub("relation", "relation [–]", new_names)
names(mosaic) <- new_names

# Fertilization: include units for fertilizer column
Fertilization$Fertilizer <- paste0(Fertilization$Fertilizer, " [kg/ha]")

# Function to adjust measure column for crop datasets
adjust_measure <- function(df) {
  df$measure <- ifelse(df$measure == "area", "area [ha]",
                       ifelse(df$measure == "yield", "yield [t/ha]", df$measure))
  return(df)
}

ALB_crop <- adjust_measure(ALB_crop)
HAI_crop <- adjust_measure(HAI_crop)
SCH_crop <- adjust_measure(SCH_crop)

############################
## CREATE ENVIRONMENTAL DATA IN LONG FORMAT (INCLUDING MOSAIC)
############################
make_env_yearly <- function(YEAR_MIN = 2008, YEAR_MAX = 2019) {
  
  # ---- Weather aggregation function ----
  aggregate_weather <- function(weather_df) {
    
    sum_cols <- c("precipitation [mm]", "rain_days [days]")
    mean_cols <- setdiff(names(weather_df)[sapply(weather_df, is.numeric)],
                         c(sum_cols, "year", "month"))
    
    # Step 1: Aggregate per plotID per year
    weather_annual <- weather_df %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(plotID, year) %>%
      summarise(
        region = first(region),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        across(all_of(mean_cols), mean, na.rm = TRUE),
        .groups = "drop"
      )
    
    # Step 2: Aggregate per region per year
    weather_region <- weather_annual %>%
      group_by(region, year) %>%
      summarise(
        across(all_of(sum_cols), mean, na.rm = TRUE),  # Mean of summed precipitation & rain days
        across(all_of(mean_cols), mean, na.rm = TRUE), # Mean of other variables
        .groups = "drop"
      )
    
    return(weather_region)
  }
  
  # Call weather aggregation
  weather_region <- aggregate_weather(weather)
  
  env <- bind_rows(
    
    ## ---- SMI (annual mean) ----
    SMI_total %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      pivot_longer(cols = c(ALB, HAI, SCH), names_to = "region", values_to = "value") %>%
      group_by(year, region) %>%
      summarise(value = mean(value, na.rm = TRUE), .groups = "drop") %>%
      mutate(dataset="SMI", variable="SMI total [–]"),
    
    SMI_upsoil %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      pivot_longer(cols = c(ALB, HAI, SCH), names_to = "region", values_to = "value") %>%
      group_by(year, region) %>%
      summarise(value = mean(value, na.rm = TRUE), .groups = "drop") %>%
      mutate(dataset="SMI", variable="SMI topsoil [–]"),
    
    ## ---- NDVI (annual mean per region) ----
    NDVI_ALB %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDVI, na.rm = TRUE)) %>%
      mutate(region="ALB", dataset="Satellite", variable="NDVI [–]"),
    NDVI_HAI %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDVI, na.rm = TRUE)) %>%
      mutate(region="HAI", dataset="Satellite", variable="NDVI [–]"),
    NDVI_SCH %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDVI, na.rm = TRUE)) %>%
      mutate(region="SCH", dataset="Satellite", variable="NDVI [–]"),
    
    ## ---- NDMI (annual mean) ----
    NDMI_ALB %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDMI, na.rm = TRUE)) %>%
      mutate(region="ALB", dataset="Satellite", variable="NDMI [–]"),
    NDMI_HAI %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDMI, na.rm = TRUE)) %>%
      mutate(region="HAI", dataset="Satellite", variable="NDMI [–]"),
    NDMI_SCH %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NDMI, na.rm = TRUE)) %>%
      mutate(region="SCH", dataset="Satellite", variable="NDMI [–]"),
    
    ## ---- NIRv (annual mean) ----
    NIRv_ALB %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NIRv, na.rm = TRUE)) %>%
      mutate(region="ALB", dataset="Satellite", variable="NIRv [–]"),
    NIRv_HAI %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NIRv, na.rm = TRUE)) %>%
      mutate(region="HAI", dataset="Satellite", variable="NIRv [–]"),
    NIRv_SCH %>% filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year) %>% summarise(value = mean(mean_NIRv, na.rm = TRUE)) %>%
      mutate(region="SCH", dataset="Satellite", variable="NIRv [–]"),
    
    ## ---- WEATHER ----
    weather_region %>%
      pivot_longer(-c(year, region), names_to="variable", values_to="value") %>%
      filter(!is.nan(value)) %>%  # Remove NaNs
      mutate(dataset="Weather"),
    
    ## ---- MOSAIC ----
    mosaic %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      pivot_longer(cols = c("normal [–]", "cellsize [ha]", "dendrites [–]", "relation [–]"),
                   names_to = "variable",
                   values_to = "value") %>%
      mutate(dataset="Germany Mosaic"),
    
    ## ---- CROPS ----
    bind_rows(
      ALB_crop %>% mutate(region="ALB"),
      HAI_crop %>% mutate(region="HAI"),
      SCH_crop %>% mutate(region="SCH")
    ) %>%
      filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
      group_by(year, region, var, measure) %>%
      summarise(value = mean(weighted_value_sum, na.rm=TRUE), .groups="drop") %>%
      mutate(dataset="Crops",
             variable = paste(var, measure, sep=" – "))
  )
  
  # Force factor order for plotting
  env$dataset <- factor(env$dataset,
                        levels = c("Grasslands","Forests","SMI","Satellite","Weather","Germany Mosaic","Crops","Fertilization"))
  
  return(env)
}

# -----------------------------
# Create env_yearly for 2008–2019
# -----------------------------
env_yearly <- make_env_yearly(YEAR_MIN = 2008, YEAR_MAX = 2019)

env_yearly <- env_yearly %>%
  mutate(dataset = recode(dataset,
                          "ds21969" = "Grasslands",
                          "ds22007" = "Forests"))

env_yearly <- env_yearly %>%
  mutate(variable = stringr::str_replace(variable,
                                         "\\[NumberAdults\\]",
                                         "[Adults]"))

############################
## FERTILIZATION DATA (SEPARATE)
############################
fert_yearly <- Fertilization %>%
  filter(year >= YEAR_MIN, year <= YEAR_MAX) %>%
  pivot_longer(cols=c(ALB,HAI,SCH), names_to="region", values_to="value") %>%
  mutate(
    dataset="Fertilization",
    variable = paste(Croptype, Fertilizer, sep=" – "),
    variable = factor(variable, levels = unique(variable)) # Force factor
  )

fert_yearly <- fert_yearly %>%
  mutate(variable = variable %>%
           stringr::str_replace("Fiber crops", "Fiber") %>%
           stringr::str_replace("Fruits", "Fruit") %>%
           stringr::str_replace("Other Cereals", "Oth. Cereals") %>%
           stringr::str_replace("Other Oilseeds", "Oth. Oilseeds") %>%
           stringr::str_replace("Other crops", "Oth. Crops") %>%
           stringr::str_replace("Palm Oil fruit", "Palm oil") %>%
           stringr::str_replace("Roots and tubers", "Roots & tub.") %>%
           stringr::str_replace("Sugar crops", "Sugar") %>%
           stringr::str_replace("Vegetables", "Veg.")
  )

############################
## INSECT DATA PREPARATION
############################
prepare_insects <- function(df, name) {
  df %>%
    filter(year >= YEAR_MIN, year <= YEAR_MAX,
           Order != "Araneae") %>%
    group_by(year, Exploratory, Order) %>%
    summarise(value=sum(NumberAdults, na.rm=TRUE), .groups="drop") %>%
    rename(region=Exploratory, variable=Order) %>%
    mutate(dataset=name,
           variable=paste0(variable, " [NumAdults]"))
}


############################
## PLOTTING FUNCTION
############################
plot_a4 <- function(df, region, dataset_name) {
  
  # Control dataset factor to place insects on top
  df$dataset <- factor(df$dataset,
                       levels=c("Grasslands","Forests","SMI","Satellite","Weather","Germany Mosaic","Crops","Fertilization"))
  
  p <- ggplot(df %>% filter(region==!!region),
              aes(x=year, y=value)) +
    geom_line() +
    facet_wrap(~dataset + variable, scales="free_y", ncol=4) +
    theme_bw() +
    theme(
      strip.text = element_text(size=9),
      axis.text = element_text(size=7.5),
      axis.title = element_blank()
    ) +
    scale_x_continuous(
      breaks = seq(YEAR_MIN, YEAR_MAX, 2)
    ) +
    scale_y_continuous(
      breaks = scales::pretty_breaks(n = 3)   
    )
  
  ggsave(
    filename = file.path(FIG_DIR, paste0("A4_", dataset_name, "_", region, ".png")),
    plot = p,
    width = 8.27,
    height = 11.69,
    dpi = 300
  )
}


############################
## FINAL EXECUTION
############################
for (reg in c("ALB","HAI","SCH")) {
  
  ## Grasslands insects + environment
  df_grass <- bind_rows(
    prepare_insects(ds21969, "Grasslands"),
    env_yearly
  )
  plot_a4(df_grass, reg, "Grasslands")
  
  # Grasslands + fertilization
  plot_a4(
    bind_rows(prepare_insects(ds21969, "Grasslands"), fert_yearly),
    reg,
    "Grasslands_fertilization"
  )
  
  ## Forests insects + environment
  df_forest <- bind_rows(
    prepare_insects(ds22007, "Forests"),
    env_yearly
  )
  plot_a4(df_forest, reg, "Forests")
  
  # Forests + fertilization
  plot_a4(
    bind_rows(prepare_insects(ds22007, "Forests"), fert_yearly),
    reg,
    "Forests_fertilization"
  )
}
