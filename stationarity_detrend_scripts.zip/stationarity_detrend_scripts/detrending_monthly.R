####################### DETRENDING; DIFFERENCING; BOTH ################################
################################# load packages #######################################
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests

#################### load data ##############################
# and harmonize names for the "year" and "month" columns
#################### Load data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Moisture Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

############################################################################################
#Load insect data 

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Ergebnis anzeigen
print(ds21969_summary)

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable

##########################################################################

# Combined ADF/KPSS results for ds21969 (monthly)
stationarity_table_ds21969_ALB_HAI_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv",
  sep =","
)
stationarity_table_ds21969_SCH_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv",
  sep =","
)

# Combined ADF/KPSS results for ds22007 (monthly)
stationarity_table_ds22007_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv",
  sep =","
)

############################## data list for easier handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  weather = weather,
  ds21969 = ds21969,
  ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  weather = list(type ="grouped", group_cols = c("region"),
                 value_cols = names(weather)[3:39]),
  ds21969 = list(type ="grouped", group_cols = c("Exploratory", "Family"),
                 value_cols = c("NumberAdults")),
  ds22007 = list(type ="grouped", group_cols = c("Exploratory", "Family"),
                 value_cols = c("NumberAdults"))
)


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1) Convert month to numeric and determine year range
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>% mutate(month_num = as.numeric(month))
years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# Determine months for ALB & HAI, and SCH
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
months_SCH     <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

cat("Months ALB & HAI:", paste(months_ALB_HAI, collapse = ", "), "\n")
cat("Months SCH:", paste(months_SCH, collapse = ", "), "\n")
cat("Year range ds21969:", paste(years_ds21969, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2) Select all monthly datasets (exclude Fertilization, mosaic, crop datasets, ds22007)
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in%
                                c("Fertilization", "mosaic",
                                  "ALB_crop", "HAI_crop", "SCH_crop",
                                  "ds22007")]

# ------------------------------------------------------------------------------
# 3) Function to filter by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4) Apply filter for ALB & HAI
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[
  !names(data_for_ds21969_ALB_HAI) %in% c("ds22007")
]

# Add ds21969 ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>%
  filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# 5) Special handling for Weather (monthly, ALB & HAI)
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds21969_ALB_HAI)) {
  
  numeric_weather_cols <- data_for_ds21969_ALB_HAI$weather %>%
    select(where(is.numeric)) %>%
    select(-year, -month, -month_num) %>%
    names()
  
  data_for_ds21969_ALB_HAI$weather <- data_for_ds21969_ALB_HAI$weather %>%
    group_by(region, year, month_num) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    rename(month = month_num)
  
  cat("Weather dataset aggregated monthly by region for ds21969 (ALB & HAI).\n")
}

# ------------------------------------------------------------------------------
# 6) Apply filter for SCH
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[
  !names(data_for_ds21969_SCH) %in% c("ds22007")
]

# Add ds21969 SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>%
  filter(Exploratory == "SCH")

# ------------------------------------------------------------------------------
# 7) Special handling for Weather (monthly, SCH)
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds21969_SCH)) {
  
  numeric_weather_cols <- data_for_ds21969_SCH$weather %>%
    select(where(is.numeric)) %>%
    select(-year, -month, -month_num) %>%
    names()
  
  data_for_ds21969_SCH$weather <- data_for_ds21969_SCH$weather %>%
    group_by(region, year, month_num) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    rename(month = month_num)
  
  cat("Weather dataset aggregated monthly by region for ds21969 (SCH).\n")
}

################################################################################
# Result: two lists
# data_for_ds21969_ALB_HAI
# data_for_ds21969_SCH
################################################################################

############################# FILTERING FOR DETRENDING ########################
################## Select only stationary datasets from table ##################
# monthly
ds21969_stationary_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_stationary_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")


################## Select only datasets that require detrending from table ##################
# monthly
ds21969_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds21969_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

# ----------------------------
# Adjusted stationarity function for ds21969 format
# ----------------------------
run_stationarity_ds21969 <- function(df, cols, time_col="year", dataset_name=NULL){
  
  results <- tibble()
  
  for(col in cols){
    
    if(col == "NumberAdults" & all(c("Exploratory","Family") %in% names(df))){
      grouped <- df %>% group_by(Exploratory, Family) %>% group_split()
      
      for(gr in grouped){
        x <- na.omit(gr[[col]])
        if(length(x) < 3) {
          adf_stat=NA; adf_p=NA; kpss_stat=NA; kpss_p=NA
        } else {
          adf_res <- tryCatch(adf.test(x), error=function(e) list(statistic=NA,p.value=NA))
          kpss_res <- tryCatch(kpss.test(x), error=function(e) list(statistic=NA,p.value=NA))
          adf_stat <- as.numeric(adf_res$statistic)
          adf_p <- as.numeric(adf_res$p.value)
          kpss_stat <- as.numeric(kpss_res$statistic)
          kpss_p <- as.numeric(kpss_res$p.value)
        }
        
        recommended <- if(!is.na(adf_p) & adf_p>0.05 & !is.na(kpss_p) & kpss_p>0.05) {
          "Detrend time series and check for stationarity again (trend stationary)"
        } else {
          "Stationary"
        }
        
        results <- bind_rows(results,
                             tibble(
                               dataset = dataset_name,
                               variable = col,
                               statistic_adf = adf_stat,
                               p_value_adf = adf_p,
                               status_adf = ifelse(!is.na(adf_p) & adf_p<0.05,"stationary","non-stationary"),
                               Exploratory = gr$Exploratory[1],
                               Family = gr$Family[1],
                               statistic_kpss = kpss_stat,
                               p_value_kpss = kpss_p,
                               status_kpss = ifelse(!is.na(kpss_p) & kpss_p<0.05,"non-stationary","stationary"),
                               recommended_action = recommended
                             )
        )
      }
      
    } else {
      # Other variables
      x <- na.omit(df[[col]])
      if(length(x) < 3) {adf_stat=NA; adf_p=NA; kpss_stat=NA; kpss_p=NA} 
      else {
        adf_res <- tryCatch(adf.test(x), error=function(e) list(statistic=NA,p.value=NA))
        kpss_res <- tryCatch(kpss.test(x), error=function(e) list(statistic=NA,p.value=NA))
        adf_stat <- as.numeric(adf_res$statistic)
        adf_p <- as.numeric(adf_res$p.value)
        kpss_stat <- as.numeric(kpss_res$statistic)
        kpss_p <- as.numeric(kpss_res$p.value)
      }
      
      recommended <- if(!is.na(adf_p) & adf_p>0.05 & !is.na(kpss_p) & kpss_p>0.05) {
        "Detrend time series and check for stationarity again (trend stationary)"
      } else {
        "Stationary"
      }
      
      results <- bind_rows(results,
                           tibble(
                             dataset = dataset_name,
                             variable = col,
                             statistic_adf = adf_stat,
                             p_value_adf = adf_p,
                             status_adf = ifelse(!is.na(adf_p) & adf_p<0.05,"stationary","non-stationary"),
                             Exploratory = NA_character_,
                             Family = NA_character_,
                             statistic_kpss = kpss_stat,
                             p_value_kpss = kpss_p,
                             status_kpss = ifelse(!is.na(kpss_p) & kpss_p<0.05,"non-stationary","stationary"),
                             recommended_action = recommended
                           )
      )
    }
  }
  return(results)
}

# ----------------------------
# Apply to detrended ALB_HAI and SCH datasets
# ----------------------------
stationarity_ALB_HAI <- map2(
  ds21969_ALB_HAI_detrended,
  names(ds21969_ALB_HAI_detrended),
  ~ run_stationarity_ds21969(.x,
                             cols=intersect(names(.x), ds21969_detrend_ALB_HAI_monthly$variable),
                             dataset_name = .y)
)

stationarity_SCH <- map2(
  ds21969_SCH_detrended,
  names(ds21969_SCH_detrended),
  ~ run_stationarity_ds21969(.x,
                             cols=intersect(names(.x), ds21969_detrend_SCH_monthly$variable),
                             dataset_name = .y)
)

# ----------------------------
# Combine into one table
# ----------------------------
stationarity_results_ds21969_monthly <- bind_rows(
  bind_rows(stationarity_ALB_HAI),
  bind_rows(stationarity_SCH)
)

# ----------------------------
# Remove duplicate rows
# ----------------------------
stationarity_results_ds21969_monthly <- stationarity_results_ds21969_monthly %>%
  distinct()

# Save CSV
write.csv(stationarity_results_ds21969_monthly,
          "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_monthly_ALL.csv",
          row.names = FALSE)

stationarity_results_ds21969_monthly

################## FILTERING FOR DIFFERENCING ##################
################## Select datasets requiring differencing from table ##################

ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

################# Filter and sort by region #################
# ALB
ALB_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "ALB" | region == "ALB")

unique(ALB_diff$dataset)

weather_ALB_diff <- ALB_diff %>%
  filter(dataset == "weather") 
weather_ALB_diff <- unique(weather_ALB_diff$variable)
weather_ALB_diff

Family_ALB_diff <- unique(ALB_diff$Family)
Family_ALB_diff <- Family_ALB_diff[!is.na(Family_ALB_diff)]

# HAI
HAI_diff <- ds21969_differencing_ALB_HAI_monthly %>% 
  filter(Exploratory == "HAI" | region == "HAI")

unique(HAI_diff$dataset)
weather_HAI_diff <- HAI_diff %>%
  filter(dataset == "weather") 
weather_HAI_diff <- unique(weather_HAI_diff$variable)

Family_HAI_diff <- unique(HAI_diff$Family)
Family_HAI_diff <- Family_HAI_diff[!is.na(Family_HAI_diff)]

# SCH
SCH_diff <- ds21969_differencing_SCH_monthly %>% 
  filter(Exploratory == "SCH" | region == "SCH")

unique(SCH_diff$dataset)

weather_SCH_diff <- SCH_diff %>%
  filter(dataset == "weather") 
weather_SCH_diff <- unique(weather_SCH_diff$variable)

Family_SCH_diff <- unique(SCH_diff$Family)
Family_SCH_diff <- Family_SCH_diff[!is.na(Family_SCH_diff)]

##### Combine Family and weather datasets for each region into a list #####
# ALB
differencing_Family_ALB <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "ALB", Family %in% Family_ALB_diff) 

differencing_weather_ALB <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:3, all_of(weather_ALB_diff))

# Combine into list
differencing_list_ALB <- list(
  insect = differencing_Family_ALB,
  weather = differencing_weather_ALB
)

str(differencing_list_ALB, max.level = 2)

# HAI
differencing_Family_HAI <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Exploratory == "HAI", Family %in% Family_HAI_diff) 

differencing_weather_HAI <- data_for_ds21969_ALB_HAI$weather %>%
  dplyr::select(1:3, all_of(weather_HAI_diff))

# Combine into list
differencing_list_HAI <- list(
  insect = differencing_Family_HAI,
  weather = differencing_weather_HAI
)

str(differencing_list_HAI, max.level = 2)

# SCH
differencing_Family_SCH <- data_for_ds21969_SCH$ds21969 %>%
  filter(Exploratory == "SCH", Family %in% Family_HAI_diff) 

differencing_weather_SCH <- data_for_ds21969_SCH$weather %>%
  dplyr::select(1:3, all_of(weather_SCH_diff))

# Combine into list
differencing_list_SCH <- list(
  insect = differencing_Family_SCH,
  weather = differencing_weather_SCH
)

str(differencing_list_SCH, max.level = 2)


################ DIFFERENCING ####################################################
# Will be applied to "differencing_list_ALB_HAI" and "differencing_list_SCH"

# ==========================================
# 1. Function for differencing numeric columns
# ==========================================
difference_df <- function(df, exclude_cols = c("plotID", "datetime", "year", "month", "region", "month_num")) {
  num_cols <- names(df)[sapply(df, is.numeric) & !(names(df) %in% exclude_cols)]
  
  df_diff <- df
  df_diff[num_cols] <- lapply(df[num_cols], function(x) c(NA, diff(x)))
  return(df_diff)
}

# ==========================================
# 2. Function to run stationarity tests (ADF + KPSS)
# ==========================================
run_diff_tests <- function(df, dataset_label, exploratory = NA) {
  
  # For weather data: no Family column
  family_vals <- if("Family" %in% names(df)) unique(df$Family) else NA
  
  results <- lapply(family_vals, function(fam) {
    sub_df <- if(!is.na(fam)) df %>% filter(Family == fam) else df
    var_names <- names(sub_df)[sapply(sub_df, is.numeric) & !(names(sub_df) %in% c("year","month","month_num"))]
    
    lapply(var_names, function(var) {
      x <- sub_df[[var]]
      x <- x[!is.na(x)]
      if(length(x) < 3) return(NULL)
      
      adf_res <- tryCatch(adf.test(x, k = 0), error = function(e) NULL)
      kpss_res <- tryCatch(kpss.test(x, null = "Level"), error = function(e) NULL)
      
      tibble(
        dataset           = dataset_label,
        variable          = var,
        Exploratory       = exploratory,
        Family            = if(!is.na(fam)) fam else NA,
        statistic_adf     = if(!is.null(adf_res)) adf_res$statistic else NA,
        p_value_adf       = if(!is.null(adf_res)) adf_res$p.value else NA,
        status_adf        = if(!is.null(adf_res)) ifelse(adf_res$p.value < 0.05,"stationary","non-stationary") else NA,
        statistic_kpss    = if(!is.null(kpss_res)) kpss_res$statistic else NA,
        p_value_kpss      = if(!is.null(kpss_res)) kpss_res$p.value else NA,
        status_kpss       = if(!is.null(kpss_res)) ifelse(kpss_res$p.value > 0.05,"stationary","non-stationary") else NA,
        recommended_action= case_when(
          status_adf == "stationary" & status_kpss == "stationary" ~ "No transformation required (stationary)",
          status_adf == "non-stationary" & status_kpss == "stationary" ~ "Detrend time series and check for stationarity again (trend stationary)",
          status_adf == "non-stationary" & status_kpss == "non-stationary" ~ "Detrend and then difference the time series and recheck for stationarity (both trends present)",
          status_adf == "stationary" & status_kpss == "non-stationary" ~ "Apply differencing to time series and check for stationarity again (difference stationary)",
          TRUE ~ "Check series manually"
        )
      )
    }) %>% bind_rows()
  }) %>% bind_rows()
  
  return(results)
}

# ==========================================
# 3. Prepare list of regions
# ==========================================
diff_lists <- list(
  ALB = differencing_list_ALB,
  HAI = differencing_list_HAI,
  SCH = differencing_list_SCH
)

# ==========================================
# 4. Apply differencing and run stationarity tests automatically
# ==========================================
all_results <- lapply(names(diff_lists), function(region) {
  cat("Processing region:", region, "\n")
  
  df_list <- diff_lists[[region]]
  
  # Apply differencing
  df_list$insect_diff  <- difference_df(df_list$insect, exclude_cols = c("TrapID","Exploratory","PlotID","CollectionMonth","year","month","month_num"))
  df_list$weather_diff <- difference_df(df_list$weather)
  
  # Run stationarity tests
  res_insect  <- run_diff_tests(df_list$insect_diff,  paste0(region,"_insect"), region)
  res_weather <- run_diff_tests(df_list$weather_diff, paste0(region,"_weather"), region)
  
  bind_rows(res_insect, res_weather)
}) %>% bind_rows()

# ==========================================
# 5. Review results
# ==========================================
all_results
# Optional: write.csv(all_results, "stationarity_diff_results.csv", row.names = FALSE)

write.csv(all_results, "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_monthly.csv", row.names = FALSE)


################## FILTERING FOR BOTH ##################
# Select only datasets requiring both detrending and differencing from the table

ds21969_both_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

ds21969_both_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

################# Filter and sort by region ##################
ds21969_both_ALB_HAI_monthly
# -> no ALB/HAI region, no need for detrending/differencing
ds21969_both_SCH_monthly
# -> only one time series requires processing; can be selected manually

ds21969_both_SCH <- data_for_ds21969_SCH$SMI_total %>%
  dplyr::select(1, 4:7)

head(ds21969_both_SCH) 

################ BOTH DETRENDING + DIFFERENCING ##################

# 1. Detrending using a linear model
ds21969_both_SCH <- ds21969_both_SCH %>%
  arrange(time)

# Fit linear model over time
lm_model <- lm(SCH ~ as.numeric(time), data = ds21969_both_SCH)

# Residuals represent the detrended time series
ds21969_both_SCH$SCH_detrended <- resid(lm_model)

# 2. Differencing (if necessary)
ds21969_both_SCH$SCH_diff <- c(NA, diff(ds21969_both_SCH$SCH_detrended))

# 3. Augmented Dickey-Fuller test
adf_result <- adf.test(ds21969_both_SCH$SCH_detrended, k = 0)  # k=0 for simple test
adf_stat <- adf_result$statistic
adf_p <- adf_result$p.value
adf_status <- ifelse(adf_p < 0.05, "stationary", "non-stationary")

# 4. KPSS test
kpss_result <- kpss.test(ds21969_both_SCH$SCH_detrended, null = "Level")
kpss_stat <- kpss_result$statistic
kpss_p <- kpss_result$p.value
kpss_status <- ifelse(kpss_p < 0.05, "non-stationary", "stationary")

# 5. Recommended action based on test results
if(adf_status == "non-stationary" & kpss_status == "non-stationary") {
  recommended_action <- "Detrend and then difference the time series and recheck for stationarity (both trends present)"
} else if(adf_status == "stationary" & kpss_status == "non-stationary") {
  recommended_action <- "Apply differencing to time series and check for stationarity again (difference stationary)"
} else if(adf_status == "non-stationary" & kpss_status == "stationary") {
  recommended_action <- "Detrend time series and check for stationarity again (trend stationary)"
} else {
  recommended_action <- "No transformation required (stationary)"
}

# 6. Compile results into a table
result_table <- tibble(
  dataset = "SMI_total",
  variable = "SCH",
  statistic_adf = adf_stat,
  p_value_adf = adf_p,
  status_adf = adf_status,
  Exploratory = NA,
  Family = NA,
  statistic_kpss = kpss_stat,
  p_value_kpss = kpss_p,
  status_kpss = kpss_status,
  recommended_action = recommended_action
)

result_table

# Export results
write.csv(result_table, "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_monthly.csv", row.names = FALSE)


################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# - Only datasets with monthly resolution (without Fertilization & mosaic)
# - Time period and months identical to ds22007
# - Only months April–October (4–10)

# ------------------------------------------------------------------------------
# 1) Determine time range and month range from ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))

years_ds22007 <- range(ds22007$year, na.rm = TRUE)

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2) Remove datasets without monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% c("Fertilization", "mosaic", "ds22007")]

# ------------------------------------------------------------------------------
# 3) Filter function for monthly period (April–October)
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df) # if no monthly data available
  df %>%
    filter(
      month %in% 4:10,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4) Apply filter for ds22007 (only to monthly datasets)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# ------------------------------------------------------------------------------
# 5) Remove ds21969, which is incorrectly included
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- data_for_ds22007_monthly[!names(data_for_ds22007_monthly) %in% c("ds21969")]

# ------------------------------------------------------------------------------
# 6) Add insect dataset back unchanged
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007


# ------------------------------------------------------------------------------
# 7 Special handling for Weather: Aggregate per region + month + year
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds22007_monthly)) {
  
  # Check which columns are numeric (year/month/region are excluded)
  numeric_weather_cols <- data_for_ds22007_monthly$weather %>%
    select(-year, -month, -region) %>%
    select(where(is.numeric)) %>%
    names()
  
  data_for_ds22007_monthly$weather <- data_for_ds22007_monthly$weather %>%
    group_by(region, year, month) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
}

##################### DS22007 - Monthly ##########################################
############################# DETREND DS22007_MONTHLY ############################
################## Select only datasets that require detrending from table ##################
# monthly
ds22007_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

# -------------------------------------------------------------------
# 1) Filter function for detrending (analogous to yearly)
# -------------------------------------------------------------------
filter_ds22007_detrend_monthly <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is included in overview table
  if(!dataset_name %in% detrend_overview$dataset) {
    cat("Dataset", dataset_name, "not found in detrend overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Allowed variables to be detrended
  allowed_columns <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Possible grouping columns
  grouping_columns <- c(
    "year", "month", "Croptype", "Fertilizer",
    "region", "var", "measure", "Exploratory", "Family"
  )
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only columns that exist in the data frame
  columns_to_keep <- intersect(unique(c(existing_group_cols, allowed_columns)), names(df))
  
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# 2) Create filtered list of all ds22007 monthly datasets
# -------------------------------------------------------------------
filtered_ds22007_detrend_monthly <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_detrend_monthly(df, name, ds22007_detrend_monthly)
  }
)

# Remove NULL entries
filtered_ds22007_detrend_monthly <- 
  filtered_ds22007_detrend_monthly[!sapply(filtered_ds22007_detrend_monthly, is.null)]

cat("\nFiltered datasets for detrending (monthly):\n")
print(names(filtered_ds22007_detrend_monthly))

# -------------------------------------------------------------------
# 3) Linear detrending function
# -------------------------------------------------------------------
detrend_ts_monthly <- function(df, value_cols, time_col) {
  df_detrended <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      valid_idx <- !is.na(df[[col]]) & !is.na(df[[time_col]])
      if(sum(valid_idx) > 2) {
        fit <- lm(df[[col]][valid_idx] ~ df[[time_col]][valid_idx])
        df_detrended[[col]] <- NA
        df_detrended[[col]][valid_idx] <- residuals(fit)
      } else {
        df_detrended[[col]] <- NA
      }
    }
  }
  
  return(df_detrended)
}

# -------------------------------------------------------------------
# 4) Apply detrending to filtered datasets
# -------------------------------------------------------------------
filtered_ds22007_detrended_monthly <- imap(
  filtered_ds22007_detrend_monthly,
  function(df, name) {
    
    value_cols <- ds22007_detrend_monthly %>%
      filter(dataset == name) %>%
      pull(variable)
    
    # Numeric time variable: year + month / 12
    df <- df %>%
      mutate(
        month = as.numeric(month),
        year_month_numeric = year + month / 12
      )
    
    detrend_ts_monthly(df, value_cols, time_col = "year_month_numeric")
  }
)

cat("\nDetrended monthly datasets:\n")
print(names(filtered_ds22007_detrended_monthly))

# -------------------------------------------------------------------
# Example output: first rows of the first dataset
# -------------------------------------------------------------------
if(length(filtered_ds22007_detrended_monthly) > 0) {
  cat("\nExample: first rows of the first dataset:\n")
  print(head(filtered_ds22007_detrended_monthly[[1]]))
}

###############################################
### ADF + KPSS tests on detrended monthly data ###
###############################################

# -------------------------------------------------------------------
# Function: run stationarity tests per dataset
# -------------------------------------------------------------------
run_stationarity_tests_ds22007_monthly <- function(detrended_list) {
  
  results <- list()
  
  for(ds_name in names(detrended_list)) {
    
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- detrended_list[[ds_name]]
    
    # Identify numeric value columns (excluding time variables)
    value_cols <- names(df)[
      sapply(df, is.numeric) &
        !names(df) %in% c("year_month_numeric", "year", "month")
    ]
    
    # Identify grouping columns
    group_cols <- names(df)[
      !names(df) %in% c(value_cols, "year", "month", "year_month_numeric")
    ]
    
    # If no grouping columns exist, create dummy group
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        
        res_list <- list()
        
        for(val_col in value_cols) {
          
          ts_data <- .x %>%
            select(year_month_numeric, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 4) next
          
          ts_vec <- ts_data[[val_col]]
          
          # KPSS test
          kpss_p <- tryCatch(
            tseries::kpss.test(ts_vec, null = "Level")$p.value,
            error = function(e) NA
          )
          
          # ADF test
          adf_p <- tryCatch(
            tseries::adf.test(ts_vec, alternative = "stationary")$p.value,
            error = function(e) NA
          )
          
          res_list[[val_col]] <- tibble(
            variable = val_col,
            adf_pvalue = adf_p,
            kpss_pvalue = kpss_p
          )
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

# -------------------------------------------------------------------
# Run tests
# -------------------------------------------------------------------
stationarity_results_ds22007_monthly <- 
  run_stationarity_tests_ds22007_monthly(filtered_ds22007_detrended_monthly)

cat("\nTests completed. Datasets:\n")
print(names(stationarity_results_ds22007_monthly))

# -------------------------------------------------------------------
# Function: derive stationarity status from p-values
# -------------------------------------------------------------------
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  
  adf_status  <- ifelse(!is.na(adf_p)  & adf_p  < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  
  tibble(
    status_adf  = adf_status,
    status_kpss = kpss_status
  )
}

# -------------------------------------------------------------------
# Convert result list into a table
# -------------------------------------------------------------------
stationarity_table_ds22007_detrended_monthly <- purrr::imap_dfr(
  stationarity_results_ds22007_monthly,
  function(df, ds_name) {
    if(nrow(df) == 0) return(NULL)
    
    df %>%
      mutate(dataset = ds_name) %>%
      rowwise() %>%
      mutate(
        status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))
      ) %>%
      unnest(cols = c(status)) %>%
      select(dataset, everything())
  }
)

cat("\nStationarity Table DS22007 Monthly (Detrended):\n")
print(stationarity_table_ds22007_detrended_monthly)

# Optional: export
write.csv(
  stationarity_table_ds22007_detrended_monthly,
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_monthly.csv",
  row.names = FALSE
)


############################# DIFFERENCING DS22007_MONTHLY ############################
# monthly
ds22007_differencing_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# -------------------------------------------------------------------
# Filter function (analogous to yearly)
# -------------------------------------------------------------------
filter_ds22007_diff_monthly <- function(df, dataset_name, diff_overview) {
  
  if(!dataset_name %in% diff_overview$dataset) {
    cat("Dataset", dataset_name, "not found in differencing overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  allowed_columns <- intersect(allowed_columns, names(df))
  
  grouping_columns <- c(
    "date", "Croptype", "Fertilizer", "region",
    "var", "measure", "Exploratory", "Family"
  )
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  cols_to_keep <- intersect(unique(c(existing_group_cols, allowed_columns)), names(df))
  
  df_filtered <- df %>%
    dplyr::select(all_of(cols_to_keep))
  
  for(col in setdiff(existing_group_cols, "date")) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>%
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-dplyr::any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Create filtered dataset list
# -------------------------------------------------------------------
filtered_ds22007_diff_monthly <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_diff_monthly(df, name, ds22007_differencing_monthly)
  }
)

filtered_ds22007_diff_monthly <-
  filtered_ds22007_diff_monthly[!sapply(filtered_ds22007_diff_monthly, is.null)]

# -------------------------------------------------------------------
# Safe KPSS test
# -------------------------------------------------------------------
safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3) 
    return(data.frame(
      kpss_statistic = NA,
      kpss_pvalue   = NA,
      kpss_status   = NA
    ))
  
  tryCatch({
    test <- kpss.test(x, null = "Level")
    data.frame(
      kpss_statistic = as.numeric(test$statistic),
      kpss_pvalue    = as.numeric(test$p.value),
      kpss_status    = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e)
    data.frame(
      kpss_statistic = NA,
      kpss_pvalue   = NA,
      kpss_status   = NA
    )
  )
}

# -------------------------------------------------------------------
# Safe ADF test
# -------------------------------------------------------------------
safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if(length(x) < 3)
    return(data.frame(
      adf_statistic = NA,
      adf_pvalue    = NA,
      adf_status    = NA
    ))
  
  tryCatch({
    test <- adf.test(x, k = 0)
    data.frame(
      adf_statistic = as.numeric(test$statistic),
      adf_pvalue    = as.numeric(test$p.value),
      adf_status    = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e)
    data.frame(
      adf_statistic = NA,
      adf_pvalue    = NA,
      adf_status    = NA
    )
  )
}

# -------------------------------------------------------------------
# Differencing + KPSS + ADF per dataset
# -------------------------------------------------------------------
run_tests_ds22007_monthly <- function(diff_list) {
  results <- list()
  
  for(ds_name in names(diff_list)) {
    df <- diff_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & names(df) != "date"]
    
    grouping_cols <- names(df)[!names(df) %in% value_cols & names(df) != "date"]
    
    if(length(grouping_cols) > 0) {
      df_grouped <- df %>% group_by(across(all_of(grouping_cols)))
      
      res_list <- df_grouped %>%
        group_map(~ {
          group_info <- .y
          df_diff <- .x
          
          # Lag-1 differencing
          for(col in value_cols) {
            df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
          }
          
          # ADF and KPSS tests on all differenced variables
          rows <- lapply(value_cols, function(col) {
            adf_res  <- safe_adf_test(df_diff[[col]])
            kpss_res <- safe_kpss_test(df_diff[[col]])
            cbind(
              dataset = ds_name,
              variable = col,
              adf_res,
              kpss_res,
              as.data.frame(group_info)
            )
          })
          
          do.call(rbind, rows)
        })
      
      results[[ds_name]] <- do.call(rbind, res_list)
      
    } else {
      df_diff <- df
      for(col in value_cols) {
        df_diff[[col]] <- c(NA, diff(df_diff[[col]]))
      }
      
      rows <- lapply(value_cols, function(col) {
        adf_res  <- safe_adf_test(df_diff[[col]])
        kpss_res <- safe_kpss_test(df_diff[[col]])
        cbind(dataset = ds_name, variable = col, adf_res, kpss_res)
      })
      
      results[[ds_name]] <- do.call(rbind, rows)
    }
  }
  
  bind_rows(results)
}

# -------------------------------------------------------------------
# Run tests
# -------------------------------------------------------------------
res_tests_diff_ds22007_monthly <- 
  run_tests_ds22007_monthly(filtered_ds22007_diff_monthly)

# -------------------------------------------------------------------
# Summary table: ADF + KPSS after differencing (monthly)
# -------------------------------------------------------------------
if(!exists("res_tests_diff_ds22007_monthly") || nrow(res_tests_diff_ds22007_monthly) == 0){
  cat("No results available.\n")
} else {
  
  summary_ds22007_monthly <- res_tests_diff_ds22007_monthly %>%
    dplyr::select(
      dataset, variable,
      adf_statistic, adf_pvalue, adf_status,
      kpss_statistic, kpss_pvalue, kpss_status,
      dplyr::everything()
    ) %>%
    arrange(dataset, variable)
  
  cat("\nSummary: ADF + KPSS after differencing (DS22007 Monthly):\n")
  print(summary_ds22007_monthly)
  
  # CSV export
  write.csv(
    summary_ds22007_monthly,
    "./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_monthly.csv",
    row.names = FALSE
  )
}


######################### DS22007 – MONTHLY – DETREND + DIFFERENCE #########################
# monthly
ds22007_diff_and_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

# =====================================================================================
# 1) Function to filter datasets (analogous to ds22007_yearly)
# =====================================================================================
filter_ds22007_monthly_diff_detrend <- function(df, dataset_name, overview_table) {
  
  # Check whether dataset is listed in the overview table
  if(!dataset_name %in% unique(overview_table$dataset)) {
    cat("Dataset", dataset_name, "not found in overview\n")
    return(NULL)
  }
  
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c(
    "year", "month", "Croptype", "Fertilizer", "region",
    "var", "measure", "Exploratory", "Family"
  )
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns (except year and month)
  for(col in setdiff(existing_group_cols, c("year","month"))) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite products
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-dplyr::any_of("region"))
  }
  
  cat("Dataset", dataset_name, "filtered.\n")
  return(df_filtered)
}

# =====================================================================================
# 2) Apply filtering to all ds22007 monthly datasets
# =====================================================================================
filtered_ds22007_monthly_diff_detrend <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name){
    filter_ds22007_monthly_diff_detrend(df, name, ds22007_diff_and_detrend_monthly)
  }
)

filtered_ds22007_monthly_diff_detrend <- filtered_ds22007_monthly_diff_detrend[
  !sapply(filtered_ds22007_monthly_diff_detrend, is.null)
]

cat("\nFiltered datasets for DS22007 Monthly:\n")
print(names(filtered_ds22007_monthly_diff_detrend))

# =====================================================================================
# 3) Function for ADF and KPSS tests on detrended and differenced data
# =====================================================================================
run_stationarity_tests_ds22007_monthly <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- diff_detrend_list[[ds_name]]
    
    value_cols <- names(df)[sapply(df, is.numeric) & !names(df) %in% c("year","month")]
    
    group_cols <- names(df)[!names(df) %in% value_cols & !names(df) %in% c("year","month")]
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    df <- df %>% mutate(time_numeric = year + month/12)
    
    res <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        
        res_list <- list()
        
        for(val_col in value_cols) {
          ts_data <- .x %>%
            dplyr::select(time_numeric, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 3) next
          
          # 1) Detrending
          detrended <- tryCatch(
            resid(lm(ts_data[[val_col]] ~ ts_data$time_numeric)),
            error = function(e) NULL
          )
          if(is.null(detrended) || length(detrended) < 2) next
          
          # 2) Differencing
          differenced <- diff(detrended)
          
          # 3) Stationarity tests
          kpss_p <- tryCatch(
            tseries::kpss.test(differenced, null = "Level")$p.value,
            error = function(e) NA
          )
          adf_p <- tryCatch(
            tseries::adf.test(differenced, alternative = "stationary")$p.value,
            error = function(e) NA
          )
          
          res_list[[val_col]] <- tibble(
            variable = val_col,
            adf_pvalue = adf_p,
            kpss_pvalue = kpss_p
          )
        }
        
        if(length(res_list) == 0) return(tibble())
        bind_rows(res_list)
      }) %>%
      ungroup()
    
    results[[ds_name]] <- res
  }
  
  return(results)
}

# =====================================================================================
# 4) Run tests
# =====================================================================================
stationarity_results_ds22007_monthly <- run_stationarity_tests_ds22007_monthly(
  filtered_ds22007_monthly_diff_detrend
)

cat("\nStationarity test results for monthly datasets:\n")
print(names(stationarity_results_ds22007_monthly))

# =====================================================================================
# 5) Function to determine stationarity status
# =====================================================================================
get_stationarity_status <- function(adf_p, kpss_p, alpha = 0.05) {
  adf_status  <- ifelse(!is.na(adf_p) & adf_p < alpha, "stationary", "non-stationary")
  kpss_status <- ifelse(!is.na(kpss_p) & kpss_p < alpha, "non-stationary", "stationary")
  tibble(status_adf = adf_status, status_kpss = kpss_status)
}

# =====================================================================================
# 6) Convert result list into a table
# =====================================================================================
stationarity_table_ds22007_monthly <- purrr::imap_dfr(
  stationarity_results_ds22007_monthly,
  function(df, ds_name) {
    if(nrow(df) == 0) return(NULL)
    df %>%
      mutate(dataset = ds_name) %>%
      rowwise() %>%
      mutate(status = list(get_stationarity_status(adf_pvalue, kpss_pvalue))) %>%
      unnest(cols = c(status)) %>%
      dplyr::select(dataset, everything())
  }
)

# =====================================================================================
# 7) Output and export
# =====================================================================================
cat("\nStationarity table DS22007 Monthly:\n")
print(stationarity_table_ds22007_monthly)

write.csv(
  stationarity_table_ds22007_monthly,
  "./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_monthly.csv",
  row.names = FALSE
)


