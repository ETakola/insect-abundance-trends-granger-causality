######################## Stationarity Testing #######################
# Objective: Check time series for stationarity using ADF and KPSS tests.
# Workflow:
# 1. Load datasets and standardize relevant columns (year, month, day).
# 2. Perform stationarity tests (ADF/KPSS) on monthly and yearly aggregated datasets.

################### Load Required Packages ###########################
# Load necessary packages for data manipulation, time series analysis, and visualization
library(tidyverse)   # Collection of packages for data manipulation and visualization
library(dplyr)       # Data manipulation (filter, select, group_by, summarize, etc.)
library(lubridate)   # Date and time operations
library(readr)       # CSV reading
library(stringr)     # String operations
library(purrr)       # Functional programming tools
library(tibble)      # Ddata frame handling
library(tidyr)       # Data tidying and reshaping
library(tseries)     # Time series analysis, including ADF test

#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Fertilization data
Fertilization <- read.csv("./data/fertilizer_cropland_means.csv", sep=';', header=TRUE) %>% 
  rename(year = Year)

# Mosaic data (area-weighted means)
mosaic <- read_csv("./data/mosaic_zones_means.csv")

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Crop yield and area data
ALB_crop <- read.csv("./data/crops/merged_ALB_filled.csv")
HAI_crop <- read.csv("./data/crops/merged_HAI_filled.csv")
SCH_crop <- read.csv("./data/crops/merged_SCH_filled.csv")

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable

############################## Create data lists for easier handling ##############
# Consolidate all datasets into a list for streamlined processing in later steps
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, 
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH, 
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  Fertilization = Fertilization, 
  mosaic = mosaic, 
  weather = weather, 
  ALB_crop = ALB_crop, 
  HAI_crop = HAI_crop,
  SCH_crop = SCH_crop, 
  ds21969 = ds21969, 
  ds22007 = ds22007
)

# Configuration for automated aggregation and stationarity testing
configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  Fertilization = list(type = "grouped", group_cols = c("Croptype", "Fertilizer"), value_cols = c("ALB", "HAI", "SCH")),
  mosaic = list(type = "grouped", group_cols = c("region"), value_cols = c("dendrites", "relation", "normal", "cellsize")),
  weather = list(type ="grouped", group_cols = c("region"), value_cols = names(weather)[3:39]),
  ALB_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  HAI_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  SCH_crop = list(type ="grouped", group_cols = c("var","measure"), value_cols = c("weighted_value_sum")),
  ds21969 = list(type ="grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type ="grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)


########### Check for Stationarity - ADF & KPSS Tests ##################
########### Augmented Dickey-Fuller Test (ADF) ########################
# Null hypothesis (H0): The time series is non-stationary (contains a unit root).
# Alternative hypothesis (H1): The time series is stationary (no unit root).
# Interpretation: p-value <= 0.05 indicates rejection of H0 (series is stationary).

######################################################################
# Function: Aggregate datasets on a yearly basis
aggregate_yearly <- function(df, dataset_name) {
  
  # ---------------------------
  # 1. Filter for seasonal datasets (NDVI, NDWI, NirV)
  # Only keep months April (4) to October (10)
  # ---------------------------
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NirV_ALB", "NirV_HAI", "NirV_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
  # ---------------------------
  # 2. Special handling for crop datasets
  # ---------------------------
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE),
                  .groups = "drop")
    )
  }
  
  # ---------------------------
  # 3. Define grouping and aggregation columns
  # ---------------------------
  group_col <- NULL
  sum_cols <- c()
  
  # Insect datasets: sum adults, grouped by Exploratory & Family
  if (dataset_name %in% c("ds21969","ds22007")) {
    group_col <- c("Exploratory", "Family")
    sum_cols <- "NumberAdults"
  }
  
  # Fertilization and mosaic datasets
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  # Columns to average (exclude year, grouping, sum, month/day)
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # ---------------------------
  # 4. Aggregate other datasets
  # ---------------------------
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  } else {
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################
# 2. Function: Safely perform ADF test on a vector
safe_adf_test <- function(x) {
  # Remove NA values and coerce to numeric
  x <- suppressWarnings(as.numeric(na.omit(x)))
  
  # If time series is too short or all NA, return NA
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  
  # Attempt ADF test and handle errors gracefully
  res <- tryCatch({
    test <- adf.test(x, k = 0)  # k = 0: no lag
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "stationary", "non-stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  
  return(res)
}

######################################################################
# 3. Function: Run ADF tests for all datasets in a list
run_adf_tests <- function(data_list, configs) {
  results <- list()
  
  for (ds_name in names(data_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- data_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    # Skip datasets without configuration
    if (is.null(cfg)) {
      cat("No config found for", ds_name, "- skipped.\n")
      next
    }
    
    # --- Grouped datasets ---
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        # Apply ADF test within each group
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_adf_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        # No grouping columns present: run ADF on entire column
        for (v in vcols) {
          res <- safe_adf_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
    
    # --- Column-based datasets (no grouping) ---
    if (cfg$type == "columns") {
      cols <- cfg$cols[cfg$cols %in% names(df)]
      for (col in cols) {
        res <- safe_adf_test(df[[col]])
        results[[length(results)+1]] <- cbind(
          dataset = ds_name,
          variable = col,
          res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  # Combine all results into a single data frame
  final_res <- bind_rows(results)
  return(final_res)
}

######################################################################
# Special aggregation for the weather dataset (per plot → per region)
aggregate_weather <- function(weather_df) {
  
  sum_cols <- c("precipitation_radolan", "precipitation_radolan_rain_days")
  mean_cols <- c(
    "rH_200", "rH_200_max", "rH_200_min",
    "SM_10", "SM_20",
    "Ta_10", "Ta_10_max", "Ta_10_min",
    "Ta_200", "Ta_200_max", "Ta_200_min",
    "Ts_05", "Ts_05_max", "Ts_05_min",
    "Ts_10", "Ts_10_max", "Ts_10_min",
    "Ts_20", "Ts_20_max", "Ts_20_min",
    "Ts_50", "Ts_50_max", "Ts_50_min"
  )
  
  # Step 1: Aggregate per plot
  weather_annual <- weather_df %>%
    group_by(plotID, year) %>%
    summarise(
      region = first(region),
      across(all_of(sum_cols), sum, na.rm = TRUE),
      across(all_of(mean_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
  # Step 2: Aggregate per region
  weather_region <- weather_annual %>%
    group_by(region, year) %>%
    summarise(
      across(all_of(sum_cols), mean, na.rm = TRUE),  # Average the sum columns
      across(all_of(mean_cols), mean, na.rm = TRUE), # Average the mean columns
      .groups = "drop"
    )
  
  return(weather_region)
}

######################################################################
# 4. Prepare yearly aggregated data for insect datasets ds21969 and ds22007

# Determine the year ranges of each insect dataset
years_ds21969 <- range(ds21969$year, na.rm = TRUE)
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

# Aggregate all datasets on a yearly basis
data_yearly <- lapply(names(data_list), function(name) {
  if (name == "weather") {
    # Use the special weather aggregation
    aggregate_weather(data_list[[name]])
  } else {
    # Use the aggregation function for other datasets
    aggregate_yearly(data_list[[name]], name)
  }
})
names(data_yearly) <- names(data_list)

# Filter datasets to the corresponding year ranges for each insect dataset
data_for_ds21969 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds21969[1], year <= years_ds21969[2]))
data_for_ds22007 <- lapply(data_yearly, function(df) df %>% filter(year >= years_ds22007[1], year <= years_ds22007[2]))

# Remove the other insect dataset from each list to avoid duplication
data_for_ds21969 <- data_for_ds21969[!names(data_for_ds21969) %in% c("ds22007")]
data_for_ds22007 <- data_for_ds22007[!names(data_for_ds22007) %in% c("ds21969")]

######################################################################
# 5. Execute ADF tests for both datasets
res_adf_ds21969 <- run_adf_tests(data_for_ds21969, configs)
res_adf_ds22007 <- run_adf_tests(data_for_ds22007, configs)

######################################################################
# 6. Preview and export results
# Display the first rows of the ADF test results
head(res_adf_ds21969)
head(res_adf_ds22007)

# Save results as CSV files (optional)
#write.csv(res_adf_ds21969, "./tables/stationarity_test/adf_test_ds21969.csv", row.names = FALSE)
#write.csv(res_adf_ds22007, "./tables/stationarity_test/adf_test_ds22007.csv", row.names = FALSE)


########### Kwiatkowski-Phillips-Schmidt-Shin Test (KPSS) #############
# Null hypothesis (H0): The time series is stationary (no unit root).
# Alternative hypothesis (H1): The time series is non-stationary (contains a unit root).
# Interpretation: p-value <= 0.05 indicates rejection of H0 (series is non-stationary).
######################################################################

######################################################################
# 1. Function: Aggregate datasets on a yearly basis
aggregate_yearly <- function(df, dataset_name) {
  
  # Filter for NDVI, NDMI, NIRv: only months 04-10 
  if (dataset_name %in% c("NDVI_ALB", "NDVI_HAI", "NDVI_SCH",
                          "NDMI_ALB", "NDMI_HAI", "NDMI_SCH",
                          "NIRv_ALB", "NIRv_HAI", "NIRv_SCH")) {
    df <- df %>% filter(month >= 4 & month <= 10)
  }
  
    # Special handling for crop datasets (ALB_crop, HAI_crop, SCH_crop)
  if (dataset_name %in% c("ALB_crop", "HAI_crop", "SCH_crop")) {
    # Group by year, crop variable, and measure; calculate mean of weighted values
    return(
      df %>%
        group_by(year, var, measure) %>%
        summarise(weighted_value_sum = mean(weighted_value_sum, na.rm = TRUE), .groups = "drop")
    )
  }
  
  # Initialize grouping and sum columns
  group_col <- NULL
  sum_cols <- c()
  
  # Grouping columns and sum columns depend on dataset type
  if (dataset_name %in% c("ds21969","ds22007")) {
    group_col <- c("Exploratory", "Family")  # spatial and taxonomic grouping
    sum_cols <- "NumberAdults"               # sum column for counts
  }
  if (dataset_name == "weather") {
    group_col <- "region"
    sum_cols <- names(df)[3:39]             # meteorological variable columns
  }
  if (dataset_name == "Fertilization") group_col <- c("Croptype", "Fertilizer")
  if (dataset_name == "mosaic") group_col <- "region"
  
  # Columns for mean aggregation (exclude year, grouping, sum, month/day)
  mean_cols <- setdiff(names(df), c("year", group_col, sum_cols, "month","day"))
  
  # Perform aggregation
  if (!is.null(group_col)) {
    df_yearly <- df %>%
      group_by(across(c("year", group_col))) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),  # calculate mean
        across(all_of(sum_cols), sum, na.rm = TRUE),    # calculate sum for count columns
        .groups = "drop"
      )
  } else {
    # If no grouping columns, aggregate only by year
    df_yearly <- df %>%
      group_by(year) %>%
      summarise(
        across(all_of(mean_cols), mean, na.rm = TRUE),
        across(all_of(sum_cols), sum, na.rm = TRUE),
        .groups = "drop"
      )
  }
  
  return(df_yearly)
}

######################################################################
# 2. Function: Safely perform KPSS test on a numeric vector
safe_kpss_test <- function(x) {
  # Remove missing values and coerce to numeric
  x <- suppressWarnings(as.numeric(na.omit(x)))
  
  # Return NA if series is too short or all values are missing
  if (length(x) < 3 || all(is.na(x))) {
    return(data.frame(statistic = NA, p_value = NA, status = NA))
  }
  
  # Execute KPSS test and handle possible errors gracefully
  res <- tryCatch({
    test <- kpss.test(x, null = "Level")  # Test for level stationarity
    data.frame(
      statistic = as.numeric(test$statistic),
      p_value = as.numeric(test$p.value),
      status = ifelse(test$p.value < 0.05, "non-stationary", "stationary")
    )
  }, error = function(e) data.frame(statistic = NA, p_value = NA, status = NA))
  
  return(res)
}

######################################################################
# 3. Function: Run KPSS tests for a list of datasets
run_kpss_tests <- function(data_list, configs) {
  results <- list()
  
  for (ds_name in names(data_list)) {
    cat("Checking dataset:", ds_name, "\n")
    
    df <- data_list[[ds_name]]
    cfg <- configs[[ds_name]]
    
    # Skip datasets without configuration
    if (is.null(cfg)) {
      cat("No config found for", ds_name, "- skipped.\n")
      next
    }
    
    # --- Grouped datasets ---
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols[cfg$group_cols %in% names(df)]
      vcols <- cfg$value_cols[cfg$value_cols %in% names(df)]
      
      if (length(gcols) == 0) gcols <- NULL
      
      if (!is.null(gcols)) {
        # Apply KPSS test within each group
        df_grouped <- df %>% group_by(across(all_of(gcols)))
        res_list <- df_grouped %>%
          group_map(~ {
            group_info <- as.data.frame(.y)
            group_info[] <- lapply(group_info, as.character)
            res_rows <- list()
            for (v in vcols) {
              res <- safe_kpss_test(.x[[v]])
              res_rows[[length(res_rows)+1]] <- cbind(
                dataset = ds_name,
                variable = v,
                res,
                group_info,
                stringsAsFactors = FALSE
              )
            }
            do.call(rbind, res_rows)
          })
        results[[length(results)+1]] <- do.call(rbind, res_list)
      } else {
        # No grouping columns present: run KPSS on entire column
        for (v in vcols) {
          res <- safe_kpss_test(df[[v]])
          results[[length(results)+1]] <- cbind(
            dataset = ds_name,
            variable = v,
            res,
            stringsAsFactors = FALSE
          )
        }
      }
    }
    
    # --- Columns-only datasets ---
    if (cfg$type == "columns") {
      cols <- cfg$cols[cfg$cols %in% names(df)]
      for (col in cols) {
        res <- safe_kpss_test(df[[col]])
        results[[length(results)+1]] <- cbind(
          dataset = ds_name,
          variable = col,
          res,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  # Combine all results into a single data frame
  final_res <- bind_rows(results)
  return(final_res)
}


######################################################################
# 5. Execute KPSS tests for both datasets
res_kpss_ds21969 <- run_kpss_tests(data_for_ds21969, configs)
res_kpss_ds22007 <- run_kpss_tests(data_for_ds22007, configs)

######################################################################
# 6. Preview and export results
# Display first rows of the KPSS test results
head(res_kpss_ds21969)
head(res_kpss_ds22007)

# Save KPSS results as CSV (optional)
#write.csv(res_kpss_ds21969, "./tables/stationarity_test/kpss_test_ds21969.csv", row.names = FALSE)
#write.csv(res_kpss_ds22007, "./tables/stationarity_test/kpss_test_ds22007.csv", row.names = FALSE)


######################################################################
# Combine ADF and KPSS results and provide recommended actions
######################################################################

# Function to merge ADF and KPSS test results and suggest transformations
combine_stationarity_results <- function(res_adf, res_kpss, file_out) {
  
  # Identify common columns to use as join keys (e.g., dataset, variable, group info)
  join_keys <- intersect(names(res_adf), names(res_kpss))
  # Exclude the test result columns to avoid overwriting
  join_keys <- join_keys[!join_keys %in% c("statistic", "p_value", "status")]
  
  # Merge ADF and KPSS results based on the join keys
  combined <- full_join(
    res_adf %>% rename(
      statistic_adf = statistic,
      p_value_adf = p_value,
      status_adf = status
    ),
    res_kpss %>% rename(
      statistic_kpss = statistic,
      p_value_kpss = p_value,
      status_kpss = status
    ),
    by = join_keys
  )
  
  # Add a new column with recommended transformation based on test results
  combined <- combined %>%
    mutate(
      recommended_action = case_when(
        # Series is difference stationary (ADF stationary, KPSS non-stationary)
        status_adf == "stationary" & status_kpss == "non-stationary" ~
          "Apply differencing to time series and check for stationarity again (difference stationary)",
        # Series is trend stationary (ADF non-stationary, KPSS stationary)
        status_adf == "non-stationary" & status_kpss == "stationary" ~
          "Detrend time series and check for stationarity again (trend stationary)",
        # Series is stationary according to both tests
        status_adf == "stationary" & status_kpss == "stationary" ~
          "No transformation required (stationary)",
        # Series shows both trend and unit root (non-stationary according to both)
        status_adf == "non-stationary" & status_kpss == "non-stationary" ~
          "Detrend and then difference the time series and recheck for stationarity (both trends present)",
        # Catch-all for ambiguous cases
       TRUE ~ "Indeterminate, check data or increase time series length"
      )
    )
  
  # Export the combined table as CSV for documentation and further analysis
  write.csv(combined, file_out, row.names = FALSE)
  
  message("Combined stationarity file saved to: ", file_out)
  return(combined)
}

############################################################
# Apply the function to insect datasets ds21969 and ds22007
############################################################

combined_ds21969 <- combine_stationarity_results(
  res_adf_ds21969,
  res_kpss_ds21969,
  "./tables/stationarity_test/combined_stationarity_ds21969_yearly_Kopie.csv"
)

combined_ds22007 <- combine_stationarity_results(
  res_adf_ds22007,
  res_kpss_ds22007,
  "./tables/stationarity_test/combined_stationarity_ds22007_yearly.csv"
)

############################################################
# Preview the combined stationarity outputs
############################################################
head(combined_ds21969)
head(combined_ds22007)


################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# This script performs monthly aggregation for datasets with monthly resolution.
# Notes:
# - Only datasets with monthly resolution are included (exclude Fertilization & mosaic).
# - Time period and months are matched to ds22007.
# - Only months April to October (4–10) are considered.

# ------------------------------------------------------------------------------
# 1 Determine the months and year ranges from ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))          # unique months present in ds22007
years_ds22007 <- range(ds22007$year, na.rm = TRUE)    # min and max years in ds22007

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2 Remove datasets that do not have monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ds22007", "ALB_crop", "HAI_crop", "SCH_crop")]

# ------------------------------------------------------------------------------
# 3 Define a filter function to select months April–October within year range
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df)
  
  df %>%
    filter(
      month %in% 4:10,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4 Apply the monthly filter to datasets for ds22007
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# ------------------------------------------------------------------------------
# 5 Remove ds21969 if accidentally included
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- data_for_ds22007_monthly[!names(data_for_ds22007_monthly) %in% c("ds21969")]

# ------------------------------------------------------------------------------
# 6 Re-add the ds22007 insect dataset (monthly resolution)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007

# Aggregate ds22007 by exploratory site, month, year, and family
data_for_ds22007_monthly$ds22007 <- data_for_ds22007_monthly$ds22007 %>%
  group_by(Exploratory, month, year, Family) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")


# ------------------------------------------------------------------------------
# 7 Special handling for Weather: Aggregate per region + month + year
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds22007_monthly)) {
  
  # Check which columns are numeric (year/month/region are excluded)
  numeric_weather_cols <- data_for_ds22007_monthly$weather %>%
    select(-year, -month, -region) %>%
    select(where(is.numeric)) %>%
    names()
  
  data_for_ds22007_monthly$weather <- data_for_ds22007_monthly$weather %>%
    group_by(region, year, month) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
}


############################ Safe Test Functions ################################
# Functions to perform ADF and KPSS tests safely on numeric vectors

safe_adf_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3) {
    return(data.frame(statistic_adf = NA, p_value_adf = NA, status_adf = NA))
  }
  res <- tryCatch(adf.test(x, k = 0), error = function(e) NULL)
  if (is.null(res)) {
    return(data.frame(statistic_adf = NA, p_value_adf = NA, status_adf = NA))
  }
  data.frame(
    statistic_adf = as.numeric(res$statistic),
    p_value_adf = as.numeric(res$p.value),
    status_adf = ifelse(res$p.value < 0.05, "stationary", "non-stationary")
  )
}

safe_kpss_test <- function(x) {
  x <- suppressWarnings(as.numeric(na.omit(x)))
  if (length(x) < 3) {
    return(data.frame(statistic_kpss = NA, p_value_kpss = NA, status_kpss = NA))
  }
  res <- tryCatch(kpss.test(x, null = "Level"), error = function(e) NULL)
  if (is.null(res)) {
    return(data.frame(statistic_kpss = NA, p_value_kpss = NA, status_kpss = NA))
  }
  data.frame(
    statistic_kpss = as.numeric(res$statistic),
    p_value_kpss = as.numeric(res$p.value),
    status_kpss = ifelse(res$p.value < 0.05, "non-stationary", "stationary")
  )
}

########################### Monthly Stationarity Runner ########################
# Function to apply ADF and KPSS tests to all monthly datasets

run_stationarity_monthly <- function(data_list, configs) {
  
  results <- list()
  
  for (ds_name in names(data_list)) {
    
    df <- data_list[[ds_name]]
    cfg <- configs[[ds_name]]
    if (is.null(cfg)) next  # skip datasets without configuration
    
    # ---------------- COLUMNS ----------------
    if (cfg$type == "columns") {
      for (v in cfg$cols) {
        if (!v %in% names(df)) next
        
        adf <- safe_adf_test(df[[v]])
        kpss <- safe_kpss_test(df[[v]])
        
        results[[length(results)+1]] <- tibble(
          dataset = ds_name,
          variable = v,
          statistic_adf = adf$statistic_adf,
          p_value_adf = adf$p_value_adf,
          status_adf = adf$status_adf,
          region = NA_character_,
          Exploratory = NA_character_,
          Family = NA_character_,
          statistic_kpss = kpss$statistic_kpss,
          p_value_kpss = kpss$p_value_kpss,
          status_kpss = kpss$status_kpss
        )
      }
    }
    
    # ---------------- GROUPED ----------------
    if (cfg$type == "grouped") {
      gcols <- cfg$group_cols
      vcols <- cfg$value_cols
      
      df %>%
        group_by(across(all_of(gcols))) %>%
        group_map(~ {
          
          out <- list()
          
          for (v in vcols) {
            if (!v %in% names(.x)) next
            
            adf <- safe_adf_test(.x[[v]])
            kpss <- safe_kpss_test(.x[[v]])
            
            row <- tibble(
              dataset = ds_name,
              variable = v,
              statistic_adf = adf$statistic_adf,
              p_value_adf = adf$p_value_adf,
              status_adf = adf$status_adf,
              region = if ("region" %in% names(.y)) as.character(.y$region) else NA_character_,
              Exploratory = if ("Exploratory" %in% names(.y)) as.character(.y$Exploratory) else NA_character_,
              Family = if ("Family" %in% names(.y)) as.character(.y$Family) else NA_character_,
              statistic_kpss = kpss$statistic_kpss,
              p_value_kpss = kpss$p_value_kpss,
              status_kpss = kpss$status_kpss
            )
            
            out[[length(out)+1]] <- row
          }
          
          bind_rows(out)
        }) %>% bind_rows() -> tmp
      
      results[[length(results)+1]] <- tmp
    }
  }
  
  bind_rows(results)
}

############################ Run Monthly Stationarity Tests ####################
stationarity_ds22007_monthly <- run_stationarity_monthly(
  data_for_ds22007_monthly,
  configs
)

# Add recommended transformation based on ADF and KPSS results
stationarity_ds22007_monthly <- stationarity_ds22007_monthly %>%
  mutate(
    recommended_action = case_when(
      status_adf == "stationary" & status_kpss == "stationary" ~
        "No transformation required (stationary)",
      status_adf == "stationary" & status_kpss == "non-stationary" ~
        "Apply differencing to time series and check for stationarity again (difference stationary)",
      status_adf == "non-stationary" & status_kpss == "stationary" ~
        "Detrend time series and check for stationarity again (trend stationary)",
      status_adf == "non-stationary" & status_kpss == "non-stationary" ~
        "Detrend and then difference the time series and recheck for stationarity (both trends present)",
      TRUE ~ "Indeterminate, check data or increase time series length"
    )
  )

##################### Export Monthly Stationarity Results #######################
write_csv(
  stationarity_ds22007_monthly,
  "./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv"
)

############################################################
# Preview the combined stationarity outputs
############################################################
head(stationarity_ds22007_monthly)


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1 Determine months and year range for ds21969
# ------------------------------------------------------------------------------
# Convert month column to numeric for filtering
ds21969 <- ds21969 %>% mutate(month_num = as.numeric(month))

# Determine the overall year range in ds21969
years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# Determine months for ALB & HAI exploratory sites
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))

cat("Months ALB & HAI:", paste(months_ALB_HAI, collapse = ", "), "\n")
cat("Year range ds21969:", paste(years_ds21969, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# Select all datasets with monthly resolution,
# exclude datasets that are not monthly or irrelevant for this analysis
# (Fertilization, mosaic, crop datasets, ds22007)
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ALB_crop", "HAI_crop", "SCH_crop", "ds22007")]

# ------------------------------------------------------------------------------
# Define function to filter datasets by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  # Return unaltered dataset if "year" or "month" columns are missing
  if (!all(c("year","month") %in% names(df))) return(df)
  
  df %>%
    mutate(month_num = as.numeric(month)) %>%   # Convert month to numeric
    filter(
      !is.na(month_num),                        # Remove missing months
      year >= year_range[1],                     # Apply lower year bound
      year <= year_range[2],                     # Apply upper year bound
      month_num %in% month_range                 # Apply month range filter
    )
}

# ------------------------------------------------------------------------------
# Apply filter for ALB & HAI exploratory sites
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove any other insect datasets (only ds21969 is added separately)
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[!names(data_for_ds21969_ALB_HAI) %in% c("ds22007")]

# Add ds21969 ALB & HAI insect dataset
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>% filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# Special handling for Weather (monthly, ds21969)
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds21969_ALB_HAI)) {
  
  # Identify numeric weather columns (exclude grouping/time variables)
  numeric_weather_cols <- data_for_ds21969_ALB_HAI$weather %>%
    select(where(is.numeric)) %>%
    select(-year, -month, -month_num) %>%
    names()
  
  # Aggregate weather to region × year × month
  data_for_ds21969_ALB_HAI$weather <- data_for_ds21969_ALB_HAI$weather %>%
    group_by(region, year, month_num) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    rename(month = month_num)
  
}

################################################################################
###################### STATIONARITY TESTS FOR ALB & HAI ########################
################################################################################

# ------------------------------------------------------------------------------
# Define function to run monthly stationarity tests for ds21969 ALB & HAI
# This function applies both ADF and KPSS tests to all relevant datasets
# and returns a combined table with recommended actions based on test results.
# ------------------------------------------------------------------------------
run_stationarity_monthly_ds21969_ALB_HAI <- function(data_list) {
  
  # -----------------------------
  # Helper function for a single vector
  # -----------------------------
  test_stationarity <- function(vec) {
    vec <- na.omit(vec)
    if(length(vec) < 3) {
      return(list(
        statistic_adf = NA, p_value_adf = NA, status_adf = NA,
        statistic_kpss = NA, p_value_kpss = NA, status_kpss = NA,
        recommended_action = "Indeterminate, check data or increase time series length"
      ))
    }
    
    # Run ADF
    adf <- try(adf.test(vec), silent = TRUE)
    if(inherits(adf, "try-error")) {
      adf_stat <- NA; adf_p <- NA; adf_status <- NA
    } else {
      adf_stat <- as.numeric(adf$statistic)
      adf_p <- adf$p.value
      adf_status <- ifelse(adf_p < 0.05, "stationary", "non-stationary")
    }
    
    # Run KPSS
    kpss <- try(kpss.test(vec, null = "Level"), silent = TRUE)
    if(inherits(kpss, "try-error")) {
      kpss_stat <- NA; kpss_p <- NA; kpss_status <- NA
    } else {
      kpss_stat <- as.numeric(kpss$statistic)
      kpss_p <- kpss$p.value
      kpss_status <- ifelse(kpss_p < 0.05, "non-stationary", "stationary")
    }
    
    # Recommended action
    recommended <- case_when(
      adf_status == "stationary" & kpss_status == "non-stationary" ~
        "Apply differencing to time series and check for stationarity again (difference stationary)",
      adf_status == "non-stationary" & kpss_status == "stationary" ~
        "Detrend time series and check for stationarity again (trend stationary)",
      adf_status == "stationary" & kpss_status == "stationary" ~
        "No transformation required (stationary)",
      adf_status == "non-stationary" & kpss_status == "non-stationary" ~
        "Detrend and then difference the time series and recheck for stationarity (both trends present)",
      TRUE ~ "Indeterminate, check data or increase time series length"
    )
    
    return(list(
      statistic_adf = adf_stat, p_value_adf = adf_p, status_adf = adf_status,
      statistic_kpss = kpss_stat, p_value_kpss = kpss_p, status_kpss = kpss_status,
      recommended_action = recommended
    ))
  }
  
  # -----------------------------
  # Run tests for each dataset
  # -----------------------------
  results <- list()
  
  for(ds_name in names(data_list)) {
    df <- data_list[[ds_name]]
    
    # -----------------------------
    # ds21969 insects
    # -----------------------------
    if(ds_name == "ds21969") {
      insects <- df %>%
        group_by(Exploratory, month, year, Family) %>%
        summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
      
      test_res <- insects %>%
        group_by(Exploratory, Family) %>%
        summarise(tmp = list(test_stationarity(NumberAdults)), .groups = "drop") %>%
        unnest_wider(tmp) %>%
        mutate(dataset = ds_name, variable = "NumberAdults", region = NA)
      
      results[[ds_name]] <- test_res
      
      # -----------------------------
      # Weather data
      # -----------------------------
    } else if(ds_name == "weather") {
      df <- df %>% filter(region %in% c("ALB","HAI"))
      numeric_cols <- names(df)[sapply(df, is.numeric)]
      numeric_cols <- setdiff(numeric_cols, c("year","month")) # exclude non-measurement columns
      
      for(col in numeric_cols){
        test_res <- df %>%
          group_by(region) %>%
          summarise(tmp = list(test_stationarity(.data[[col]])), .groups = "drop") %>%
          unnest_wider(tmp) %>%
          mutate(dataset = ds_name, variable = col, Exploratory = NA, Family = NA)
        results[[paste(ds_name,col,sep="_")]] <- test_res
      }
      
      # -----------------------------
      # SMI datasets
      # -----------------------------
    } else if(ds_name %in% c("SMI_total","SMI_upsoil")) {
      cols <- intersect(c("ALB","HAI"), names(df))
      for(col in cols){
        test_res <- test_stationarity(df[[col]]) %>%
          as_tibble() %>%
          mutate(dataset = ds_name, variable = col, region = NA, Exploratory = NA, Family = NA)
        results[[paste(ds_name,col,sep="_")]] <- test_res
      }
      
      # -----------------------------
      # NDVI / NDMI / NIRv datasets
      # -----------------------------
    } else if(grepl("^NDVI_|^NDMI_|^NIRv_", ds_name)) {
      measure_col <- case_when(
        grepl("^NDVI_", ds_name) ~ "mean_NDVI",
        grepl("^NDMI_", ds_name) ~ "mean_NDMI",
        grepl("^NIRv_", ds_name) ~ "mean_NIRv",
        TRUE ~ names(df)[2]
      )
      for(region_name in unique(df$region)) {
        vec <- df %>% filter(region == region_name) %>% pull(all_of(measure_col))
        test_res <- test_stationarity(vec) %>%
          as_tibble() %>%
          mutate(dataset = ds_name, variable = measure_col, region = region_name, Exploratory = NA, Family = NA)
        results[[paste(ds_name,region_name,sep="_")]] <- test_res
      }
    }
  }
  
  # -----------------------------
  # Combine all results
  # -----------------------------
  combined <- bind_rows(results) %>%
    select(dataset, variable, statistic_adf, p_value_adf, status_adf,
           region, Exploratory, Family, statistic_kpss, p_value_kpss, status_kpss,
           recommended_action)
  
  return(combined)
}


# ------------------------------------------------------------------------------
# Apply the stationarity function to the prepared ds21969 ALB & HAI monthly datasets
# ------------------------------------------------------------------------------
combined_stationarity_ds21969_ALB_HAI_monthly <- run_stationarity_monthly_ds21969_ALB_HAI(data_for_ds21969_ALB_HAI)

# ------------------------------------------------------------------------------
# Export the results as CSV
# ------------------------------------------------------------------------------
write_csv(
  combined_stationarity_ds21969_ALB_HAI_monthly,
  "./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv"
)

################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 (SCH) ###################
################################################################################

# ------------------------------------------------------------------------------
# 1. Determine months and year range for SCH
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>% mutate(month_num = as.numeric(month))  # numeric month

years_ds21969 <- range(ds21969$year, na.rm = TRUE)
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

cat("Months SCH:", paste(months_SCH, collapse = ", "), "\n")
cat("Years ds21969:", paste(years_ds21969, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2. Select all monthly datasets (SMI, NDVI, NDMI, NIRv, Weather)
# Exclude irrelevant datasets
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in%
                                c("Fertilization", "mosaic", "ALB_crop",
                                  "HAI_crop", "SCH_crop", "ds22007")]

# ------------------------------------------------------------------------------
# 3. Function to filter data by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year", "month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 5. Apply filtering for all monthly datasets (SCH)
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# ------------------------------------------------------------------------------
# 6. Special handling for Weather (monthly, SCH)
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds21969_SCH)) {
  
  numeric_weather_cols <- data_for_ds21969_SCH$weather %>%
    select(where(is.numeric)) %>%
    select(-year, -month, -month_num) %>%
    names()
  
  data_for_ds21969_SCH$weather <- data_for_ds21969_SCH$weather %>%
    group_by(region, year, month_num) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    rename(month = month_num)
}

################################################################################
# Stationarity tests for SCH
################################################################################
run_stationarity_monthly_ds21969_SCH <- function(data_list) {
  
  test_stationarity <- function(vec) {
    vec <- na.omit(vec)
    if(length(vec) < 3) {
      return(list(
        statistic_adf = NA, p_value_adf = NA, status_adf = NA,
        statistic_kpss = NA, p_value_kpss = NA, status_kpss = NA,
        recommended_action = "Indeterminate, check data or increase time series length"
      ))
    }
    
    # ADF test
    adf <- try(adf.test(vec), silent = TRUE)
    if(inherits(adf, "try-error")) {
      adf_stat <- NA; adf_p <- NA; adf_status <- NA
    } else {
      adf_stat <- as.numeric(adf$statistic)
      adf_p <- adf$p.value
      adf_status <- ifelse(adf_p < 0.05, "stationary", "non-stationary")
    }
    
    # KPSS test
    kpss <- try(kpss.test(vec, null = "Level"), silent = TRUE)
    if(inherits(kpss, "try-error")) {
      kpss_stat <- NA; kpss_p <- NA; kpss_status <- NA
    } else {
      kpss_stat <- as.numeric(kpss$statistic)
      kpss_p <- kpss$p.value
      kpss_status <- ifelse(kpss_p < 0.05, "non-stationary", "stationary")
    }
    
    # Recommended action with 5 categories
    recommended <- case_when(
      adf_status == "stationary" & kpss_status == "non-stationary" ~
        "Apply differencing to time series and check for stationarity again (difference stationary)",
      adf_status == "non-stationary" & kpss_status == "stationary" ~
        "Detrend time series and check for stationarity again (trend stationary)",
      adf_status == "stationary" & kpss_status == "stationary" ~
        "No transformation required (stationary)",
      adf_status == "non-stationary" & kpss_status == "non-stationary" ~
        "Detrend and then difference the time series and recheck for stationarity (both trends present)",
      TRUE ~ "Indeterminate, check data or increase time series length"
    )
    
    return(list(
      statistic_adf = adf_stat, p_value_adf = adf_p, status_adf = adf_status,
      statistic_kpss = kpss_stat, p_value_kpss = kpss_p, status_kpss = kpss_status,
      recommended_action = recommended
    ))
  }
  
  # Aggregate ds21969 insect data for SCH
  insects <- data_list$ds21969 %>%
    group_by(Exploratory, month, year, Family) %>%
    summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
  data_list$ds21969 <- insects
  
  # Filter weather data for SCH
  if("weather" %in% names(data_list)) {
    data_list$weather <- data_list$weather %>% filter(region == "SCH")
  }
  
  results <- list()
  
  for(ds_name in names(data_list)) {
    df <- data_list[[ds_name]]
    
    if(ds_name == "ds21969") {
      for(col in "NumberAdults") {
        test_res <- df %>%
          group_by(Family) %>%
          summarise(tmp = list(test_stationarity(get(col))), .groups = "drop") %>%
          unnest_wider(tmp) %>%
          mutate(dataset = ds_name, variable = col, region = "SCH", Exploratory = "SCH")
        results[[paste(ds_name, col, sep = "_")]] <- test_res
      }
      
    } else if(ds_name == "weather") {
      numeric_cols <- names(df)[sapply(df, is.numeric)]
      numeric_cols <- setdiff(numeric_cols, c("year", "month_num"))
      for(col in numeric_cols) {
        test_res <- test_stationarity(df[[col]]) %>%
          as_tibble() %>%
          mutate(dataset = ds_name, variable = col, region = "SCH", Exploratory = NA, Family = NA)
        results[[paste(ds_name, col, sep = "_")]] <- test_res
      }
      
    } else if(ds_name %in% c("SMI_total", "SMI_upsoil")) {
      cols <- intersect("SCH", names(df))
      for(col in cols) {
        test_res <- test_stationarity(df[[col]]) %>%
          as_tibble() %>%
          mutate(dataset = ds_name, variable = col, region = "SCH", Exploratory = NA, Family = NA)
        results[[paste(ds_name, col, sep = "_")]] <- test_res
      }
      
    } else if(grepl("^NDVI_|^NDMI_|^NIRv_", ds_name)) {
      measure_col <- case_when(
        grepl("^NDVI_", ds_name) ~ "mean_NDVI",
        grepl("^NDMI_", ds_name) ~ "mean_NDMI",
        grepl("^NIRv_", ds_name) ~ "mean_NIRv",
        TRUE ~ names(df)[2]
      )
      vec <- df %>% pull(all_of(measure_col))
      test_res <- test_stationarity(vec) %>%
        as_tibble() %>%
        mutate(dataset = ds_name, variable = measure_col, region = "SCH", Exploratory = NA, Family = NA)
      results[[paste(ds_name, "SCH", sep = "_")]] <- test_res
    }
  }
  
  combined <- bind_rows(results) %>%
    select(dataset, variable, statistic_adf, p_value_adf, status_adf,
           region, Exploratory, Family, statistic_kpss, p_value_kpss, status_kpss,
           recommended_action)
  
  return(combined)
}

# ------------------------------------------------------------------------------
# Apply the stationarity tests to the prepared SCH monthly datasets
# ------------------------------------------------------------------------------
combined_stationarity_ds21969_SCH_monthly <-
  run_stationarity_monthly_ds21969_SCH(data_for_ds21969_SCH)


# ------------------------------------------------------------------------------
# Export results as CSV
# ------------------------------------------------------------------------------
write_csv(
  combined_stationarity_ds21969_SCH_monthly,
  "./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv"
)

