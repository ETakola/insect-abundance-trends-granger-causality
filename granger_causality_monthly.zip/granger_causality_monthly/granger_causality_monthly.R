################### GRANGER CAUSALITY - MONTHLY ###########################################
#################### ds22007 #############################################################

################### Load packages ###########################    
library(lmtest)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) 

#################### Load data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

############################################################################################
#Load insect data 

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable

# Load previously computed ADF/KPSS results
stationarity_table_ds21969_ALB_HAI <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv", sep =",")
stationarity_table_ds21969_SCH <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv", sep =",")
stationarity_table_ds22007 <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep =",")


############################## Create data list for easier handling ##############
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB, NDVI_HAI = NDVI_HAI, NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB, NDMI_HAI = NDMI_HAI, NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB, NIRv_HAI = NIRv_HAI, NIRv_SCH = NIRv_SCH,
  weather = weather, 
  ds21969 = ds21969, ds22007 = ds22007
)

configs <- list(
  SMI_total = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  SMI_upsoil = list(type = "columns", cols = c("ALB", "HAI", "SCH")),
  NDVI_ALB = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_HAI = list(type = "columns", cols = c("mean_NDVI")),
  NDVI_SCH = list(type = "columns", cols = c("mean_NDVI")),
  NDMI_ALB = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_HAI = list(type = "columns", cols = c("mean_NDMI")),
  NDMI_SCH = list(type = "columns", cols = c("mean_NDMI")),
  NIRv_ALB = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_HAI = list(type = "columns", cols = c("mean_NIRv")),
  NIRv_SCH = list(type = "columns", cols = c("mean_NIRv")),
  weather = list(type = "grouped", group_cols = c("region"), value_cols = names(weather)[3:39]),
  ds21969 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults")),
  ds22007 = list(type = "grouped", group_cols = c("Exploratory", "Family"), value_cols = c("NumberAdults"))
)

################## Filter only stationary datasets #################
ds21969_stationary_ALB_HAI <- stationarity_table_ds21969_ALB_HAI %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_stationary_SCH <- stationarity_table_ds21969_SCH %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_stationary <- stationarity_table_ds22007 %>%
  filter(status_adf == "stationary", status_kpss == "stationary")


################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# This script performs monthly aggregation for datasets with monthly resolution.
# Notes:
# - Only datasets with monthly resolution are included (exclude Fertilization & mosaic).
# - Time period and months are matched to ds22007.
# - Only months April to October (4–10) are considered.

# ------------------------------------------------------------------------------
# 1 Determine the months and year ranges from ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))          # unique months present in ds22007
years_ds22007 <- range(ds22007$year, na.rm = TRUE)    # min and max years in ds22007

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2 Remove datasets that do not have monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ds22007", "ALB_crop", "HAI_crop", "SCH_crop")]

# ------------------------------------------------------------------------------
# 3 Define a filter function to select months April–October within year range
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df)
  
  df %>%
    filter(
      month %in% 4:10,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4 Apply the monthly filter to datasets for ds22007
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# ------------------------------------------------------------------------------
# 5 Remove ds21969 if accidentally included
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- data_for_ds22007_monthly[!names(data_for_ds22007_monthly) %in% c("ds21969")]

# ------------------------------------------------------------------------------
# 6 Re-add the ds22007 insect dataset (monthly resolution)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007

# Aggregate ds22007 by exploratory site, month, year, and family
data_for_ds22007_monthly$ds22007 <- data_for_ds22007_monthly$ds22007 %>%
  group_by(Exploratory, month, year, Family) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")


# ------------------------------------------------------------------------------
# 7 Special handling for Weather: Aggregate per region + month + year
# ------------------------------------------------------------------------------
if ("weather" %in% names(data_for_ds22007_monthly)) {
  
  # Check which columns are numeric (year/month/region are excluded)
  numeric_weather_cols <- data_for_ds22007_monthly$weather %>%
    select(-year, -month, -region) %>%
    select(where(is.numeric)) %>%
    names()
  
  data_for_ds22007_monthly$weather <- data_for_ds22007_monthly$weather %>%
    group_by(region, year, month) %>%
    summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    )
  
}


###################### FILTER FOR MONTHLY ds22007 ###########################
# -------------------------------------------------------------------
# Function: filter monthly ds22007 datasets based on stationary variables
# -------------------------------------------------------------------
filter_ds22007_dataset_monthly <- function(df, dataset_name, overview_ds22007) {
  
  # Check whether the dataset is listed in the stationary overview
  if(!dataset_name %in% unique(overview_ds22007$dataset)) return(NULL)
  
  # Variables allowed for this dataset
  allowed_columns <- overview_ds22007 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly data include month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final set of columns to retain
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns (except year and month) by allowed values
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds22007 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>%
      unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>%
        filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for NDVI / NDMI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NirV_ALB","NirV_HAI","NirV_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds22007 datasets
# -------------------------------------------------------------------
filtered_ds22007_monthly_list <- imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_dataset_monthly(df, name, ds22007_stationary)
  }
)

# Remove NULL entries
filtered_ds22007_monthly_list <- filtered_ds22007_monthly_list[
  !sapply(filtered_ds22007_monthly_list, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds22007_monthly_list$ds22007
# -------------------------------------------------------------------
names(filtered_ds22007_monthly_list)
str(filtered_ds22007_monthly_list, max.level = 1)

######################################################################
############## Build sub-lists of ds22007_monthly by region ##########
######################################################################

#################### ALB ##########################################
# 1. SMI
smi_total_alb <- filtered_ds22007_monthly_list$SMI_total %>%
  dplyr::select(month, year, ALB)
smi_upsoil_alb <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, ALB)

# 2. NDVI, NDMI, NIRv
ndvi_alb <- filtered_ds22007_monthly_list$NDVI_ALB
ndmi_alb <- filtered_ds22007_monthly_list$NDMI_ALB
nirv_alb <- filtered_ds22007_monthly_list$NIRv_ALB

# 4. Weather
weather_alb <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "ALB")

# 5. ds22007 for ALB
ds22007_alb <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "ALB")

# 6. Create sub-list
ds22007_monthly_ALB <- list(
  SMI_total = smi_total_alb,
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDMI = ndmi_alb,
  NIRv = nirv_alb,
  weather = weather_alb,
  ds22007 = ds22007_alb
)

#################### HAI ##########################################
# 1. SMI_upsoil
smi_hai <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, HAI)

# 2. NDVI, NDMI, NIRv
ndvi_hai <- filtered_ds22007_monthly_list$NDVI_HAI
ndmi_hai <- filtered_ds22007_monthly_list$NDMI_HAI
nirv_hai <- filtered_ds22007_monthly_list$NIRv_HAI

# 3. Weather
weather_hai <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "HAI")

# 4. ds22007
ds22007_hai <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "HAI")

# 5. Create sub-list
ds22007_monthly_HAI <- list(
  SMI_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NDMI = ndmi_hai,
  NIRv = nirv_hai,
  weather = weather_hai,
  ds22007 = ds22007_hai
)

#################### SCH ##########################################
# 1. SMI_upsoil
smi_sch <- filtered_ds22007_monthly_list$SMI_upsoil %>%
  dplyr::select(month, year, SCH)

# 2. NDVI, NDMI, NIRv
ndvi_sch <- filtered_ds22007_monthly_list$NDVI_SCH
ndmi_sch <- filtered_ds22007_monthly_list$NDMI_SCH
nirv_sch <- filtered_ds22007_monthly_list$NIRv_SCH

# 3. Weather
weather_sch <- filtered_ds22007_monthly_list$weather %>%
  filter(region == "SCH")

# 4. ds22007
ds22007_sch <- filtered_ds22007_monthly_list$ds22007 %>%
  filter(Exploratory == "SCH")

# 5. Create sub-list
ds22007_monthly_SCH <- list(
  smi_upsoil = smi_sch,
  NDVI = ndvi_sch,
  NDMI = ndmi_sch,
  NIRv = nirv_sch,
  weather = weather_sch,
  ds22007 = ds22007_sch
)

#####################################################################################
######### GRANGER TEST DS22007 ######################################################
########################## ALB ######################################################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_ALB$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) { 
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_ALB$ds22007 %>% 
    dplyr::filter(Family == family_name) %>% 
    dplyr::group_by(year, month) %>% 
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_total
# -----------------------------
results_smi_total <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_ALB$SMI_total, "ALB")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_total", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test SMI_upsoil
# -----------------------------
results_smi_upsoil <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_ALB$SMI_upsoil, "ALB")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "ALB",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 6. Test NDVI, NDMI, NIRv
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_ALB$NDVI %>% dplyr::select(year, month, ALB = mean_NDVI),
  NDMI = ds22007_monthly_ALB$NDMI %>% dplyr::select(year, month, ALB = mean_NDMI),
  NIRv = ds22007_monthly_ALB$NIRv %>% dplyr::select(year, month, ALB = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "ALB",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_ALB$weather)[!(names(ds22007_monthly_ALB$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_ALB$weather %>% dplyr::select(year, month, ALB = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 8. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_ALB <- dplyr::bind_rows(results_smi_total, results_smi_upsoil, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 9. Review and save results
# -----------------------------
head(results_ds22007_monthly_ALB)
write.csv(results_ds22007_monthly_ALB, "./tables/granger_test/results_ds22007_monthly_ALB.csv", row.names = FALSE)

############################################################################
##################### HAI, lags 1-3 #######################################
######################### GRANGER TEST FOR DS22007 - HAI (MONTHLY, MULTIPLE LAGS) ##################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_HAI$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_HAI$ds22007 %>%
    dplyr::filter(Family == family_name) %>%
    dplyr::group_by(year, month) %>%
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_upsoil
# -----------------------------
results_smi <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_HAI$SMI_upsoil, "HAI")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "HAI",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test NDVI, NDMI, NIRv
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_HAI$NDVI %>% dplyr::select(year, month, HAI = mean_NDVI),
  NDMI = ds22007_monthly_HAI$NDMI %>% dplyr::select(year, month, HAI = mean_NDMI),
  NIRv = ds22007_monthly_HAI$NIRv %>% dplyr::select(year, month, HAI = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "HAI",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 6. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_HAI$weather)[!(names(ds22007_monthly_HAI$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_HAI$weather %>% dplyr::select(year, month, HAI = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_HAI <- dplyr::bind_rows(results_smi, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 8. Review and save results
# -----------------------------
head(results_ds22007_monthly_HAI)
write.csv(results_ds22007_monthly_HAI, "./tables/granger_test/results_ds22007_monthly_HAI.csv", row.names = FALSE)

############################################################################
##################### SCH, lags 1-3 #######################################
######################### GRANGER TEST FOR DS22007 - SCH (MONTHLY, MULTIPLE LAGS) ##################

# -----------------------------
# 0. Safe Granger test function
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. List of families
# -----------------------------
families <- unique(ds22007_monthly_SCH$ds22007$Family)

# -----------------------------
# 2. Define lags to test (e.g., 1–3)
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  # Aggregate insect counts per month/year
  insect_agg <- ds22007_monthly_SCH$ds22007 %>%
    dplyr::filter(Family == family_name) %>%
    dplyr::group_by(year, month) %>%
    dplyr::summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  # Arrange environmental data and merge with insects (common months only)
  env_df <- env_df %>% dplyr::arrange(year, month)
  
  df <- dplyr::inner_join(
    insect_agg %>% dplyr::mutate(month = as.integer(month)),
    env_df %>% dplyr::mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test SMI_upsoil
# -----------------------------
results_smi <- purrr::map_dfr(families, function(fam) {
  ts_list <- prepare_ts(fam, ds22007_monthly_SCH$smi_upsoil, "SCH")
  purrr::map_dfr(lags_to_test, function(lag_val) {
    res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
    tibble(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "SCH",
           F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
  })
})

# -----------------------------
# 5. Test NDVI, NDMI, NIRv
# -----------------------------
env_list <- list(
  NDVI = ds22007_monthly_SCH$NDVI %>% dplyr::select(year, month, SCH = mean_NDVI),
  NDMI = ds22007_monthly_SCH$NDMI %>% dplyr::select(year, month, SCH = mean_NDMI),
  NIRv = ds22007_monthly_SCH$NIRv %>% dplyr::select(year, month, SCH = mean_NIRv)
)

results_env <- purrr::map_dfr(names(env_list), function(envname) {
  env_df <- env_list[[envname]]
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = envname, EnvColumn = "SCH",
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 6. Test weather variables
# -----------------------------
weather_vars <- names(ds22007_monthly_SCH$weather)[!(names(ds22007_monthly_SCH$weather) %in% c("year","month","region"))]

results_weather <- purrr::map_dfr(weather_vars, function(varname) {
  env_df <- ds22007_monthly_SCH$weather %>% dplyr::select(year, month, SCH = dplyr::all_of(varname))
  purrr::map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    purrr::map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 7. Combine all results and mark causality
# -----------------------------
results_ds22007_monthly_SCH <- dplyr::bind_rows(results_smi, results_env, results_weather) %>%
  dplyr::mutate(causal_label = dplyr::case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 8. Review and save results
# -----------------------------
head(results_ds22007_monthly_SCH)
write.csv(results_ds22007_monthly_SCH, "./tables/granger_test/results_ds22007_monthly_SCH.csv", row.names = FALSE)



###################### FILTER FOR MONTHLY ds21969 ###########################

# -------------------------------------------------------------------
# Function: filter monthly ds21969 datasets based on stationary vars
# -------------------------------------------------------------------
filter_ds21969_dataset_monthly <- function(df, dataset_name, overview_ds21969) {
  
  # Check if dataset appears in stationary overview
  if(!dataset_name %in% unique(overview_ds21969$dataset)) return(NULL)
  
  # Allowed variables for this dataset
  allowed_columns <- overview_ds21969 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns except year & month
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds21969 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region for NDVI / NDWI / NirV datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to ALL monthly ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_monthly_ALB_HAI_list <- imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_stationary_ALB_HAI)
  }
)

filtered_ds21969_monthly_list_SCH <- imap(
  data_for_ds21969_SCH,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_stationary_SCH)
  }
)

# remove NULL entries
filtered_ds21969_monthly_list <- filtered_ds21969_monthly_ALB_HAI_list[
  !sapply(filtered_ds21969_monthly_ALB_HAI_list, is.null)
]

filtered_ds21969_monthly_list_SCH <- filtered_ds21969_monthly_list_SCH[
  !sapply(filtered_ds21969_monthly_list_SCH, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds21969_monthly_list$ds21969_ALB_HAI
# filtered_ds21969_monthly_list_SCH$ds21969_SCH
# -------------------------------------------------------------------

names(filtered_ds21969_monthly_list)
names(filtered_ds21969_monthly_list_SCH)
str(filtered_ds21969_monthly_ALB_HAI_list, max.level = 1)
str(filtered_ds21969_monthly_list_SCH, max.level = 1)


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1 Determine months and year range for ds21969
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>% mutate(month_num = as.numeric(month))

years_ds21969 <- range(ds21969$year, na.rm = TRUE)

months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

cat("Months ALB & HAI:", paste(months_ALB_HAI, collapse = ", "), "\n")
cat("Months SCH:", paste(months_SCH, collapse = ", "), "\n")
cat("Year range ds21969:", paste(years_ds21969, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2 Select all monthly datasets (excluding irrelevant ones)
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% 
                                c("Fertilization", "mosaic", "ALB_crop", "HAI_crop", "SCH_crop", "ds22007")]

# ------------------------------------------------------------------------------
# 3 Define function to filter datasets by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4 Filter datasets for ALB & HAI and SCH
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[!names(data_for_ds21969_ALB_HAI) %in% c("ds22007")]
data_for_ds21969_SCH <- data_for_ds21969_SCH[!names(data_for_ds21969_SCH) %in% c("ds22007")]

# Add ds21969 insect dataset
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>% filter(Exploratory %in% c("ALB","HAI"))
data_for_ds21969_SCH$ds21969 <- ds21969 %>% filter(Exploratory == "SCH")

# ------------------------------------------------------------------------------
# 5 Special handling for Weather (monthly)
# ------------------------------------------------------------------------------
process_weather <- function(weather_df) {
  
  # Identify numeric weather columns (exclude year/month/region)
  numeric_weather_cols <- weather_df %>%
    select(where(is.numeric)) %>%
    select(-year, -month, -month_num) %>%
    names()
  
  # Aggregate by region × year × month
  weather_df %>%
    group_by(region, year, month_num) %>%
    summarise(across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
              .groups = "drop") %>%
    rename(month = month_num)
}

if ("weather" %in% names(data_for_ds21969_ALB_HAI)) {
  data_for_ds21969_ALB_HAI$weather <- process_weather(data_for_ds21969_ALB_HAI$weather)
}

if ("weather" %in% names(data_for_ds21969_SCH)) {
  data_for_ds21969_SCH$weather <- process_weather(data_for_ds21969_SCH$weather)
}

######################################################################
############## build sub-lists of ds21969_monthly by region ##########
######################################################################

#################### ALB #############################################

# 1. Weather
weather_alb <- filtered_ds21969_monthly_list$weather %>% filter(region == "ALB")

# 2. ds21969 for ALB
ds21969_alb <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "ALB")

# 3. Create sub-list
ds21969_monthly_ALB <- list(
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI #############################################

# 1. Weather
weather_hai <- filtered_ds21969_monthly_list$weather %>% filter(region == "HAI")

# 2. ds21969 for HAI
ds21969_hai <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "HAI")

# 3. Create sub-list
ds21969_monthly_HAI <- list(
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH #############################################

# 1. Weather
weather_sch <- filtered_ds21969_monthly_list_SCH$weather %>% filter(region == "SCH")

# 2. ds21969 for SCH
ds21969_sch <- filtered_ds21969_monthly_list_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 3. Create sub-list
ds21969_monthly_SCH <- list(
  weather = weather_sch,
  ds21969 = ds21969_sch
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## ALB ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_ALB$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_ALB$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_ALB$weather)[
  !(names(ds21969_monthly_ALB$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_ALB$weather %>% dplyr::select(year, month, ALB = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "ALB")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 5. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_ALB <- bind_rows(
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 6. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_ALB)

write.csv(
  results_ds21969_monthly_ALB,
  "./tables/granger_test/results_ds21969_monthly_ALB.csv",
  row.names = FALSE
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## HAI ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if(length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_HAI$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_HAI$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_HAI$weather)[
  !(names(ds21969_monthly_HAI$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_HAI$weather %>% dplyr::select(year, month, HAI = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "HAI")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 5. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_HAI <- bind_rows(
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 6. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_HAI)

write.csv(
  results_ds21969_monthly_HAI,
  "./tables/granger_test/results_ds21969_monthly_HAI.csv",
  row.names = FALSE
)


#####################################################################################
######### GRANGER TEST – DS21969 #####################################################
########################## SCH ######################################################

# -----------------------------
# 0. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lag = 1) {
  if (length(x) != length(y) || any(is.na(x)) || any(is.na(y)) || length(x) <= lag) {
    return(tibble(F_stat = NA, p_value = NA, lag = lag))
  }
  tryCatch({
    res <- grangertest(x ~ y, order = lag)
    tibble(F_stat = res$F[2], p_value = res$`Pr(>F)`[2], lag = lag)
  }, error = function(e) tibble(F_stat = NA, p_value = NA, lag = lag))
}

# -----------------------------
# 1. Family list
# -----------------------------
families <- unique(ds21969_monthly_SCH$ds21969$Family)

# -----------------------------
# 2. Define lags
# -----------------------------
lags_to_test <- 1:3

# -----------------------------
# 3. Function to align time series per family
# -----------------------------
prepare_ts <- function(family_name, env_df, env_col) {
  insect_agg <- ds21969_monthly_SCH$ds21969 %>%
    filter(Family == family_name) %>%
    group_by(year, month) %>%
    summarise(NumberAdults = sum(NumberAdults), .groups = "drop")
  
  env_df <- env_df %>% arrange(year, month)
  
  df <- inner_join(
    insect_agg %>% mutate(month = as.integer(month)),
    env_df %>% mutate(month = as.integer(month)),
    by = c("year", "month")
  )
  
  list(insect = df$NumberAdults, env = df[[env_col]])
}

# -----------------------------
# 4. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_SCH$weather)[
  !(names(ds21969_monthly_SCH$weather) %in% c("year", "month", "region"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_SCH$weather %>%
    dplyr::select(year, month, SCH = all_of(varname))
  map_dfr(families, function(fam) {
    ts_list <- prepare_ts(fam, env_df, "SCH")
    map_dfr(lags_to_test, function(lag_val) {
      res <- granger_safe(ts_list$insect, ts_list$env, lag = lag_val)
      tibble(Family = fam, EnvDataset = "weather", EnvColumn = varname,
             F_stat = res$F_stat, p_value = res$p_value, lag = lag_val)
    })
  })
})

# -----------------------------
# 5. Combine all results and label causality
# -----------------------------
results_ds21969_monthly_SCH <- bind_rows(
  results_weather
) %>%
  mutate(causal_label = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# 6. Inspect and export results
# -----------------------------
head(results_ds21969_monthly_SCH)

write.csv(
  results_ds21969_monthly_SCH,
  "./tables/granger_test/results_ds21969_monthly_SCH.csv",
  row.names = FALSE
)

