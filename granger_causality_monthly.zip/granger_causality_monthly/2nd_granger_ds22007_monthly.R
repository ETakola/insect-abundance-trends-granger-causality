########################## SECOND ROUND GRANGER ###############################
# Perform Granger tests on detrended and/or differenced data (stationary series):
# 1. Use outputs from the detrending scripts
# 2. Apply Granger tests on all stationary insect time series combined

################### load packages ###########################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # stationarity tests

#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable
##### stationarity tables from first Granger round #####

# Combined ADF/KPSS results

stationarity_table_ds22007_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep=",")

##### stationary datasets after detrending/differencing #####

# ds22007 monthly
ds22007_both_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_monthly.csv", sep=",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_detrended_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_monthly.csv", sep=",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds22007_differenced_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_monthly.csv", sep=",") %>%
  filter(adf_status == "stationary", kpss_status == "stationary", Family != "Fam.")

############################## data list for unified handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  weather = weather,
  ds22007 = ds22007
)


################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# - Only datasets with monthly resolution (excluding Fertilization & mosaic)
# - Time period and months aligned with ds22007
# - Only months April–October (4–10)

# ------------------------------------------------------------------------------
# 1 Determine time span and month range of ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2 Remove datasets without monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% c("Fertilization", "mosaic", "ds22007")]

# ------------------------------------------------------------------------------
# 3 Filtering function for target months (April–October)
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df) # skip datasets without monthly information
  df %>%
    filter(
      month %in% 4:10,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4 Apply filtering for ds22007 time span (monthly datasets only)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# ------------------------------------------------------------------------------
# 5 Re-add insect dataset without modification
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007
data_for_ds22007_monthly$ds22007 <- group_by(
  data_for_ds22007_monthly$ds22007,
  Exploratory, month, year, Family
) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")

################################################################################
# Special handling for Weather (monthly aggregation by region) for ds22007
################################################################################

aggregate_weather_monthly <- function(weather_df) {
  
  if(is.null(weather_df) || nrow(weather_df) == 0){
    message("⚠ Weather dataset empty → returning NULL")
    return(NULL)
  }
  
  # Create month_num if it doesn't exist
  if(!"month_num" %in% names(weather_df)){
    weather_df <- weather_df %>%
      mutate(month_num = as.numeric(month))
  }
  
  # numeric columns to aggregate (exclude time and grouping columns)
  numeric_weather_cols <- weather_df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::select(-year, -month, -month_num) %>%
    names()
  
  if(length(numeric_weather_cols) == 0){
    message("⚠ Weather dataset has no numeric columns → returning as-is")
    return(weather_df)
  }
  
  # aggregate by region, year, month_num
  weather_df %>%
    dplyr::group_by(region, year, month_num) %>%
    dplyr::summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    dplyr::rename(month = month_num)
}

# Apply aggregation to ds22007 weather
if("weather" %in% names(data_for_ds22007_monthly)){
  data_for_ds22007_monthly$weather <- aggregate_weather_monthly(
    data_for_ds22007_monthly$weather
  )
}

cat(" ds22007 weather aggregated by region, year, month\n")

##############################################################################
################## SELECT ONLY STATIONARY RESULTS FROM TABLE #################
# monthly
ds22007_stationary_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DETRENDING #################
# monthly
ds22007_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DIFFERENCING #################
# monthly
ds22007_differencing_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

# Remove rows where variable is "year"
ds22007_differencing_monthly <- ds22007_differencing_monthly %>%
  filter(variable != "year")

################## SELECT DATASETS REQUIRING BOTH METHODS ###################
# monthly
ds22007_diff_and_detrend_monthly <- stationarity_table_ds22007_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "non-stationary")

########################### DS22007 ##############################################
########################### DETREND DS22007 MONTHLY ##############################

# -------------------------------------------------------------------
# 1. Filtering function for detrending (analogous to yearly workflow)
# -------------------------------------------------------------------
filter_ds22007_detrend_monthly <- function(df, dataset_name, detrend_overview) {
  
  # Check whether dataset is listed in the detrending overview
  if(!dataset_name %in% detrend_overview$dataset) {
    cat("Dataset", dataset_name, "not found in detrend overview\n")
    return(NULL)
  } else {
    cat("Dataset", dataset_name, "found\n")
  }
  
  # Variables allowed for detrending
  allowed_columns <- detrend_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Potential grouping columns
  grouping_columns <- c("year", "month", "Croptype", "Fertilizer",
                        "region", "var", "measure", "Exploratory", "Family")
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only columns that actually exist in the data frame
  columns_to_keep <- intersect(unique(c(existing_group_cols, allowed_columns)), names(df))
  
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# 2. Create filtered list of all ds22007 monthly datasets for detrending
# -------------------------------------------------------------------
filtered_ds22007_detrend_monthly <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_detrend_monthly(df, name, ds22007_detrend_monthly)
  }
)

# Remove NULL entries
filtered_ds22007_detrend_monthly <- filtered_ds22007_detrend_monthly[
  !sapply(filtered_ds22007_detrend_monthly, is.null)
]

cat("\nFiltered datasets for detrending (monthly):\n")
print(names(filtered_ds22007_detrend_monthly))

# -------------------------------------------------------------------
# 3. Linear detrending function
# -------------------------------------------------------------------
detrend_ts_monthly <- function(df, value_cols, time_col) {
  df_detrended <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      # Use only rows with valid values
      valid_idx <- !is.na(df[[col]]) & !is.na(df[[time_col]])
      if(sum(valid_idx) > 2) {
        fit <- lm(df[[col]][valid_idx] ~ df[[time_col]][valid_idx])
        df_detrended[[col]] <- NA
        df_detrended[[col]][valid_idx] <- residuals(fit)
      } else {
        df_detrended[[col]] <- NA
      }
    }
  }
  
  return(df_detrended)
}

# -------------------------------------------------------------------
# 4. Apply detrending to filtered datasets
# -------------------------------------------------------------------
filtered_ds22007_detrended_monthly <- imap(
  filtered_ds22007_detrend_monthly,
  function(df, name) {
    
    value_cols <- ds22007_detrend_monthly %>%
      filter(dataset == name) %>%
      pull(variable)
    
    # Numeric time variable: year + month / 12
    df <- df %>%
      mutate(
        month = as.numeric(month),
        year_month_numeric = year + month / 12
      )
    
    detrend_ts_monthly(df, value_cols, time_col = "year_month_numeric")
  }
)

cat("\nDetrended monthly datasets:\n")
print(names(filtered_ds22007_detrended_monthly))

# -------------------------------------------------------------------
# Example output: first rows of the first dataset
# -------------------------------------------------------------------
if(length(filtered_ds22007_detrended_monthly) > 0) {
  cat("\nExample: first rows of the first dataset:\n")
  print(head(filtered_ds22007_detrended_monthly[[1]]))
}

filtered_ds22007_detrended_monthly$ds22007$NumberAdults_detrended <-
  filtered_ds22007_detrended_monthly$ds22007$NumberAdults

filtered_ds22007_detrended_monthly$ds22007 <-
  filtered_ds22007_detrended_monthly$ds22007 %>%
  dplyr::select(-NumberAdults, -year_month_numeric)

filtered_ds22007_detrended_monthly$ds22007[
  complete.cases(filtered_ds22007_detrended_monthly$ds22007),
]

########################### DIFFERENCING DS22007 MONTHLY ########################

# -------------------------------------------------------------------
# 1. Lag-1 differencing for monthly data
# -------------------------------------------------------------------
difference_ts_monthly <- function(df, value_cols, time_cols = c("year", "month")) {
  df_diff <- df
  num_cols <- intersect(value_cols, names(df))
  
  for(col in num_cols) {
    df_diff[[col]] <- c(NA, diff(df[[col]]))
  }
  
  for(tc in time_cols) {
    if(!tc %in% names(df_diff)) df_diff[[tc]] <- df[[tc]]
  }
  
  return(df_diff)
}

# -------------------------------------------------------------------
# 2. Safe filtering and differencing for normal datasets
# -------------------------------------------------------------------
filter_ds22007_diff_monthly_safe <- function(df, dataset_name, diff_overview) {
  
  # Check if dataset is listed in the overview
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  # Variables to be differenced
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns
  grouping_columns <- c("year", "month", "Croptype", "Fertilizer", "region",
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only relevant columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns
  for(col in setdiff(existing_group_cols, c("year","month"))) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Keep only allowed Family–Exploratory combinations
  allowed_combinations <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family","Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Apply differencing only if data exists
  if(nrow(df_filtered) > 0) {
    df_diff <- difference_ts_monthly(df_filtered, allowed_columns, time_cols = c("year","month"))
    return(df_diff)
  } else {
    return(NULL)
  }
}

# -------------------------------------------------------------------
# 3. Special differencing for Weather
# -------------------------------------------------------------------
difference_weather_monthly <- function(weather_df) {
  # All columns except year, month, region
  value_cols <- setdiff(names(weather_df), c("year","month","region"))
  difference_ts_monthly(weather_df, value_cols, time_cols = c("year","month"))
}

# -------------------------------------------------------------------
# 4. Apply filtering and differencing to all datasets
# -------------------------------------------------------------------
filtered_ds22007_diffed_monthly_safe <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name) {
    if(name == "weather") {
      difference_weather_monthly(df)
    } else {
      filter_ds22007_diff_monthly_safe(df, name, ds22007_differencing_monthly)
    }
  }
)

# Remove NULL and empty DataFrames
filtered_ds22007_diffed_monthly_safe <- filtered_ds22007_diffed_monthly_safe[
  sapply(filtered_ds22007_diffed_monthly_safe, function(x) !is.null(x) && nrow(x) > 0)
]

# -------------------------------------------------------------------
# 5. Safely convert month column
# -------------------------------------------------------------------
filtered_ds22007_diffed_monthly_safe <- lapply(
  filtered_ds22007_diffed_monthly_safe,
  function(df) {
    if("month" %in% names(df)) df <- df %>% mutate(month = as.numeric(month))
    df
  }
)

# -------------------------------------------------------------------
# 6. Test output
# -------------------------------------------------------------------
cat("Differenced monthly datasets:\n")
print(names(filtered_ds22007_diffed_monthly_safe))
str(filtered_ds22007_diffed_monthly_safe)


####################### DS22007 – MONTHLY – DETREND + DIFFERENCE #################

# =====================================================================================
# 1) Function to filter datasets (analogous to ds22007_yearly)
# =====================================================================================
filter_ds22007_monthly_diff_detrend <- function(df, dataset_name, overview_table) {
  
  # Check whether dataset is listed in the overview table
  if(!dataset_name %in% unique(overview_table$dataset)) {
    cat("Dataset", dataset_name, "not listed in overview\n")
    return(NULL)
  }
  
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year", "month", "Croptype", "Fertilizer", "region", 
                        "var", "measure", "Exploratory", "Family")
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns (excluding year and month)
  for(col in setdiff(existing_group_cols, c("year","month"))) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    if(length(allowed_values) > 0){
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region column for satellite products
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% select(-dplyr::any_of("region"))
  }
  
  cat("Dataset", dataset_name, "filtered.\n")
  return(df_filtered)
}

# =====================================================================================
# 2) Apply to all ds22007 monthly datasets
# =====================================================================================
filtered_ds22007_monthly_diff_detrend <- purrr::imap(
  data_for_ds22007_monthly,
  function(df, name){
    filter_ds22007_monthly_diff_detrend(df, name, ds22007_diff_and_detrend_monthly)
  }
)

filtered_ds22007_monthly_diff_detrend <- filtered_ds22007_monthly_diff_detrend[
  !sapply(filtered_ds22007_monthly_diff_detrend, is.null)
]

cat("\nFiltered datasets for DS22007 monthly:\n")
print(names(filtered_ds22007_monthly_diff_detrend))

# =====================================================================================
# 1) Function: detrending and differencing for DS22007_MONTHLY (without tests)
# =====================================================================================
run_detrend_diff_ds22007_monthly <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- diff_detrend_list[[ds_name]]
    
    # Numeric columns excluding year and month
    value_cols <- names(df)[sapply(df, is.numeric) & !names(df) %in% c("year","month")]
    
    # Grouping columns
    group_cols <- names(df)[!names(df) %in% value_cols & !names(df) %in% c("year","month")]
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    # Time variable for detrending: year + month/12
    df <- df %>% mutate(time_numeric = year + month/12)
    
    df_diffed <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        df_group <- .x
        df_out <- df_group
        
        for(val_col in value_cols) {
          
          ts_data <- df_group %>%
            dplyr::select(time_numeric, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 2) next
          
          # 1) Detrending
          detrended <- tryCatch(
            unname(resid(lm(ts_data[[val_col]] ~ ts_data$time_numeric))),
            error = function(e) NULL
          )
          
          if(is.null(detrended) || length(detrended) < 2) next
          
          # 2) Differencing
          differenced <- unname(c(NA, diff(detrended)))
          
          # Write results back to data frame
          df_out[[val_col]] <- differenced
        }
        
        df_out
      }) %>%
      ungroup()
    
    # Remove helper columns if present
    if("dummy" %in% names(df_diffed)) df_diffed <- df_diffed %>% dplyr::select(-dummy)
    if("time_numeric" %in% names(df_diffed)) df_diffed <- df_diffed %>% dplyr::select(-time_numeric)
    
    results[[ds_name]] <- df_diffed
  }
  
  return(results)
}

# =====================================================================================
# 2) Apply detrending and differencing to filtered datasets
# =====================================================================================
filtered_ds22007_monthly_diffed_detrended <- run_detrend_diff_ds22007_monthly(
  filtered_ds22007_monthly_diff_detrend
)

# =====================================================================================
# 3) Check dataset names
# =====================================================================================
cat("\nFinal list after differencing and detrending:\n")
print(names(filtered_ds22007_monthly_diffed_detrended))

# Example: inspect structure of the first dataset
str(filtered_ds22007_monthly_diffed_detrended[[1]])


#############################MONTHLY###########################################
###################### FILTER FOR MONTHLY ds22007 #############################

# -------------------------------------------------------------------
# Function: filter monthly ds22007 datasets based on stationary vars
# -------------------------------------------------------------------
filter_ds22007_dataset_monthly <- function(df, dataset_name, overview_ds22007) {
  
  # Check if dataset appears in stationary overview
  if(!dataset_name %in% unique(overview_ds22007$dataset)) return(NULL)
  
  # Allowed variables for this dataset
  allowed_columns <- overview_ds22007 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns except year & month
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    
    allowed_values <- overview_ds22007 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region for NDVI / NDMI / NIRv datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to ALL monthly ds22007 datasets
# -------------------------------------------------------------------
filtered_ds22007_monthly_list <- imap(
  data_for_ds22007_monthly,
  function(df, name) {
    filter_ds22007_dataset_monthly(df, name, ds22007_stationary_monthly)
  }
)

# remove NULL entries
filtered_ds22007_monthly_list <- filtered_ds22007_monthly_list[
  !sapply(filtered_ds22007_monthly_list, is.null)
]

filtered_ds22007_monthly_list$ds22007 <- group_by(filtered_ds22007_monthly_list$ds22007, Exploratory, month, year, Family) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
# -------------------------------------------------------------------
# Example access:
# filtered_ds22007_monthly_list$ds22007
# -------------------------------------------------------------------

names(filtered_ds22007_monthly_list)
str(filtered_ds22007_monthly_list, max.level = 1)

######################################################################
##############build sub-lists of ds22007_monthly per region###########
######################################################################

####################### ALB ##########################################
# 1. SMI 
smi_upsoil_alb <- filtered_ds22007_monthly_list$SMI_upsoil %>% dplyr::select(month, year, ALB)


# 2. NDVI, NDMI, NIRv
ndvi_alb <- filtered_ds22007_monthly_list$NDVI_ALB
ndmi_alb <- filtered_ds22007_monthly_list$NDMI_ALB
nirv_alb <- filtered_ds22007_monthly_list$NIRv_ALB

# 4. Weather
weather_alb <- filtered_ds22007_monthly_list$weather %>% filter(region == "ALB")

# 5. ds22007 für ALB
ds22007_alb <- filtered_ds22007_monthly_list$ds22007 %>% filter(Exploratory == "ALB")

# 6. Sub-Liste erstellen
ds22007_monthly_ALB <- list(
  SMI_upsoil = smi_upsoil_alb,
  NDVI = ndvi_alb,
  NDMI = ndmi_alb,
  NIRv = nirv_alb,
  weather = weather_alb,
  ds22007 = ds22007_alb
)

#################### HAI ##########################################
# 1. SMI_upsoil
smi_hai <- filtered_ds22007_monthly_list$SMI_upsoil %>% dplyr::select(month, year, HAI)

# 2. NDVI, NDMI, NIRv
ndvi_hai <- filtered_ds22007_monthly_list$NDVI_HAI
ndmi_hai <- filtered_ds22007_monthly_list$NDMI_HAI
nirv_hai <- filtered_ds22007_monthly_list$NIRv_HAI

# 3. Weather
weather_hai <- filtered_ds22007_monthly_list$weather %>% filter(region == "HAI")

# 4. ds22007
ds22007_hai <- filtered_ds22007_monthly_list$ds22007 %>% filter(Exploratory == "HAI")

# 5. Sub-Liste erstellen
ds22007_monthly_HAI <- list(
  SMI_upsoil = smi_hai,
  NDVI = ndvi_hai,
  NDMI = ndmi_hai,
  NIRv = nirv_hai,
  weather = weather_hai,
  ds22007 = ds22007_hai
)

#################### SCH ##########################################

# 2. NDVI, NDMI, NIRv
ndvi_sch <- filtered_ds22007_monthly_list$NDVI_SCH
ndmi_sch <- filtered_ds22007_monthly_list$NDMI_SCH
nirv_sch <- filtered_ds22007_monthly_list$NIRv_SCH

# 3. Weather
weather_sch <- filtered_ds22007_monthly_list$weather %>% filter(region == "SCH")

# 4. ds22007
ds22007_sch <- filtered_ds22007_monthly_list$ds22007 %>% filter(Exploratory == "SCH")

# 5. Sub-Liste erstellen
ds22007_monthly_SCH <- list(
  NDVI = ndvi_sch,
  NDMI = ndmi_sch,
  NIRv = nirv_sch,
  weather = weather_sch,
  ds22007 = ds22007_sch
)

########## Prepare datasets for merge ###########################################
str(filtered_ds22007_detrended_monthly)

# Aggregate ds22007 counts for ALB by site, month, year, and family
ds22007_monthly_ALB$ds22007 <- group_by(
  ds22007_monthly_ALB$ds22007,
  Exploratory, month, year, Family
) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")

ds22007_monthly_ALB$ds22007$month <- as.numeric(ds22007_monthly_ALB$ds22007$month)

#################### REMOVE DUPLICATES #############################
# Keep only ALB
detrended_alb <- filtered_ds22007_detrended_monthly$ds22007 %>%
  filter(Exploratory == "ALB")

# Identify duplicated rows
detrended_alb[duplicated(detrended_alb), ]

# ---------------------------------------------
# 1) Helper function: merge monthly insect data
# ---------------------------------------------
merge_monthly_insects <- function(old, new) {
  
  key_cols <- c("Exploratory", "Family", "year", "month")
  
  # Ensure key columns exist
  if (!all(key_cols %in% names(old)) | !all(key_cols %in% names(new))) {
    stop("❌ Key columns missing in old or new dataset!")
  }
  
  # Keep only new rows
  new_only <- dplyr::anti_join(new, old, by = key_cols)
  
  if (nrow(new_only) == 0) {
    message("ℹ No new monthly ds22007 rows to add.")
    return(old)
  }
  
  message("➕ Added new rows: ", nrow(new_only))
  
  out <- dplyr::bind_rows(old, new_only) %>%
    dplyr::distinct() %>%
    dplyr::arrange(Exploratory, Family, year, month)
  
  return(out)
}

# ---------------------------------------------
# 2) Set target
# ---------------------------------------------
target <- ds22007_monthly_ALB

# ---------------------------------------------
# 3) Extract new ALB rows
# ---------------------------------------------
new_insects <- filtered_ds22007_detrended_monthly$ds22007 %>%
  filter(Exploratory == "ALB") %>%
  # Keep only relevant columns
  dplyr::select(Exploratory, Family, year, month, NumberAdults_detrended) %>%
  # Initialize NumberAdults as NA
  mutate(NumberAdults = NA) %>%
  # Arrange columns
  dplyr::select(Exploratory, month, year, Family, NumberAdults, NumberAdults_detrended)

# Optional: remove duplicates
new_insects <- new_insects %>% distinct()

# ---------------------------------------------
# 4) Merge into target
# ---------------------------------------------
target$ds22007 <- merge_monthly_insects(
  old = target$ds22007,
  new = new_insects
)

# ---------------------------------------------
# 5) Check results
# ---------------------------------------------
cat("Old dataset rows:", nrow(ds22007_monthly_ALB$ds22007), "\n")
cat("Rows after merge:", nrow(target$ds22007), "\n")

# Show newly added rows
dplyr::anti_join(target$ds22007, ds22007_monthly_ALB$ds22007,
                 by = c("Exploratory","Family","year","month"))

ds22007_monthly_ALB <- target 

################## DIFFED #############################################

# ---------------------------------------------
# 1) Helper function: merge diffed insect data
# ---------------------------------------------
merge_diffed_insects <- function(old, new) {
  key_cols <- c("Exploratory", "Family", "year", "month", "NumberAdults_diffed") 
  
  if (!all(key_cols %in% names(old)) | !all(key_cols %in% names(new))) {
    stop("❌ Key columns missing in old or new dataset!")
  }
  
  # Keep only new rows
  new_only <- dplyr::anti_join(new, old, by = key_cols)
  message("➕ Added new rows: ", nrow(new_only))
  
  out <- dplyr::bind_rows(old, new_only) %>%
    dplyr::distinct() %>%
    dplyr::arrange(Exploratory, Family, year, month)
  
  return(out)
}

# ---------------------------------------------
# 2) Set target for diffed
# ---------------------------------------------
target_diffed <- ds22007_monthly_ALB  # same structure as before

# ---------------------------------------------
# 3) Add weather data
# ---------------------------------------------
if ("weather" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  new_weather <- filtered_ds22007_diffed_monthly_safe$weather %>%
    filter(region == "ALB")
  
  target_diffed$weather <- bind_rows(target_diffed$weather, new_weather) %>%
    dplyr::distinct() %>%
    dplyr::arrange(year, month)
}

# ---------------------------------------------
# 4) Add ds22007 diffed data
# ---------------------------------------------
if ("ds22007" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  
  # 4a. Create NumberAdults_diffed column if missing
  if(!"NumberAdults_diffed" %in% names(target_diffed$ds22007)) {
    target_diffed$ds22007 <- target_diffed$ds22007 %>%
      dplyr::mutate(NumberAdults_diffed = NA_real_)
  }
  
  # 4b. Prepare new insect rows
  new_insects <- filtered_ds22007_diffed_monthly_safe$ds22007 %>%
    dplyr::filter(Exploratory == "ALB") %>%
    dplyr::mutate(NumberAdults_diffed = NumberAdults) %>%
    dplyr::transmute(
      Exploratory,
      month,
      year,
      Family,
      NumberAdults = NA_real_,
      NumberAdults_detrended = NA_real_,
      NumberAdults_diffed
    )
  
  # 4c. Merge only new rows
  target_diffed$ds22007 <- merge_diffed_insects(
    old = target_diffed$ds22007,
    new = new_insects
  )
}

# ---------------------------------------------
# 5) Check results
# ---------------------------------------------
cat("Weather rows:", nrow(target_diffed$weather), "\n")
cat("ds22007 rows:", nrow(target_diffed$ds22007), "\n")

# ---------------------------------------------
# 6) Save result
# ---------------------------------------------
ds22007_monthly_ALB <- target_diffed


#################### DIFFED_DETRENDED ##########################################
str(filtered_ds22007_monthly_diffed_detrended)
# No diffed_detrended data to add for ALB

# ---------------------------------------------
# Check and remove invalid weather rows
# ---------------------------------------------
ds22007_monthly_ALB$weather <- ds22007_monthly_ALB$weather %>%
  filter(
    !is.na(year),
    !is.na(month)
  )

############################# HAI ##############################################
######################### DETRENDED ###########################################
str(filtered_ds22007_detrended_monthly)

# Aggregate ds22007 counts for HAI by site, month, year, and family
ds22007_monthly_HAI$ds22007 <- group_by(
  ds22007_monthly_HAI$ds22007,
  Exploratory, month, year, Family
) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")

ds22007_monthly_HAI$ds22007$month <- as.numeric(ds22007_monthly_HAI$ds22007$month)


#################### REMOVE DUPLICATES #############################
# Keep only HAI
detrended_hai <- filtered_ds22007_detrended_monthly$ds22007 %>%
  filter(Exploratory == "HAI")

# Identify duplicated rows
detrended_hai[duplicated(detrended_hai), ]

# ---------------------------------------------
# 1) Helper function: merge monthly insect data
# ---------------------------------------------
merge_monthly_insects <- function(old, new) {
  
  key_cols <- c("Exploratory", "Family", "year", "month")
  
  # Ensure key columns exist
  if (!all(key_cols %in% names(old)) | !all(key_cols %in% names(new))) {
    stop("❌ Key columns missing in old or new dataset!")
  }
  
  # Keep only new rows
  new_only <- dplyr::anti_join(new, old, by = key_cols)
  
  if (nrow(new_only) == 0) {
    message("ℹ No new monthly ds22007 rows to add.")
    return(old)
  }
  
  message("➕ Added new rows: ", nrow(new_only))
  
  out <- dplyr::bind_rows(old, new_only) %>%
    dplyr::distinct() %>%
    dplyr::arrange(Exploratory, Family, year, month)
  
  return(out)
}

# ---------------------------------------------
# 2) Set target
# ---------------------------------------------
target <- ds22007_monthly_HAI

# ---------------------------------------------
# 3) Extract new HAI rows
# ---------------------------------------------
new_insects <- filtered_ds22007_detrended_monthly$ds22007 %>%
  filter(Exploratory == "HAI") %>%
  # Keep only relevant columns
  dplyr::select(Exploratory, Family, year, month, NumberAdults_detrended) %>%
  # Initialize NumberAdults as NA
  mutate(NumberAdults = NA) %>%
  # Reorder columns
  dplyr::select(Exploratory, month, year, Family, NumberAdults, NumberAdults_detrended)

# Optional: remove duplicates
new_insects <- new_insects %>% distinct()

# ---------------------------------------------
# 4) Merge into target
# ---------------------------------------------
target$ds22007 <- merge_monthly_insects(
  old = target$ds22007,
  new = new_insects
)

# ---------------------------------------------
# 5) Check results
# ---------------------------------------------
cat("Old dataset rows:", nrow(ds22007_monthly_HAI$ds22007), "\n")
cat("Rows after merge:", nrow(target$ds22007), "\n")

# Show newly added rows
dplyr::anti_join(target$ds22007, ds22007_monthly_HAI$ds22007,
                 by = c("Exploratory","Family","year","month"))

# Update target
ds22007_monthly_HAI <- target 

######################### DIFFED ##############################################
str(filtered_ds22007_diffed_monthly_safe)

# ---------------------------------------------
# 1) Helper function: merge diffed insect data
# ---------------------------------------------
merge_diffed_insects <- function(old, new) {
  # Key columns to identify new rows
  key_cols <- c("Exploratory", "Family", "year", "month", "NumberAdults_diffed")
  
  if (!all(key_cols %in% names(old)) | !all(key_cols %in% names(new))) {
    stop("❌ Key columns missing in old or new dataset!")
  }
  
  # Keep only rows not yet present
  new_only <- anti_join(new, old, by = key_cols)
  message("➕ Added new rows: ", nrow(new_only))
  
  out <- bind_rows(old, new_only) %>%
    arrange(Exploratory, Family, year, month)
  
  return(out)
}

# ---------------------------------------------
# 2) Set target for diffed
# ---------------------------------------------
target_diffed <- ds22007_monthly_HAI  # same structure as before

# ---------------------------------------------
# 3) Add weather data
# ---------------------------------------------
if ("weather" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  new_weather <- filtered_ds22007_diffed_monthly_safe$weather %>%
    filter(region == "HAI")
  
  target_diffed$weather <- bind_rows(target_diffed$weather, new_weather) %>%
    distinct() %>%
    arrange(year, month)
}

# ---------------------------------------------
# 4) Add ds22007 diffed data
# ---------------------------------------------
if ("ds22007" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  
  # 4a. Create NumberAdults_diffed column if missing
  if(!"NumberAdults_diffed" %in% names(target_diffed$ds22007)) {
    target_diffed$ds22007 <- target_diffed$ds22007 %>%
      mutate(NumberAdults_diffed = NA_real_)
  }
  
  # 4b. Prepare new insect rows
  new_insects <- filtered_ds22007_diffed_monthly_safe$ds22007 %>%
    filter(Exploratory == "HAI") %>%
    mutate(NumberAdults_diffed = NumberAdults) %>%  # actual values from source
    transmute(
      Exploratory,
      month,
      year,
      Family,
      NumberAdults = NA_real_,
      NumberAdults_detrended = NA_real_,
      NumberAdults_diffed
    )
  
  # 4c. Merge only new rows
  target_diffed$ds22007 <- merge_diffed_insects(
    old = target_diffed$ds22007,
    new = new_insects
  )
}

# ---------------------------------------------
# 5) Check results
# ---------------------------------------------
cat("SMI_upsoil rows:", nrow(target_diffed$SMI_upsoil), "\n")
cat("Weather rows:", nrow(target_diffed$weather), "\n")
cat("ds22007 rows:", nrow(target_diffed$ds22007), "\n")

# Update target
ds22007_monthly_HAI <- target_diffed

# ---------------------------------------------
# 6) Add SMI_total
# ---------------------------------------------
# SMI_total must be added completely new
smi_hai <- filtered_ds22007_diffed_monthly_safe$SMI_total %>%
  dplyr::select(month, year, HAI) 

# Add to list as new element
ds22007_monthly_HAI$SMI_total <- smi_hai

# ---------------------------------------------
# Check and remove invalid weather rows
# ---------------------------------------------
ds22007_monthly_HAI$weather <- ds22007_monthly_HAI$weather %>%
  filter(
    !is.na(year),
    !is.na(month)
  )


######################### DIFFED_DETRENDED #####################################
# No diffed_detrended data available for HAI

############################ SCH ###############################################
########################## DETRENDED MERGE #####################################
ds22007_monthly_SCH$ds22007 <- group_by(ds22007_monthly_SCH$ds22007, Exploratory, month, year, Family) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")
ds22007_monthly_SCH$ds22007$month <- as.numeric(ds22007_monthly_SCH$ds22007$month)

#################### REMOVE DUPLICATES #############################
# Keep only SCH
detrended_SCH <- filtered_ds22007_detrended_monthly$ds22007 %>%
  filter(Exploratory == "SCH")

# Identify duplicated rows
detrended_SCH[duplicated(detrended_SCH), ]

# ---------------------------------------------
# 1) Set new target
# ---------------------------------------------
target <- ds22007_monthly_SCH

# ---------------------------------------------
# 2) Extract new SCH rows from detrended
# ---------------------------------------------
new_insects <- detrended_SCH %>%
  filter(Exploratory == "SCH") %>%
  dplyr::select(Exploratory, Family, year, month, NumberAdults_detrended) %>%
  mutate(NumberAdults = NA) %>%
  dplyr::select(Exploratory, month, year, Family, NumberAdults, NumberAdults_detrended) %>%
  distinct()

# ---------------------------------------------
# 3) Merge into target
# ---------------------------------------------
target$ds22007 <- merge_monthly_insects(
  old = target$ds22007,
  new = new_insects
)

# ---------------------------------------------
# 4) Check results
# ---------------------------------------------
cat("Old dataset rows:", nrow(ds22007_monthly_SCH$ds22007), "\n")
cat("Rows after merge:", nrow(target$ds22007), "\n")

# Show newly added rows
dplyr::anti_join(target$ds22007, ds22007_monthly_SCH$ds22007,
                 by = c("Exploratory","Family","year","month"))

# Update target
ds22007_monthly_SCH <- target 

######################## DIFFED ##################################

# ---------------------------------------------
# 1) Helper function for diffed merge
# ---------------------------------------------
merge_diffed_insects <- function(old, new) {
  key_cols <- c("Exploratory", "Family", "year", "month", "NumberAdults_diffed")
  
  if (!all(key_cols %in% names(old)) | !all(key_cols %in% names(new))) {
    stop("❌ Key columns missing in old or new dataset!")
  }
  
  # Keep only new rows
  new_only <- dplyr::anti_join(new, old, by = key_cols)
  message("➕ Added new rows: ", nrow(new_only))
  
  out <- dplyr::bind_rows(old, new_only) %>%
    dplyr::distinct() %>%
    dplyr::arrange(Exploratory, Family, year, month)
  
  return(out)
}

# ---------------------------------------------
# 2) Set target for diffed
# ---------------------------------------------
target_diffed <- ds22007_monthly_SCH  # same structure as before

# ---------------------------------------------
# 3) Add weather data
# ---------------------------------------------
if ("weather" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  new_weather <- filtered_ds22007_diffed_monthly_safe$weather %>%
    dplyr::filter(region == "SCH")
  
  target_diffed$weather <- dplyr::bind_rows(target_diffed$weather, new_weather) %>%
    dplyr::distinct() %>%
    dplyr::arrange(year, month)
}

# ---------------------------------------------
# 4) Add ds22007 diffed data
# ---------------------------------------------
if ("ds22007" %in% names(filtered_ds22007_diffed_monthly_safe)) {
  
  # 4a. Create NumberAdults_diffed column if missing
  if(!"NumberAdults_diffed" %in% names(target_diffed$ds22007)) {
    target_diffed$ds22007 <- target_diffed$ds22007 %>%
      dplyr::mutate(NumberAdults_diffed = NA_real_)
  }
  
  # 4b. Prepare new insect rows
  new_insects <- filtered_ds22007_diffed_monthly_safe$ds22007 %>%
    dplyr::filter(Exploratory == "SCH") %>%
    dplyr::mutate(NumberAdults_diffed = NumberAdults) %>% 
    dplyr::transmute(
      Exploratory,
      month,
      year,
      Family,
      NumberAdults = NA_real_,
      NumberAdults_detrended = NA_real_,
      NumberAdults_diffed
    )
  
  # 4c. Merge only new rows
  target_diffed$ds22007 <- merge_diffed_insects(
    old = target_diffed$ds22007,
    new = new_insects
  )
}

# ---------------------------------------------
# 5) Check results
# ---------------------------------------------
cat("SMI_upsoil rows:", nrow(target_diffed$SMI_upsoil), "\n")
cat("Weather rows:", nrow(target_diffed$weather), "\n")
cat("ds22007 rows:", nrow(target_diffed$ds22007), "\n")

# ---------------------------------------------
# 6) Save final target
# ---------------------------------------------
ds22007_monthly_SCH <- target_diffed

################### DIFFED_DETRENDED ##############################
str(filtered_ds22007_monthly_diffed_detrended)

############################################
# SMI_total (diffed + detrended) for SCH
############################################
# Create new element
smi_sch <- filtered_ds22007_monthly_diffed_detrended$SMI_total %>%
  dplyr::select(month, year, SCH) 

# Add to list as new element
ds22007_monthly_SCH$SMI_total <- smi_sch

# ---------------------------------------------
# Check and remove invalid weather rows
# ---------------------------------------------
ds22007_monthly_SCH$weather <- ds22007_monthly_SCH$weather %>%
  filter(
    !is.na(year),
    !is.na(month)
  )

############################# GRANGER TEST ##############################
########################## DS22007_ALB_MONTHLY ##########################

# -----------------------------
# List of insect families & lags (months)
# -----------------------------
families <- unique(ds22007_monthly_ALB$ds22007$Family)
lags <- 1:3   # 1–3 months

# -----------------------------
# Function to get insect time series for a family (monthly)
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_ALB$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = coalesce(
        NumberAdults_detrended,
        NumberAdults,
        NumberAdults_diffed
      )
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Align insect and environmental time series by month + year
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e)
        tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
      )
    }
  })
}

# -----------------------------
# 1. SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_ALB$SMI_upsoil, "ALB")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "ALB",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn,
                  Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn,
                    Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(
  ds22007_monthly_ALB$NDVI, "NDVI", "mean_NDVI"
)

results_ndmi <- run_granger_env_vars_monthly(
  ds22007_monthly_ALB$NDMI, "NDMI", "mean_NDMI"
)

results_nirv <- run_granger_env_vars_monthly(
  ds22007_monthly_ALB$NIRv, "NIRv", "mean_NIRv"
)

# -----------------------------
# 4. Weather variables (all columns except year, month, region)
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>%
    dplyr::select(-year, -month, -region) %>%
    names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn,
                      Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(
  ds22007_monthly_ALB$weather,
  "weather"
)

# -----------------------------
# 5. Combine all results
# -----------------------------
results_ALB_monthly <- bind_rows(
  results_smi_upsoil,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 6. Add causality label
# -----------------------------
results_ALB_monthly <- results_ALB_monthly %>%
  mutate(
    causality = ifelse(
      is.na(p_value), "no_test",
      ifelse(p_value < 0.05, "causal", "non-causal")
    )
  ) %>%
  filter(!is.na(Family))

# -----------------------------
# 7. Export results
# -----------------------------
write.csv(
  results_ALB_monthly,
  "./tables/granger_test/results_ds22007_ALB_monthly_2nd_round.csv",
  row.names = FALSE
)

table(results_ALB_monthly$causality)

############################# GRANGER TEST ##############################
########################## DS22007_HAI_MONTHLY ##########################

# -----------------------------
# List of insect families & lags (months)
# -----------------------------
families <- unique(ds22007_monthly_HAI$ds22007$Family)
lags <- 1:3

# -----------------------------
# Function to get insect time series for a family (monthly)
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_HAI$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = coalesce(
        NumberAdults_detrended,
        NumberAdults,
        NumberAdults_diffed
      )
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Align insect and environmental time series by month + year
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_HAI$SMI_upsoil, "HAI")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "HAI",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_HAI$SMI_total, "HAI")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "HAI",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NDVI, "NDVI", "mean_NDVI")
results_ndmi <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NDMI, "NDMI", "mean_NDMI")
results_nirv <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 4. Weather variables
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -month, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(ds22007_monthly_HAI$weather, "weather")

# -----------------------------
# 5. Combine all results
# -----------------------------
results_HAI_monthly <- bind_rows(
  results_smi_upsoil,
  results_smi_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 6. Add causality label
# -----------------------------
results_HAI_monthly <- results_HAI_monthly %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  ) %>%
  filter(!is.na(Family))

results_HAI_monthly

# -----------------------------
# 7. Export results
# -----------------------------
write.csv(
  results_HAI_monthly,
  "./tables/granger_test/results_ds22007_HAI_monthly_2nd_round.csv",
  row.names = FALSE
)


############################# GRANGER TEST ##############################
########################## DS22007_SCH_MONTHLY ##########################

# -----------------------------
# List of insect families & lags (months)
# -----------------------------
families <- unique(ds22007_monthly_SCH$ds22007$Family)
lags <- 1:3

# -----------------------------
# Function to get insect time series for a family (monthly)
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_SCH$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = coalesce(
        NumberAdults_detrended,
        NumberAdults,
        NumberAdults_diffed
      )
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Align insect and environmental time series by month + year
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 1. SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_SCH$SMI_total, "SCH")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "SCH",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 2. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(ds22007_monthly_SCH$NDVI, "NDVI", "mean_NDVI")
results_ndmi <- run_granger_env_vars_monthly(ds22007_monthly_SCH$NDMI, "NDMI", "mean_NDMI")
results_nirv <- run_granger_env_vars_monthly(ds22007_monthly_SCH$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 3. Weather variables
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -month, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(ds22007_monthly_SCH$weather, "weather")

# -----------------------------
# 4. Combine all results
# -----------------------------
results_SCH_monthly <- bind_rows(
  results_smi_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 5. Add causality label
# -----------------------------
results_SCH_monthly <- results_SCH_monthly %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  ) %>%
  filter(!is.na(Family))

table(results_SCH_monthly$causality)

# -----------------------------
# 6. Export results
# -----------------------------
write.csv(
  results_SCH_monthly,
  "./tables/granger_test/results_ds22007_SCH_monthly_2nd_round.csv",
  row.names = FALSE
)
