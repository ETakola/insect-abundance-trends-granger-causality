########################## SECOND ROUND GRANGER ###############################
# Perform Granger tests on detrended and/or differenced data (stationary series):
# 1. Use outputs from the detrending scripts
# 2. Apply Granger tests on all stationary insect time series combined
setwd("D:/Masterarbeit/Upload")
################### load packages ###########################
library(lmtest)
library(tidyverse)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # stationarity tests

#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 

# Helper function to decode CollectionRun letters to numeric months
decode_collection_run <- function(run_letter){
  # Mapping: A = April (4) to G = October (10)
  mapvals <- setNames(4:10, LETTERS[1:7])
  as.numeric(mapvals[run_letter])  # Returns NA if letter is not in mapping
}

# Load insect dataset ds22007 and convert CollectionRun to month
ds22007 <- read_csv("./data/insects/ds22007.csv") %>%
  mutate(
    run_letter = str_sub(CollectionRun, 1, 1),  # Extract first character
    month = decode_collection_run(run_letter),  # Convert letter to numeric month
    month = ifelse(!is.na(month), sprintf("%02d", month), NA_character_),  # Optional: format as two-digit string
    year = as.numeric(CollectionYear)  # Convert year to numeric
  ) %>%
  dplyr::select(-run_letter)  # Remove temporary variable
##### stationarity tables from first Granger round #####

# Combined ADF/KPSS results

stationarity_table_ds22007_monthly <- read.csv("./tables/stationarity_test/combined_stationarity_ds22007_monthly.csv", sep=",") %>% filter(status_adf == "stationary", status_kpss == "stationary")

##### stationary datasets after detrending/differencing #####

# ds22007 monthly
ds22007_both_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_both_monthly.csv", sep=",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_detrended_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_detrended_monthly.csv", sep=",") %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds22007_differenced_monthly <- read.csv("./tables/detrend_diff_stationarity/stationarity_table_ds22007_diff_monthly.csv", sep=",") %>%
  filter(adf_status == "stationary", kpss_status == "stationary")

############################## data list for unified handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  weather = weather,
  ds22007 = ds22007
)


################################################################################
###################### MONTHLY AGGREGATION SCRIPT ##############################
################################################################################

# - Only datasets with monthly resolution (excluding Fertilization & mosaic)
# - Time period and months aligned with ds22007
# - Only months April–October (4–10)

# ------------------------------------------------------------------------------
# 1 Determine time span and month range of ds22007
# ------------------------------------------------------------------------------
months_ds22007 <- sort(unique(ds22007$month))
years_ds22007 <- range(ds22007$year, na.rm = TRUE)

cat("Months in ds22007:", paste(months_ds22007, collapse = ", "), "\n")
cat("Year range ds22007:", paste(years_ds22007, collapse = " - "), "\n")

# ------------------------------------------------------------------------------
# 2 Remove datasets without monthly resolution
# ------------------------------------------------------------------------------
monthly_datasets <- data_list[!names(data_list) %in% c("Fertilization", "mosaic", "ds22007")]

# ------------------------------------------------------------------------------
# 3 Filtering function for target months (April–October)
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range) {
  if (!all(c("year", "month") %in% names(df))) return(df) # skip datasets without monthly information
  df %>%
    filter(
      month %in% 4:10,
      year >= year_range[1],
      year <= year_range[2]
    )
}

# ------------------------------------------------------------------------------
# 4 Apply filtering for ds22007 time span (monthly datasets only)
# ------------------------------------------------------------------------------
data_for_ds22007_monthly <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds22007)
})

# ------------------------------------------------------------------------------
# 5 Re-add insect dataset without modification
# ------------------------------------------------------------------------------
data_for_ds22007_monthly$ds22007 <- ds22007
data_for_ds22007_monthly$ds22007 <- group_by(
  data_for_ds22007_monthly$ds22007,
  Exploratory, month, year, Family
) %>%
  summarise(NumberAdults = sum(NumberAdults, na.rm = TRUE), .groups = "drop")

################################################################################
# Special handling for Weather (monthly aggregation by region) for ds22007
################################################################################

aggregate_weather_monthly <- function(weather_df) {
  
  if(is.null(weather_df) || nrow(weather_df) == 0){
    message("⚠ Weather dataset empty → returning NULL")
    return(NULL)
  }
  
  # Create month_num if it doesn't exist
  if(!"month_num" %in% names(weather_df)){
    weather_df <- weather_df %>%
      mutate(month_num = as.numeric(month))
  }
  
  # numeric columns to aggregate (exclude time and grouping columns)
  numeric_weather_cols <- weather_df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::select(-year, -month, -month_num) %>%
    names()
  
  if(length(numeric_weather_cols) == 0){
    message("⚠ Weather dataset has no numeric columns → returning as-is")
    return(weather_df)
  }
  
  # aggregate by region, year, month_num
  weather_df %>%
    dplyr::group_by(region, year, month_num) %>%
    dplyr::summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    dplyr::rename(month = month_num)
}

# Apply aggregation to ds22007 weather
if("weather" %in% names(data_for_ds22007_monthly)){
  data_for_ds22007_monthly$weather <- aggregate_weather_monthly(
    data_for_ds22007_monthly$weather
  )
}

cat(" ds22007 weather aggregated by region, year, month\n")


########################### DS22007 ##############################################
########################### DETREND DS22007 MONTHLY ##############################
##############################
# Initialize list for stationary monthly data
##############################
data_for_ds22007_stationary_monthly <- list()

# -----------------------------
# Function: Detrend monthly series
# -----------------------------
detrend_ts <- function(df, cols) {
  for (col in cols) {
    if(col %in% names(df)){
      fit <- stats::lm(df[[col]] ~ df$year + df$month) #consider month
      df[[col]] <- df[[col]] - fit$fitted.values
    }
  }
  df
}

# -----------------------------
# Function: Difference monthly series
# -----------------------------
diff_ts <- function(df, cols) {
  for(col in cols){
    if(col %in% names(df)){
      df[[col]] <- c(NA, diff(df[[col]]))
    }
  }
  df
}

# -----------------------------
# Function: Detrend + Difference monthly series
# -----------------------------
detrend_diff_ts <- function(df, cols) {
  for(col in cols){
    if(col %in% names(df)){
      fit <- stats::lm(df[[col]] ~ df$year + df$month)
      detrended <- df[[col]] - fit$fitted.values
      df[[col]] <- c(NA, diff(detrended))
    }
  }
  df
}

# --- SMI_total ---
# Stationary Variablen SMI_total
vars_stationary <- stationarity_table_ds22007_monthly %>%
  filter(dataset == "SMI_total") %>%
  pull(variable) %>%
  unique()

# Detrended Variablen SMI_total
vars_detrended <- ds22007_detrended_monthly %>%
  filter(dataset == "SMI_total") %>%
  pull(variable) %>%
  unique()

# Differenced Variablen SMI_total
vars_diff <- ds22007_differenced_monthly %>%
  filter(dataset == "SMI_total") %>%
  pull(variable) %>%
  unique()

# Both (Detrended + Differenced)
vars_both <- ds22007_both_monthly %>%
  filter(dataset == "SMI_total") %>%
  pull(variable) %>%
  unique()

df <- data_for_ds22007_monthly$SMI_total


# 1. Stationary – no change
SMI_total_stationary <- df %>%
  dplyr::select(year, month, day, any_of(vars_stationary))

# 2. Detrended
SMI_total_detrended <- detrend_ts(df, vars_detrended) %>%
  dplyr::select(year, month, day, any_of(vars_detrended))

# 3. Differenced
SMI_total_diff <- diff_ts(df, vars_diff) %>%
  dplyr::select(year, month, day, any_of(vars_diff))

# 4. Both
SMI_total_both <- detrend_diff_ts(df, vars_both) %>%
  dplyr::select(year, month, day, any_of(vars_both))

data_for_ds22007_stationary_monthly$SMI_total <- bind_rows(
  SMI_total_stationary,
  SMI_total_detrended,
  SMI_total_diff,
  SMI_total_both
) %>%
  arrange(year, month)

data_for_ds22007_stationary_monthly$SMI_total <- data_for_ds22007_stationary_monthly$SMI_total %>%
  filter(!(is.na(ALB) & is.na(HAI) & is.na(SCH)))

# --- SMI_upsoil ---
vars_smi_upsoil <- stationarity_table_ds22007_monthly %>% 
  filter(dataset == "SMI_upsoil") %>% 
  pull(variable) %>% unique()

df_smi_upsoil <- data_for_ds22007_monthly$SMI_upsoil %>%
  select(time, month, year, any_of(vars_smi_upsoil))

data_for_ds22007_stationary_monthly$SMI_upsoil <- df_smi_upsoil

####NDVI/NIRv/NDMI
# Function to select stationary monthly variables
data_for_ds22007_stationary_monthly$NDVI_ALB <- data_for_ds22007_monthly$NDVI_ALB
data_for_ds22007_stationary_monthly$NDVI_HAI <- data_for_ds22007_monthly$NDVI_HAI
data_for_ds22007_stationary_monthly$NDVI_SCH <- data_for_ds22007_monthly$NDVI_SCH

data_for_ds22007_stationary_monthly$NDMI_ALB <- data_for_ds22007_monthly$NDMI_ALB
data_for_ds22007_stationary_monthly$NDMI_HAI <- data_for_ds22007_monthly$NDMI_HAI
data_for_ds22007_stationary_monthly$NDMI_SCH <- data_for_ds22007_monthly$NDMI_SCH

data_for_ds22007_stationary_monthly$NIRv_ALB <- data_for_ds22007_monthly$NIRv_ALB
data_for_ds22007_stationary_monthly$NIRv_HAI <- data_for_ds22007_monthly$NIRv_HAI
data_for_ds22007_stationary_monthly$NIRv_SCH <- data_for_ds22007_monthly$NIRv_SCH

# Filter stationäre Variablen
stationary_weather <- stationarity_table_ds22007_monthly %>%
  filter(dataset == "weather", status_adf == "stationary", status_kpss == "stationary") %>%
  select(variable, region)

differenced_weather <- ds22007_differenced_monthly %>%
  filter(dataset == "weather") %>%
  select(variable, region)

weather_raw <- data_for_ds22007_monthly$weather

# Stationär: long -> filter -> wide
weather_stationary <- weather_raw %>%
  pivot_longer(cols = -c(year, month, region), names_to = "variable", values_to = "value") %>%
  semi_join(stationary_weather, by = c("variable", "region")) %>%
  pivot_wider(names_from = "variable", values_from = "value")

# Differenced: long -> filter -> wide -> diff_ts
weather_diff <- weather_raw %>%
  pivot_longer(cols = -c(year, month, region), names_to = "variable", values_to = "value") %>%
  semi_join(differenced_weather, by = c("variable", "region")) %>%
  pivot_wider(names_from = "variable", values_from = "value") %>%
  group_by(region) %>%
  arrange(year, month) %>%
  group_modify(~ diff_ts(.x, cols = setdiff(names(.x), c("year", "month", "region")))) %>%
  ungroup()

# Zusammenführen
weather_final <- bind_rows(weather_stationary, weather_diff) %>%
  arrange(region, year, month)

data_for_ds22007_stationary_monthly$weather <- weather_final

# Fertilization 
# Stationary bleibt unverändert
subset_stationary <- semi_join(
  data_for_ds22007_monthly$ds22007,
  stationarity_table_ds22007_monthly %>% filter(dataset == "ds22007", variable == "NumberAdults"),
  by = c("Exploratory", "Family")
)

# Differenced
subset_diff <- semi_join(
  data_for_ds22007_monthly$ds22007,
  ds22007_differenced_monthly %>% filter(dataset == "ds22007", variable == "NumberAdults"),
  by = c("Exploratory", "Family")
)
if(nrow(subset_diff) > 0){
  subset_diff <- diff_ts(subset_diff, cols = "NumberAdults")
}

# Detrended
subset_detrended <- semi_join(
  data_for_ds22007_monthly$ds22007,
  ds22007_detrended_monthly %>% filter(dataset == "ds22007", variable == "NumberAdults"),
  by = c("Exploratory", "Family")
)
if(nrow(subset_detrended) > 0){
  subset_detrended <- detrend_ts(subset_detrended, cols = "NumberAdults")
}

# Zusammenführen
data_for_ds22007_stationary_monthly$ds22007 <- bind_rows(
  subset_stationary, subset_detrended, subset_diff
) %>%
  arrange(Exploratory, Family, year, month) %>%
  mutate(Priority = NA)

####################Seperate in Regions###############################
####################### ALB ##########################################
# 1. SMI 
smi_upsoil_alb <- data_for_ds22007_stationary_monthly$SMI_upsoil %>% dplyr::select(month, year, ALB)
smi_total_alb <- data_for_ds22007_stationary_monthly$SMI_total %>% dplyr::select(month, year, ALB)

# 2. NDVI, NDMI, NIRv
ndvi_alb <- data_for_ds22007_stationary_monthly$NDVI_ALB
ndmi_alb <- data_for_ds22007_stationary_monthly$NDMI_ALB
nirv_alb <- data_for_ds22007_stationary_monthly$NIRv_ALB

# 4. Weather
weather_alb <- data_for_ds22007_stationary_monthly$weather %>% filter(region == "ALB")

# 5. ds22007 für ALB
ds22007_alb <- data_for_ds22007_stationary_monthly$ds22007 %>% filter(Exploratory == "ALB")

# 6. Sub-Liste erstellen
ds22007_monthly_ALB <- list(
  SMI_upsoil = smi_upsoil_alb,
  SMI_total = smi_total_alb,
  NDVI = ndvi_alb,
  NDMI = ndmi_alb,
  NIRv = nirv_alb,
  weather = weather_alb,
  ds22007 = ds22007_alb
)

#################### HAI ##########################################
# 1. SMI_upsoil
smi_hai <- data_for_ds22007_stationary_monthly$SMI_upsoil %>% dplyr::select(month, year, HAI)
smi_total_hai <- data_for_ds22007_stationary_monthly$SMI_total %>% dplyr::select(month, year, HAI)

# 2. NDVI, NDMI, NIRv
ndvi_hai <- data_for_ds22007_stationary_monthly$NDVI_HAI
ndmi_hai <- data_for_ds22007_stationary_monthly$NDMI_HAI
nirv_hai <- data_for_ds22007_stationary_monthly$NIRv_HAI

# 3. Weather
weather_hai <- data_for_ds22007_stationary_monthly$weather %>% filter(region == "HAI")

# 4. ds22007
ds22007_hai <- data_for_ds22007_stationary_monthly$ds22007 %>% filter(Exploratory == "HAI")

# 5. Sub-Liste erstellen
ds22007_monthly_HAI <- list(
  SMI_upsoil = smi_hai,
  SMI_total = smi_total_hai,
  NDVI = ndvi_hai,
  NDMI = ndmi_hai,
  NIRv = nirv_hai,
  weather = weather_hai,
  ds22007 = ds22007_hai
)

#################### SCH ##########################################
# 1. SMI_upsoil
smi_upsoil_sch <- data_for_ds22007_stationary_monthly$SMI_upsoil %>% dplyr::select(month, year, SCH)
smi_total_sch <- data_for_ds22007_stationary_monthly$SMI_total %>% dplyr::select(month, year, SCH)

# 2. NDVI, NDMI, NIRv
ndvi_sch <- data_for_ds22007_stationary_monthly$NDVI_SCH
ndmi_sch <- data_for_ds22007_stationary_monthly$NDMI_SCH
nirv_sch <- data_for_ds22007_stationary_monthly$NIRv_SCH

# 3. Weather
weather_sch <- data_for_ds22007_stationary_monthly$weather %>% filter(region == "SCH")

# 4. ds22007
ds22007_sch <- data_for_ds22007_stationary_monthly$ds22007 %>% filter(Exploratory == "SCH")

# 5. Sub-Liste erstellen
ds22007_monthly_SCH <- list(
  SMI_upsoil = smi_upsoil_sch,
  SMI_total = smi_total_sch, 
  NDVI = ndvi_sch,
  NDMI = ndmi_sch,
  NIRv = nirv_sch,
  weather = weather_sch,
  ds22007 = ds22007_sch
)

############################# GRANGER TEST ##############################
########################## DS22007_ALB_MONTHLY ##########################

# -----------------------------
# 1. Vorbereitung
# -----------------------------
families <- unique(ds22007_monthly_ALB$ds22007$Family)
lags <- 1:3   # 1–3 Monate

# -----------------------------
# Funktion: Insekten-Zeitreihe für Family
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_ALB$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = NumberAdults  # nur NumberAdults
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Funktion: Insekten- und Umweltzeitreihe nach Jahr+Monat ausrichten
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  insect_df <- insect_df %>%
    mutate(month = as.integer(month))  # Monat auf integer
  
  env_df <- env_df %>%
    mutate(month = as.integer(month))  # Monat auf integer
  
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Funktion: sicherer Granger-Test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e)
        tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
      )
    }
  })
}

# -----------------------------
# 2. SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_ALB$SMI_total, "ALB")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "ALB",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_ALB$SMI_upsoil, "ALB")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "ALB",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 4. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(ds22007_monthly_ALB$NDVI, "NDVI", "mean_NDVI")
results_ndmi <- run_granger_env_vars_monthly(ds22007_monthly_ALB$NDMI, "NDMI", "mean_NDMI")
results_nirv <- run_granger_env_vars_monthly(ds22007_monthly_ALB$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 5. Wettervariablen
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>%
    dplyr::select(-year, -month, -region) %>%
    names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(ds22007_monthly_ALB$weather, "weather")

# -----------------------------
# 6. Alle Ergebnisse kombinieren
# -----------------------------
results_ALB_monthly <- bind_rows(
  results_smi_upsoil,
  results_smi_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 7. Kausalität kennzeichnen
# -----------------------------
results_ALB_monthly <- results_ALB_monthly %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  ) %>%
  filter(!is.na(Family))

# -----------------------------
# 8. Export
# -----------------------------
write.csv(
  results_ALB_monthly,
  "./tables/granger_test/results_ds22007_ALB_monthly_2nd_round.csv",
  row.names = FALSE
)


#############################
# GRANGER TEST DS22007_HAI_MONTHLY
#############################

# -----------------------------
# 1. Vorbereitung
# -----------------------------
families <- unique(ds22007_monthly_HAI$ds22007$Family)
lags <- 1:3  # 1–3 Monate

# -----------------------------
# Funktion: Insekten-Zeitreihe für Family
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_HAI$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = NumberAdults  # nur NumberAdults
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Funktion: Insekten- und Umweltzeitreihe nach Jahr+Monat ausrichten
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  insect_df <- insect_df %>%
    mutate(month = as.integer(month))  # Monat auf integer
  
  env_df <- env_df %>%
    mutate(month = as.integer(month))  # Monat auf integer
  
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Funktion: sicherer Granger-Test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 2. SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_HAI$SMI_upsoil, "HAI")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "HAI",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_HAI$SMI_total, "HAI")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "HAI",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 4. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NDVI, "NDVI", "mean_NDVI")
results_ndmi <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NDMI, "NDMI", "mean_NDMI")
results_nirv <- run_granger_env_vars_monthly(ds22007_monthly_HAI$NIRv, "NIRv", "mean_NIRv")

# -----------------------------
# 5. Wettervariablen
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>% dplyr::select(-year, -month, -region) %>% names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        dplyr::select(Family, EnvDataset, EnvColumn, Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(ds22007_monthly_HAI$weather, "weather")

# -----------------------------
# 6. Alle Ergebnisse kombinieren
# -----------------------------
results_HAI_monthly <- bind_rows(
  results_smi_upsoil,
  results_smi_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 7. Kausalität kennzeichnen
# -----------------------------
results_HAI_monthly <- results_HAI_monthly %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  ) %>%
  filter(!is.na(Family))

# -----------------------------
# 8. Export
# -----------------------------
write.csv(
  results_HAI_monthly,
  "./tables/granger_test/results_ds22007_HAI_monthly_2nd_round.csv",
  row.names = FALSE
)

#############################
# GRANGER TEST DS22007_SCH_MONTHLY
#############################

# -----------------------------
# 1. Vorbereitung
# -----------------------------
families <- unique(ds22007_monthly_SCH$ds22007$Family)
lags <- 1:3  # 1–3 Monate

# -----------------------------
# Funktion: Insekten-Zeitreihe für Family
# -----------------------------
get_insect_ts_df_monthly <- function(fam) {
  ds22007_monthly_SCH$ds22007 %>%
    filter(Family == fam) %>%
    arrange(year, month) %>%
    mutate(
      NumberAdults_use = NumberAdults   # nur NumberAdults
    ) %>%
    dplyr::select(year, month, NumberAdults_use)
}

# -----------------------------
# Funktion: Insekten- & Umweltzeitreihe ausrichten
# -----------------------------
align_ts_month <- function(insect_df, env_df, env_col) {
  insect_df <- insect_df %>%
    mutate(month = as.integer(month))
  
  env_df <- env_df %>%
    mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df,
    dplyr::select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Funktion: sicherer Granger-Test
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if (length(x) < lag + 2 || length(y) < lag + 2 ||
        var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(
          Lag = lag,
          F_stat = res$F[2],
          p_value = res$`Pr(>F)`[2]
        )
      }, error = function(e)
        tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
      )
    }
  })
}

# -----------------------------
# 2. SMI_upsoil
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_SCH$SMI_upsoil, "SCH")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "SCH",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    select(Family, EnvDataset, EnvColumn,
           Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 3. SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_df <- get_insect_ts_df_monthly(fam)
  ts <- align_ts_month(insect_df, ds22007_monthly_SCH$SMI_total, "SCH")
  
  granger_safe(ts$insect, ts$env, lags) %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "SCH",
      Croptype = NA_character_,
      Fertilizer = NA_character_
    ) %>%
    select(Family, EnvDataset, EnvColumn,
           Croptype, Fertilizer, Lag, F_stat, p_value)
})

# -----------------------------
# 4. NDVI / NDMI / NIRv
# -----------------------------
run_granger_env_vars_monthly <- function(env_df, envname, colname) {
  map_dfr(families, function(fam) {
    insect_df <- get_insect_ts_df_monthly(fam)
    ts <- align_ts_month(insect_df, env_df, colname)
    
    granger_safe(ts$insect, ts$env, lags) %>%
      mutate(
        Family = fam,
        EnvDataset = envname,
        EnvColumn = colname,
        Croptype = NA_character_,
        Fertilizer = NA_character_
      ) %>%
      select(Family, EnvDataset, EnvColumn,
             Croptype, Fertilizer, Lag, F_stat, p_value)
  })
}

results_ndvi <- run_granger_env_vars_monthly(
  ds22007_monthly_SCH$NDVI, "NDVI", "mean_NDVI"
)

results_ndmi <- run_granger_env_vars_monthly(
  ds22007_monthly_SCH$NDMI, "NDMI", "mean_NDMI"
)

results_nirv <- run_granger_env_vars_monthly(
  ds22007_monthly_SCH$NIRv, "NIRv", "mean_NIRv"
)

# -----------------------------
# 5. Weather
# -----------------------------
run_granger_weather_monthly <- function(env_df, envname) {
  env_cols <- env_df %>%
    select(-year, -month, -region) %>%
    names()
  
  map_dfr(env_cols, function(colname) {
    map_dfr(families, function(fam) {
      insect_df <- get_insect_ts_df_monthly(fam)
      ts <- align_ts_month(insect_df, env_df, colname)
      
      granger_safe(ts$insect, ts$env, lags) %>%
        mutate(
          Family = fam,
          EnvDataset = envname,
          EnvColumn = colname,
          Croptype = NA_character_,
          Fertilizer = NA_character_
        ) %>%
        select(Family, EnvDataset, EnvColumn,
               Croptype, Fertilizer, Lag, F_stat, p_value)
    })
  })
}

results_weather <- run_granger_weather_monthly(
  ds22007_monthly_SCH$weather, "weather"
)

# -----------------------------
# 6. combine all results
# -----------------------------
results_SCH_monthly <- bind_rows(
  results_smi_upsoil,
  results_smi_total,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# 7. causality 
# -----------------------------
results_SCH_monthly <- results_SCH_monthly %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  ) %>%
  filter(!is.na(Family))

# -----------------------------
# 8. export
# -----------------------------
write.csv(
  results_SCH_monthly,
  "./tables/granger_test/results_ds22007_SCH_monthly_2nd_round.csv",
  row.names = FALSE
)

