########################## 2nd Round Granger ###############################
# Performs Granger tests on detrended and/or differenced data (stationary):
# 1. Uses the lists created in the "detrending/differencing"-scripts
# 2. Performs Granger tests on all stationary insect datasets combined

################### load packages ###########################
library(lmtest)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests


#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 


##### Stationarity tables from first round to build lists #####

stationarity_table_ds21969_ALB_HAI_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv",
  sep =","
)

stationarity_table_ds21969_SCH_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv",
  sep =","
)

##### Combined stationarity tables for detrended/differenced data #####

# ds21969 monthly
ds21969_both_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_detrended_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")

ds21969_differenced_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")


############################## data list for easier handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  weather = weather,
  ds21969 = ds21969
)

##################################################################################
################## Select datasets requiring detrending based on table ##########

ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")


################## select datasets requiring both methods based on tables #################

# monthly
ds21969_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds21969_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1. Determine months and year range
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>%
  mutate(month_num = as.numeric(month))  # numeric month for filtering

years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# ALB & HAI months
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
# SCH months
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

# ------------------------------------------------------------------------------
# 3. Function to filter by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4. Apply filter for ALB & HAI
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(data_list, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets (ds21969 is added separately)
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[
  !names(data_for_ds21969_ALB_HAI) %in% c("ds22007")
]

# Add ds21969 for ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>%
  filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# 5. Apply filter for SCH
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[
  !names(data_for_ds21969_SCH) %in% c("ds22007")
]

# Add ds21969 for SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>%
  filter(Exploratory == "SCH")

# ------------------------------------------------------------------------------
# 6. Special handling for Weather (monthly aggregation by region)
# ------------------------------------------------------------------------------

aggregate_weather_monthly <- function(weather_df) {
  
  numeric_weather_cols <- weather_df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::select(-year, -month, -month_num) %>%
    names()
  
  weather_df %>%
    dplyr::group_by(region, year, month_num) %>%
    dplyr::summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    dplyr::rename(month = month_num)
}

# ---- ALB & HAI ----
if ("weather" %in% names(data_for_ds21969_ALB_HAI)) {
  data_for_ds21969_ALB_HAI$weather <-
    aggregate_weather_monthly(data_for_ds21969_ALB_HAI$weather)
}

# ---- SCH ----
if ("weather" %in% names(data_for_ds21969_SCH)) {
  data_for_ds21969_SCH$weather <-
    aggregate_weather_monthly(data_for_ds21969_SCH$weather)
}


################################################################################
# Result: two lists
# data_for_ds21969_ALB_HAI
# data_for_ds21969_SCH
################################################################################

##############################################################################
################## SELECT ONLY STATIONARY RESULTS FROM TABLE #################
# monthly
ds21969_stationary_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_stationary_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DETRENDING #################
# monthly
ds21969_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds21969_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

################## SELECT DATASETS REQUIRING DIFFERENCING #################
# monthly
ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

########################### DETREND ds21969 MONTHLY ##############################

# -------------------------------------------------------------------
# 1. Linear detrending function (if not already loaded)
# -------------------------------------------------------------------
detrend_ts_monthly <- function(df, value_cols, time_col) {
  df_detrended <- df
  
  for(col in value_cols) {
    if(col %in% names(df)) {
      # Use only valid values
      valid_idx <- !is.na(df[[col]]) & !is.na(df[[time_col]])
      if(sum(valid_idx) > 2) {
        fit <- lm(df[[col]][valid_idx] ~ df[[time_col]][valid_idx])
        df_detrended[[col]] <- NA
        df_detrended[[col]][valid_idx] <- residuals(fit)
      } else {
        df_detrended[[col]] <- NA
      }
    }
  }
  
  return(df_detrended)
}

# -------------------------------------------------------------------
# 2. Prepare datasets for detrending
# -------------------------------------------------------------------
# ALB & HAI
datasets_to_detrend_ALB_HAI <- unique(ds21969_detrend_ALB_HAI_monthly$dataset)
data_for_detrend_ALB_HAI <- data_for_ds21969_ALB_HAI[datasets_to_detrend_ALB_HAI]

# SCH
datasets_to_detrend_SCH <- unique(ds21969_detrend_SCH_monthly$dataset)
data_for_detrend_SCH <- data_for_ds21969_SCH[datasets_to_detrend_SCH]

# -------------------------------------------------------------------
# 3. Apply detrending to each dataset
# -------------------------------------------------------------------
# ALB & HAI
filtered_ds21969_detrended_ALB_HAI <- purrr::imap(
  data_for_detrend_ALB_HAI,
  function(df, name) {
    value_cols <- ds21969_detrend_ALB_HAI_monthly %>%
      filter(dataset == name) %>%
      pull(variable)
    
    df <- df %>%
      mutate(month = as.numeric(month),
             year_month_numeric = year + month / 12)
    
    df_detrended <- detrend_ts_monthly(df, value_cols, time_col = "year_month_numeric")
    
    # Optional: replace original columns with detrended values (_detrended suffix)
    for(col in value_cols) {
      detr_col <- paste0(col, "_detrended")
      df_detrended[[detr_col]] <- df_detrended[[col]]
      df_detrended[[col]] <- NULL
    }
    
    # Remove temporary numeric time column
    df_detrended <- df_detrended %>% select(-year_month_numeric)
    
    # Keep only complete cases
    df_detrended <- df_detrended[complete.cases(df_detrended), ]
    
    return(df_detrended)
  }
)

# SCH
filtered_ds21969_detrended_SCH <- purrr::imap(
  data_for_detrend_SCH,
  function(df, name) {
    value_cols <- ds21969_detrend_SCH_monthly %>%
      filter(dataset == name) %>%
      pull(variable)
    
    df <- df %>%
      mutate(month = as.numeric(month),
             year_month_numeric = year + month / 12)
    
    df_detrended <- detrend_ts_monthly(df, value_cols, time_col = "year_month_numeric")
    
    # Optional: replace original columns with detrended values
    for(col in value_cols) {
      detr_col <- paste0(col, "_detrended")
      df_detrended[[detr_col]] <- df_detrended[[col]]
      df_detrended[[col]] <- NULL
    }
    
    # Remove temporary numeric time column
    df_detrended <- df_detrended %>% select(-year_month_numeric)
    
    # Keep only complete cases
    df_detrended <- df_detrended[complete.cases(df_detrended), ]
    
    return(df_detrended)
  }
)

# -------------------------------------------------------------------
# 4. Quick check
# -------------------------------------------------------------------
cat("\nDetrended monthly datasets for ALB & HAI:\n")
print(names(filtered_ds21969_detrended_ALB_HAI))

cat("\nDetrended monthly datasets for SCH:\n")
print(names(filtered_ds21969_detrended_SCH))


###################DIFFERENCING###################################################

# -------------------------------------------------------------------
# 1. Lag-1 differencing function for monthly data
# -------------------------------------------------------------------
difference_ts_monthly <- function(df, value_cols, time_cols = c("year", "month")) {
  df_diff <- df
  num_cols <- intersect(value_cols, names(df))
  
  for(col in num_cols) {
    df_diff[[col]] <- c(NA, diff(df[[col]]))
  }
  
  # Make sure time columns exist
  for(tc in time_cols) {
    if(!tc %in% names(df_diff)) df_diff[[tc]] <- df[[tc]]
  }
  
  return(df_diff)
}

# -------------------------------------------------------------------
# 2. Safe filtering and differencing for general datasets
# -------------------------------------------------------------------
filter_ds21969_diff_monthly_safe <- function(df, dataset_name, diff_overview) {
  
  # Check if dataset exists in overview
  if(!dataset_name %in% unique(diff_overview$dataset)) return(NULL)
  
  # Columns allowed for differencing
  allowed_columns <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Possible grouping columns
  grouping_columns <- c("year", "month", "Croptype", "Fertilizer", "region",
                        "var", "measure", "Exploratory", "Family")
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Keep only relevant columns
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter by allowed values in grouping columns
  for(col in setdiff(existing_group_cols, c("year","month"))) {
    allowed_values <- diff_overview %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Only allowed Family–Exploratory combinations
  allowed_combinations <- diff_overview %>%
    filter(dataset == dataset_name) %>%
    dplyr::select(any_of(c("Family","Exploratory"))) %>%
    distinct()
  
  if(all(c("Family","Exploratory") %in% names(df_filtered))) {
    df_filtered <- df_filtered %>%
      semi_join(allowed_combinations, by = c("Family","Exploratory"))
  }
  
  # Apply differencing if data exists
  if(nrow(df_filtered) > 0) {
    df_diff <- difference_ts_monthly(df_filtered, allowed_columns, time_cols = c("year","month"))
    return(df_diff)
  } else {
    return(NULL)
  }
}

# -------------------------------------------------------------------
# 3. Special differencing for Weather data
# -------------------------------------------------------------------
difference_weather_monthly <- function(weather_df) {
  value_cols <- setdiff(names(weather_df), c("year","month","region"))
  difference_ts_monthly(weather_df, value_cols, time_cols = c("year","month"))
}

# -------------------------------------------------------------------
# 4. Apply filtering and differencing to all ds21969 monthly datasets
# -------------------------------------------------------------------
# ALB & HAI
filtered_ds21969_diffed_ALB_HAI <- purrr::imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    if(name == "weather") {
      difference_weather_monthly(df)
    } else {
      filter_ds21969_diff_monthly_safe(df, name, ds21969_differencing_ALB_HAI_monthly)
    }
  }
)

# Remove NULL or empty datasets
filtered_ds21969_diffed_ALB_HAI <- filtered_ds21969_diffed_ALB_HAI[
  sapply(filtered_ds21969_diffed_ALB_HAI, function(x) !is.null(x) && nrow(x) > 0)
]

# SCH
filtered_ds21969_diffed_SCH <- purrr::imap(
  data_for_ds21969_SCH,
  function(df, name) {
    if(name == "weather") {
      difference_weather_monthly(df)
    } else {
      filter_ds21969_diff_monthly_safe(df, name, ds21969_differencing_SCH_monthly)
    }
  }
)

# Remove NULL or empty datasets
filtered_ds21969_diffed_SCH <- filtered_ds21969_diffed_SCH[
  sapply(filtered_ds21969_diffed_SCH, function(x) !is.null(x) && nrow(x) > 0)
]

# -------------------------------------------------------------------
# 5. Ensure month column is numeric
# -------------------------------------------------------------------
filtered_ds21969_diffed_ALB_HAI <- lapply(
  filtered_ds21969_diffed_ALB_HAI,
  function(df) {
    if("month" %in% names(df)) df <- df %>% mutate(month = as.numeric(month))
    df
  }
)

filtered_ds21969_diffed_SCH <- lapply(
  filtered_ds21969_diffed_SCH,
  function(df) {
    if("month" %in% names(df)) df <- df %>% mutate(month = as.numeric(month))
    df
  }
)

# -------------------------------------------------------------------
# 6. Test output
# -------------------------------------------------------------------
cat("\nDifferenced monthly datasets for ALB & HAI:\n")
print(names(filtered_ds21969_diffed_ALB_HAI))

cat("\nDifferenced monthly datasets for SCH:\n")
print(names(filtered_ds21969_diffed_SCH))

########################### ds21969 – MONTHLY – DETREND + DIFFERENCE #################

# =====================================================================================
# 1) Function to filter ds21969 datasets according to overview table
# =====================================================================================
filter_ds21969_monthly_diff_detrend <- function(df, dataset_name, overview_table) {
  
  # Check if dataset exists in table
  if(!dataset_name %in% unique(overview_table$dataset)) {
    cat("Dataset", dataset_name, "not listed in overview\n")
    return(NULL)
  }
  
  allowed_columns <- overview_table %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  grouping_columns <- c("year","month","Croptype","Fertilizer","region",
                        "var","measure","Exploratory","Family")
  
  existing_group_cols <- intersect(names(df), grouping_columns)
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(dplyr::any_of(columns_to_keep))
  
  # Filter grouping columns (excluding year and month)
  for(col in setdiff(existing_group_cols, c("year","month"))) {
    allowed_values <- overview_table %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  cat("Dataset", dataset_name, "filtered.\n")
  return(df_filtered)
}

# =====================================================================================
# 2) Apply filtering to all ds21969 monthly datasets
# =====================================================================================
# ALB & HAI
filtered_ds21969_monthly_diff_detrend_ALB_HAI <- purrr::imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    filter_ds21969_monthly_diff_detrend(df, name, ds21969_diff_and_detrend_ALB_HAI_monthly)
  }
)

filtered_ds21969_monthly_diff_detrend_ALB_HAI <- filtered_ds21969_monthly_diff_detrend_ALB_HAI[
  !sapply(filtered_ds21969_monthly_diff_detrend_ALB_HAI, is.null)
]

# SCH
filtered_ds21969_monthly_diff_detrend_SCH <- purrr::imap(
  data_for_ds21969_SCH,
  function(df, name) {
    filter_ds21969_monthly_diff_detrend(df, name, ds21969_diff_and_detrend_SCH_monthly)
  }
)

filtered_ds21969_monthly_diff_detrend_SCH <- filtered_ds21969_monthly_diff_detrend_SCH[
  !sapply(filtered_ds21969_monthly_diff_detrend_SCH, is.null)
]

# =====================================================================================
# 3) Function: detrending + differencing (without stationarity tests)
# =====================================================================================
run_detrend_diff_ds21969_monthly <- function(diff_detrend_list) {
  results <- list()
  
  for(ds_name in names(diff_detrend_list)) {
    cat("\n---- Processing dataset:", ds_name, "----\n")
    df <- diff_detrend_list[[ds_name]]
    
    # Numeric value columns (excluding year and month)
    value_cols <- names(df)[sapply(df, is.numeric) & !names(df) %in% c("year","month")]
    
    # Grouping columns
    group_cols <- names(df)[!names(df) %in% value_cols & !names(df) %in% c("year","month")]
    if(length(group_cols) == 0) {
      df <- df %>% mutate(dummy = "all")
      group_cols <- "dummy"
    }
    
    # Time variable for detrending
    df <- df %>% mutate(time_numeric = year + month/12)
    
    df_diffed <- df %>%
      group_by(across(all_of(group_cols))) %>%
      group_modify(~ {
        df_group <- .x
        df_out <- df_group
        
        for(val_col in value_cols) {
          
          ts_data <- df_group %>%
            dplyr::select(time_numeric, !!sym(val_col)) %>%
            filter(!is.na(.data[[val_col]]))
          
          if(nrow(ts_data) < 2) next
          
          # 1) Linear detrending
          detrended <- tryCatch(
            unname(resid(lm(ts_data[[val_col]] ~ ts_data$time_numeric))),
            error = function(e) NULL
          )
          
          if(is.null(detrended) || length(detrended) < 2) next
          
          # 2) Lag-1 differencing
          differenced <- unname(c(NA, diff(detrended)))
          
          # Assign back to output
          df_out[[val_col]] <- differenced
        }
        
        df_out
      }) %>%
      ungroup()
    
    # Remove helper columns
    if("dummy" %in% names(df_diffed)) df_diffed <- df_diffed %>% dplyr::select(-dummy)
    if("time_numeric" %in% names(df_diffed)) df_diffed <- df_diffed %>% dplyr::select(-time_numeric)
    
    results[[ds_name]] <- df_diffed
  }
  
  return(results)
}

# =====================================================================================
# 4) Apply detrending + differencing
# =====================================================================================
filtered_ds21969_monthly_diffed_detrended_ALB_HAI <- run_detrend_diff_ds21969_monthly(
  filtered_ds21969_monthly_diff_detrend_ALB_HAI
)

filtered_ds21969_monthly_diffed_detrended_SCH <- run_detrend_diff_ds21969_monthly(
  filtered_ds21969_monthly_diff_detrend_SCH
)

# =====================================================================================
# 5) Check final results
# =====================================================================================
cat("\nFinal list after detrending and differencing (ALB & HAI):\n")
print(names(filtered_ds21969_monthly_diffed_detrended_ALB_HAI))

cat("\nFinal list after detrending and differencing (SCH):\n")
print(names(filtered_ds21969_monthly_diffed_detrended_SCH))


################################################################################
################## DS21969 ######################################################

combined_ds21969_ALB_HAI <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv", sep =",")

combined_ds21969_SCH <- read.csv("./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv", sep =",")

################## Select only stationary results from table #################
ds21969_ALB_HAI_stationary <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_SCH_stationary <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

###################### FILTER FOR MONTHLY ds21969 ###########################

# -------------------------------------------------------------------
# Function: filter monthly ds21969 datasets based on stationary vars
# -------------------------------------------------------------------
filter_ds21969_dataset_monthly <- function(df, dataset_name, overview_ds21969) {
  
  # Check if dataset appears in stationary overview
  if(!dataset_name %in% unique(overview_ds21969$dataset)) return(NULL)
  
  # Allowed variables for this dataset
  allowed_columns <- overview_ds21969 %>%
    filter(dataset == dataset_name) %>%
    pull(variable)
  
  # Grouping columns (monthly version includes month)
  grouping_columns <- c(
    "year", "month", "region", "Exploratory", "Family"
  )
  existing_group_cols <- intersect(names(df), grouping_columns)
  
  # Final columns to keep
  columns_to_keep <- unique(c(existing_group_cols, allowed_columns))
  
  df_filtered <- df %>% dplyr::select(any_of(columns_to_keep))
  
  # Filter grouping columns except year & month
  for(col in setdiff(existing_group_cols, c("year", "month"))) {
    allowed_values <- overview_ds21969 %>%
      filter(dataset == dataset_name & !is.na(.data[[col]])) %>%
      pull(.data[[col]]) %>% unique()
    
    if(length(allowed_values) > 0) {
      df_filtered <- df_filtered %>% filter(.data[[col]] %in% allowed_values)
    }
  }
  
  # Remove region for NDVI / NDMI / NIRv datasets
  if(dataset_name %in% c(
    "NDVI_ALB","NDVI_HAI","NDVI_SCH",
    "NDMI_ALB","NDMI_HAI","NDMI_SCH",
    "NIRv_ALB","NIRv_HAI","NIRv_SCH"
  )) {
    df_filtered <- df_filtered %>% dplyr::select(-any_of("region"))
  }
  
  return(df_filtered)
}

# -------------------------------------------------------------------
# Apply filtering to all monthly ds21969 datasets
# -------------------------------------------------------------------
filtered_ds21969_monthly_ALB_HAI_list <- imap(
  data_for_ds21969_ALB_HAI,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_ALB_HAI_stationary)
  }
)

filtered_ds21969_monthly_list_SCH <- imap(
  data_for_ds21969_SCH,
  function(df, name) {
    filter_ds21969_dataset_monthly(df, name, ds21969_SCH_stationary)
  }
)

# Remove NULL entries
filtered_ds21969_monthly_ALB_HAI_list <- filtered_ds21969_monthly_ALB_HAI_list[
  !sapply(filtered_ds21969_monthly_ALB_HAI_list, is.null)
]

filtered_ds21969_monthly_list_SCH <- filtered_ds21969_monthly_list_SCH[
  !sapply(filtered_ds21969_monthly_list_SCH, is.null)
]

# -------------------------------------------------------------------
# Example access:
# filtered_ds21969_monthly_list$ds21969_ALB_HAI
# filtered_ds21969_monthly_list_SCH$ds21969_SCH
# -------------------------------------------------------------------

names(filtered_ds21969_monthly_list)
names(filtered_ds21969_monthly_list_SCH)
str(filtered_ds21969_monthly_ALB_HAI_list, max.level = 1)
str(filtered_ds21969_monthly_list_SCH, max.level = 1)

######################################################################
############## Build sub-lists of ds21969_monthly per region #########
######################################################################

#################### ALB #############################################
# 3. Weather
weather_alb <- filtered_ds21969_monthly_list$weather %>% filter(region == "ALB")

# 4. ds21969 for ALB
ds21969_alb <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "ALB")

# 5. Create sub-list
ds21969_monthly_ALB <- list(
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI ##########################################
# 3. Weather
weather_hai <- filtered_ds21969_monthly_list$weather %>% filter(region == "HAI")

# 4. ds21969 for HAI
ds21969_hai <- filtered_ds21969_monthly_list$ds21969 %>% filter(Exploratory == "HAI")

# 5. Create sub-list
ds21969_monthly_HAI <- list(
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH ##########################################
# 3. Weather
weather_sch <- filtered_ds21969_monthly_list_SCH$weather %>% filter(region == "SCH")

# 4. ds21969 for SCH
ds21969_sch <- filtered_ds21969_monthly_list_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 5. Create sub-list
ds21969_monthly_SCH <- list(
  weather = weather_sch,
  ds21969 = ds21969_sch
)

###################### UPDATED DATASETS #########################################
# ---------------------------------------------
# 1) Set target dataset for ALB
# ---------------------------------------------
ds21969_monthly_ALB_updated <- ds21969_monthly_ALB

# ---------------------------------------------
# 2) Prepare detrended insect rows for ALB
# ---------------------------------------------
new_rows_ALB <- filtered_ds21969_detrended_ALB_HAI$ds21969 %>%
  filter(Exploratory == "ALB") %>%
  select(Exploratory, year, month, Family, NumberAdults_detrended) %>%
  mutate(NumberAdults = NA_real_) %>%
  select(Exploratory, month, year, Family, NumberAdults, NumberAdults_detrended) %>%
  distinct()

# Ensure month is numeric in both datasets
ds21969_monthly_ALB_updated$ds21969 <- ds21969_monthly_ALB_updated$ds21969 %>%
  mutate(month = as.numeric(month), NumberAdults_detrended = NA_real_)

new_rows_ALB <- new_rows_ALB %>% mutate(month = as.numeric(month))

# Remove duplicates to get unique join keys
new_rows_ALB_unique <- new_rows_ALB %>% distinct(Exploratory, Family, year, month, .keep_all = TRUE)

# ---------------------------------------------
# 3) Update existing ds21969 with detrended values
# ---------------------------------------------
old_n <- nrow(ds21969_monthly_ALB_updated$ds21969)

ds21969_monthly_ALB_updated$ds21969 <- ds21969_monthly_ALB_updated$ds21969 %>%
  left_join(
    new_rows_ALB_unique %>% rename(NumberAdults_detrended_new = NumberAdults_detrended),
    by = c("Exploratory", "Family", "year", "month"),
    relationship = "many-to-many"
  ) %>%
  mutate(NumberAdults_detrended = coalesce(NumberAdults_detrended_new, NumberAdults_detrended)) %>%
  select(-NumberAdults_detrended_new)

new_n <- nrow(ds21969_monthly_ALB_updated$ds21969)
cat("Updated ds21969 rows with detrended values (ALB):", new_n - old_n, "\n")

# ---------------------------------------------
# 4) Add weather data for ALB
# ---------------------------------------------
new_weather_ALB <- filtered_ds21969_detrended_ALB_HAI$weather %>%
  filter(region == "ALB") %>%
  mutate(month = as.numeric(month))

ds21969_monthly_ALB_updated$weather <- bind_rows(
  ds21969_monthly_ALB_updated$weather,
  new_weather_ALB
) %>%
  distinct() %>%
  arrange(region, year, month)

cat("ALB weather rows:", nrow(ds21969_monthly_ALB_updated$weather), "\n")

# ---------------------------------------------
# 5) Add NDVI and NIRv for ALB (diffed only)
# ---------------------------------------------
ds21969_monthly_ALB_updated$NDVI_ALB <- filtered_ds21969_diffed_ALB_HAI$NDVI_ALB
ds21969_monthly_ALB_updated$NIRv_ALB <- filtered_ds21969_diffed_ALB_HAI$NIRv_ALB

cat("NDVI_ALB rows:", nrow(ds21969_monthly_ALB_updated$NDVI_ALB), "\n")
cat("NIRv_ALB rows:", nrow(ds21969_monthly_ALB_updated$NIRv_ALB), "\n")

# ---------------------------------------------
# 6) Add NDMI, SMI_total, SMI_upsoil for ALB (detrended only)
# ---------------------------------------------
ds21969_monthly_ALB_updated$NDMI_ALB <- filtered_ds21969_detrended_ALB_HAI$NDMI_ALB

ds21969_monthly_ALB_updated$SMI_total <- filtered_ds21969_detrended_ALB_HAI$SMI_total %>%
  select(month, year, ALB) %>%
  filter(!is.na(month), !is.na(year))

ds21969_monthly_ALB_updated$SMI_upsoil <- filtered_ds21969_detrended_ALB_HAI$SMI_upsoil %>%
  select(month, year, ALB) %>%
  filter(!is.na(month), !is.na(year))

cat("NDMI_ALB rows:", nrow(ds21969_monthly_ALB_updated$NDMI_ALB), "\n")
cat("SMI_total rows (ALB):", nrow(ds21969_monthly_ALB_updated$SMI_total), "\n")
cat("SMI_upsoil rows (ALB):", nrow(ds21969_monthly_ALB_updated$SMI_upsoil), "\n")


######################################################################
########################### HAI ######################################
######################################################################
# ---------------------------------------------
# 1) Set target dataset
# ---------------------------------------------
ds21969_monthly_HAI_updated <- ds21969_monthly_HAI

# ---------------------------------------------
# 2) Prepare detrended insect rows for HAI
# ---------------------------------------------
new_rows_HAI <- filtered_ds21969_detrended_ALB_HAI$ds21969 %>%
  filter(Exploratory == "HAI") %>%
  select(Exploratory, year, month, Family, NumberAdults_detrended) %>%
  mutate(NumberAdults = NA_real_) %>%
  select(Exploratory, month, year, Family, NumberAdults, NumberAdults_detrended) %>%
  distinct()

# Ensure 'month' is numeric for consistency
ds21969_monthly_HAI_updated$ds21969 <- ds21969_monthly_HAI_updated$ds21969 %>%
  mutate(month = as.numeric(month), NumberAdults_detrended = NA_real_)

new_rows_HAI <- new_rows_HAI %>% mutate(month = as.numeric(month))

# Remove duplicates to get unique join keys
new_rows_HAI_unique <- new_rows_HAI %>%
  distinct(Exploratory, Family, year, month, .keep_all = TRUE)

# ---------------------------------------------
# 3) Update existing ds21969 with detrended values
# ---------------------------------------------
old_n <- nrow(ds21969_monthly_HAI_updated$ds21969)

ds21969_monthly_HAI_updated$ds21969 <- ds21969_monthly_HAI_updated$ds21969 %>%
  left_join(
    new_rows_HAI_unique %>% rename(NumberAdults_detrended_new = NumberAdults_detrended),
    by = c("Exploratory", "Family", "year", "month"),
    relationship = "many-to-many"
  ) %>%
  mutate(NumberAdults_detrended = coalesce(NumberAdults_detrended_new, NumberAdults_detrended)) %>%
  select(-NumberAdults_detrended_new)

new_n <- nrow(ds21969_monthly_HAI_updated$ds21969)
cat("Updated ds21969 rows with detrended values:", new_n - old_n, "\n")

# ---------------------------------------------
# 4) Add weather data for HAI
# ---------------------------------------------
new_weather_HAI <- filtered_ds21969_detrended_ALB_HAI$weather %>%
  filter(region == "HAI") %>%
  mutate(month = as.numeric(month))

ds21969_monthly_HAI_updated$weather <- bind_rows(
  ds21969_monthly_HAI_updated$weather,
  new_weather_HAI
) %>%
  distinct() %>%
  arrange(region, year, month)  # no plotID for HAI, use region instead

cat("HAI weather rows:", nrow(ds21969_monthly_HAI_updated$weather), "\n")

# ---------------------------------------------
# 5) Add NIRv, NDVI, NDMI for HAI
# ---------------------------------------------
ds21969_monthly_HAI_updated$NIRv_HAI <- filtered_ds21969_detrended_ALB_HAI$NIRv_HAI
ds21969_monthly_HAI_updated$NDVI_HAI <- filtered_ds21969_detrended_ALB_HAI$NDVI_HAI
ds21969_monthly_HAI_updated$NDMI_HAI <- filtered_ds21969_detrended_ALB_HAI$NDMI_HAI

cat("NIRv_HAI rows:", nrow(ds21969_monthly_HAI_updated$NIRv_HAI), "\n")
cat("NDVI_HAI rows:", nrow(ds21969_monthly_HAI_updated$NDVI_HAI), "\n")
cat("NDMI_HAI rows:", nrow(ds21969_monthly_HAI_updated$NDMI_HAI), "\n")

# ---------------------------------------------
# 6) Add SMI (total + upsoil)
# ---------------------------------------------
ds21969_monthly_HAI_updated$SMI_total <- filtered_ds21969_detrended_ALB_HAI$SMI_total %>%
  select(month, year, HAI) %>%
  filter(!is.na(month), !is.na(year))

ds21969_monthly_HAI_updated$SMI_upsoil <- filtered_ds21969_detrended_ALB_HAI$SMI_upsoil %>%
  select(month, year, HAI) %>%
  filter(!is.na(month), !is.na(year))

cat("SMI_total rows:", nrow(ds21969_monthly_HAI_updated$SMI_total), "\n")
cat("SMI_upsoil rows:", nrow(ds21969_monthly_HAI_updated$SMI_upsoil), "\n")

######################################################################
########################### SCH ######################################
######################################################################
# ---------------------------------------------
# 1) Set target dataset for SCH
# ---------------------------------------------
ds21969_monthly_SCH_updated <- ds21969_monthly_SCH

# ---------------------------------------------
# 2) Add / update detrended insect data (ds21969)
# ---------------------------------------------
new_rows_SCH <- filtered_ds21969_detrended_SCH$ds21969 %>%
  filter(Exploratory == "SCH") %>%
  select(Exploratory, year, month, Family, NumberAdults_detrended) %>%
  distinct()

# Align types
ds21969_monthly_SCH_updated$ds21969 <- ds21969_monthly_SCH_updated$ds21969 %>%
  mutate(
    month = as.numeric(month),
    NumberAdults_detrended = NA_real_
  )

new_rows_SCH <- new_rows_SCH %>%
  mutate(month = as.numeric(month)) %>%
  distinct(Exploratory, Family, year, month, .keep_all = TRUE)

old_n <- nrow(ds21969_monthly_SCH_updated$ds21969)

ds21969_monthly_SCH_updated$ds21969 <- ds21969_monthly_SCH_updated$ds21969 %>%
  left_join(
    new_rows_SCH %>% rename(NumberAdults_detrended_new = NumberAdults_detrended),
    by = c("Exploratory", "Family", "year", "month"),
    relationship = "many-to-many"
  ) %>%
  mutate(
    NumberAdults_detrended = coalesce(NumberAdults_detrended_new, NumberAdults_detrended)
  ) %>%
  select(-NumberAdults_detrended_new)

new_n <- nrow(ds21969_monthly_SCH_updated$ds21969)
cat("Updated ds21969 rows with detrended values (SCH):", new_n - old_n, "\n")

# ---------------------------------------------
# 3) Add weather data
#    - diffed + detrended
# ---------------------------------------------
new_weather_diffed_SCH <- filtered_ds21969_diffed_SCH$weather %>%
  mutate(month = as.numeric(month))

new_weather_detrended_SCH <- filtered_ds21969_detrended_SCH$weather %>%
  mutate(month = as.numeric(month))

ds21969_monthly_SCH_updated$weather <- bind_rows(
  ds21969_monthly_SCH_updated$weather %>% mutate(month = as.numeric(month)),
  new_weather_diffed_SCH,
  new_weather_detrended_SCH
) %>%
  distinct() %>%
  arrange(region, year, month)

cat("SCH weather rows:", nrow(ds21969_monthly_SCH_updated$weather), "\n")

# ---------------------------------------------
# 4) Add SMI_upsoil (detrended only)
# ---------------------------------------------
ds21969_monthly_SCH_updated$SMI_upsoil <- filtered_ds21969_detrended_SCH$SMI_upsoil

cat("SMI_upsoil rows (SCH):", nrow(ds21969_monthly_SCH_updated$SMI_upsoil), "\n")

# ---------------------------------------------
# 5) Add SMI_total (monthly diffed + detrended)
# ---------------------------------------------
ds21969_monthly_SCH_updated$SMI_total <- filtered_ds21969_monthly_diffed_detrended_SCH$SMI_total %>%
  select(month, year, SCH) %>%
  filter(!is.na(month), !is.na(year))

cat("SMI_total rows (SCH):", nrow(ds21969_monthly_SCH_updated$SMI_total), "\n")


#####################################################################################
######### GRANGER TEST DS21969 monthly ##############################################
########################## ALB ######################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_ALB_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  df <- ds21969_monthly_ALB_updated$ds21969 %>% filter(Family == fam)
  
  if(nrow(df) == 0) return(NULL)
  
  # --- check which column to use ---
  has_detrended <- "NumberAdults_detrended" %in% names(df) && any(!is.na(df$NumberAdults_detrended))
  has_raw <- "NumberAdults" %in% names(df) && any(!is.na(df$NumberAdults))
  
  if(!has_detrended && !has_raw) return(NULL)
  
  value_col <- if(has_detrended) "NumberAdults_detrended" else "NumberAdults"
  
  df %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(.data[[value_col]], na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
}

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  if(is.null(insect_df) || is.null(env_df)) return(NULL)
  
  # Ensure month is integer
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% select(year, month, NumberAdults_use),
    env_df %>% select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# Test all families for SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "ALB")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_total", EnvColumn = "ALB") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test SMI_upsoil for all families
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB_updated$SMI_upsoil
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "ALB")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "ALB") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDVI
# -----------------------------
results_ndvi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB_updated$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDVI", EnvColumn = "mean_NDVI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDMI
# -----------------------------
results_ndmi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB_updated$NDMI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDMI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDMI", EnvColumn = "mean_NDMI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NIRv
# -----------------------------
results_nirv <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB_updated$NIRv
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NIRv", EnvColumn = "mean_NIRv") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_ALB_updated$weather)[
  sapply(ds21969_monthly_ALB_updated$weather, is.numeric) &
    !(names(ds21969_monthly_ALB_updated$weather) %in% c("year","month"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_ALB_updated$weather %>%
    select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    if(is.null(insect_ts)) return(NULL)
    
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    if(is.null(ts_list)) return(NULL)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(Family = fam, EnvDataset = "weather", EnvColumn = varname) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# Combine all results
# -----------------------------
results_ds21969_monthly <- bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "./tables/granger_test/results_ds21969_monthly_ALB_2nd_round.csv", 
  row.names = FALSE
)


#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## HAI ######################################################
#####################################################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_HAI_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  df <- ds21969_monthly_HAI_updated$ds21969 %>% filter(Family == fam)
  if(nrow(df) == 0) return(NULL)
  
  # --- prefer detrended if exists ---
  has_detrended <- "NumberAdults_detrended" %in% names(df) && any(!is.na(df$NumberAdults_detrended))
  has_raw <- "NumberAdults" %in% names(df) && any(!is.na(df$NumberAdults))
  
  if(!has_detrended && !has_raw) return(NULL)
  
  value_col <- if(has_detrended) "NumberAdults_detrended" else "NumberAdults"
  
  df %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(.data[[value_col]], na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
}

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  if(is.null(insect_df) || is.null(env_df)) return(NULL)
  
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% select(year, month, NumberAdults_use),
    env_df %>% select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# Test all families for SMI_total
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_HAI_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "HAI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_total", EnvColumn = "HAI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test SMI_upsoil for all families
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_HAI_updated$SMI_upsoil
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "HAI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "SMI_upsoil", EnvColumn = "HAI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDVI
# -----------------------------
results_ndvi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_HAI_updated$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDVI", EnvColumn = "mean_NDVI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDMI
# -----------------------------
results_ndmi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_HAI_updated$NDMI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDMI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDMI", EnvColumn = "mean_NDMI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NIRv
# -----------------------------
results_nirv <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_HAI_updated$NIRv
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NIRv", EnvColumn = "mean_NIRv") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_HAI_updated$weather)[
  sapply(ds21969_monthly_HAI_updated$weather, is.numeric) &
    !(names(ds21969_monthly_HAI_updated$weather) %in% c("year","month"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_HAI_updated$weather %>%
    select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    if(is.null(insect_ts)) return(NULL)
    
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    if(is.null(ts_list)) return(NULL)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(Family = fam, EnvDataset = "weather", EnvColumn = varname) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# Combine all results
# -----------------------------
results_ds21969_monthly <- bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "./tables/granger_test/results_ds21969_monthly_HAI_2nd_round.csv", 
  row.names = FALSE
)

#####################################################################################
#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## SCH ######################################################

# -----------------------------
# 1. Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_SCH_updated$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Create insect time series for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  ds <- ds21969_monthly_SCH_updated$ds21969 %>%
    filter(Family == fam) %>%
    mutate(NumberAdults_use = if("NumberAdults_detrended" %in% names(.)) NumberAdults_detrended else NumberAdults) %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(NumberAdults_use, na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
  
  ds
}

# -----------------------------
# 3. Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    select(insect_df, year, month, NumberAdults_use),
    select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1:3) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# 5. Granger test for SMI_total (use SCH column)
# -----------------------------
results_smi_total <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$SMI_total
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "SCH")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_total",
      EnvColumn = "SCH"
    ) %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# 6. Granger test for SMI_upsoil (use SCH_detrended column)
# -----------------------------
results_smi_upsoil <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  env_ts <- ds21969_monthly_SCH_updated$SMI_upsoil
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "SCH_detrended")
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(
      Family = fam,
      EnvDataset = "SMI_upsoil",
      EnvColumn = "SCH_detrended"
    ) %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_SCH_updated$weather)[
  sapply(ds21969_monthly_SCH_updated$weather, is.numeric) &
    !(names(ds21969_monthly_SCH_updated$weather) %in% c("year","month","region","plotID","datetime"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_ts <- ds21969_monthly_SCH_updated$weather %>%
    select(year, month, !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    ts_list <- align_ts_monthly(insect_ts, env_ts, varname)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = "weather",
        EnvColumn = varname
      ) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 8. Combine all results and add causality column
# -----------------------------
results_ds21969_monthly_SCH <- bind_rows(
  results_smi_total,
  results_smi_upsoil,
  results_weather
) %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  )

# -----------------------------
# 9. Save results as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly_SCH,
  "./tables/granger_test/results_ds21969_monthly_SCH_2nd_round.csv",
  row.names = FALSE
)

