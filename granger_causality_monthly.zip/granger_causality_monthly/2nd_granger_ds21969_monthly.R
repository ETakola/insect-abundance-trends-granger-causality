########################## 2nd Round Granger ###############################
# Performs Granger tests on detrended and/or differenced data (stationary):
# 1. Uses the lists created in the "detrending/differencing"-scripts
# 2. Performs Granger tests on all stationary insect datasets combined

################### load packages ###########################
library(lmtest)
library(dplyr)
library(lubridate)
library(readr)
library(stringr)
library(purrr)
library(tibble)
library(tidyr)
library(tseries) # for stationarity tests


#################### Load Data ##############################
# Load datasets and standardize column names for year and month

# Soil Moisture Index (SMI) data
SMI_total <- read.csv("./data/smi/smi_means_total_soil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))
SMI_upsoil <- read.csv("./data/smi/smi_means_upsoil.csv", sep=',', header=TRUE) %>% 
  mutate(time = as.Date(time), day = day(time), month = month(time), year = year(time))

# Satellite data: NDVI (Normalized Difference Vegetation Index)
NDVI_ALB <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_HAI <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDVI_SCH <- read_csv("./data/NDVI/Landsat7_Monthly_NDVI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NDMI (Normalized Difference Moisture Index)
NDMI_ALB <- read_csv(
  "./data/NDMI/Landsat7_Monthly_NDMI_ALB_merged.csv",
  quote = "",              
  na = c("", "-9999")       
) %>%
  dplyr::select(-`system:index`) 
NDMI_HAI <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NDMI_SCH <- read_csv("./data/NDMI/Landsat7_Monthly_NDMI_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Satellite data: NIRv (Near Infrared Reflectance of vegetation)
NIRv_ALB <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_ALB_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_HAI <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_HAI_merged.csv") %>% dplyr::select(-`system:index`)
NIRv_SCH <- read_csv("./data/NIRv/Landsat7_Monthly_NIRv_SCH_merged.csv") %>% dplyr::select(-`system:index`)

# Weather data: Convert datetime to year and month, assign region labels
weather <- read.csv("./data/bexis_weather_plots.csv") %>%
  mutate(datetime = as.Date(datetime),   
         year = year(datetime),
         month = month(datetime),
         region = case_when(
           str_starts(plotID,"A") ~ "ALB",
           str_starts(plotID,"H") ~ "HAI",
           str_starts(plotID,"S") ~ "SCH",
           TRUE ~ NA_character_
         ))

# Insect dataset filtered ds21969
ds21969 <- read_csv("./data/insects/ds21969_filtered.csv") 


##### Stationarity tables from first round to build lists #####

stationarity_table_ds21969_ALB_HAI_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_ALB_HAI_monthly.csv",
  sep =","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

stationarity_table_ds21969_SCH_monthly <- read.csv(
  "./tables/stationarity_test/combined_stationarity_ds21969_SCH_monthly.csv",
  sep =","
) %>% filter(status_adf == "stationary", status_kpss == "stationary")

##### Combined stationarity tables for detrended/differenced data #####

# ds21969 monthly
ds21969_both_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_both_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_detrended_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_detrended_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary")

ds21969_differenced_monthly <- read.csv(
  "./tables/detrend_diff_stationarity/stationarity_table_ds21969_diff_monthly.csv",
  sep =","
) %>%
  filter(status_adf == "stationary", status_kpss == "stationary", Family != "Fam.")


############################## data list for easier handling ##############################
data_list <- list(
  SMI_total = SMI_total,
  SMI_upsoil = SMI_upsoil,
  NDVI_ALB = NDVI_ALB,
  NDVI_HAI = NDVI_HAI,
  NDVI_SCH = NDVI_SCH,
  NDMI_ALB = NDMI_ALB,
  NDMI_HAI = NDMI_HAI,
  NDMI_SCH = NDMI_SCH,
  NIRv_ALB = NIRv_ALB,
  NIRv_HAI = NIRv_HAI,
  NIRv_SCH = NIRv_SCH,
  weather = weather,
  ds21969 = ds21969
)

##################################################################################
################## Select datasets requiring detrending based on table ##########

ds21969_differencing_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")

ds21969_differencing_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "stationary", status_kpss == "non-stationary")


################## select datasets requiring detrending based on tables #################

# monthly
ds21969_detrend_ALB_HAI_monthly <- stationarity_table_ds21969_ALB_HAI_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")

ds21969_detrend_SCH_monthly <- stationarity_table_ds21969_SCH_monthly %>%
  filter(status_adf == "non-stationary", status_kpss == "stationary")


################################################################################
###################### MONTHLY AGGREGATION FOR ds21969 #########################
################################################################################

# ------------------------------------------------------------------------------
# 1. Determine months and year range
# ------------------------------------------------------------------------------
ds21969 <- ds21969 %>%
  mutate(month_num = as.numeric(month))  # numeric month for filtering

years_ds21969 <- range(ds21969$year, na.rm = TRUE)

# ALB & HAI months
months_ALB_HAI <- sort(unique(ds21969$month_num[ds21969$Exploratory %in% c("ALB","HAI")]))
# SCH months
months_SCH <- sort(unique(ds21969$month_num[ds21969$Exploratory == "SCH"]))

# ------------------------------------------------------------------------------
# 3. Function to filter by year and month
# ------------------------------------------------------------------------------
filter_monthly_period <- function(df, year_range, month_range) {
  if (!all(c("year","month") %in% names(df))) return(df)
  df %>%
    mutate(month_num = as.numeric(month)) %>%
    filter(
      !is.na(month_num),
      year >= year_range[1],
      year <= year_range[2],
      month_num %in% month_range
    )
}

# ------------------------------------------------------------------------------
# 4. Apply filter for ALB & HAI
# ------------------------------------------------------------------------------
data_for_ds21969_ALB_HAI <- lapply(data_list, function(df) {
  filter_monthly_period(df, years_ds21969, months_ALB_HAI)
})

# Remove other insect datasets (ds21969 is added separately)
data_for_ds21969_ALB_HAI <- data_for_ds21969_ALB_HAI[
  !names(data_for_ds21969_ALB_HAI) %in% c("ds22007")
]

# Add ds21969 for ALB & HAI
data_for_ds21969_ALB_HAI$ds21969 <- ds21969 %>%
  filter(Exploratory %in% c("ALB","HAI"))

# ------------------------------------------------------------------------------
# 5. Apply filter for SCH
# ------------------------------------------------------------------------------
data_for_ds21969_SCH <- lapply(monthly_datasets, function(df) {
  filter_monthly_period(df, years_ds21969, months_SCH)
})

# Remove other insect datasets
data_for_ds21969_SCH <- data_for_ds21969_SCH[
  !names(data_for_ds21969_SCH) %in% c("ds22007")
]

# Add ds21969 for SCH
data_for_ds21969_SCH$ds21969 <- ds21969 %>%
  filter(Exploratory == "SCH")

# ------------------------------------------------------------------------------
# 6. Special handling for Weather (monthly aggregation by region)
# ------------------------------------------------------------------------------

aggregate_weather_monthly <- function(weather_df) {
  
  numeric_weather_cols <- weather_df %>%
    dplyr::select(where(is.numeric)) %>%
    dplyr::select(-year, -month, -month_num) %>%
    names()
  
  weather_df %>%
    dplyr::group_by(region, year, month_num) %>%
    dplyr::summarise(
      across(all_of(numeric_weather_cols), mean, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    dplyr::rename(month = month_num)
}

# ---- ALB & HAI ----
if ("weather" %in% names(data_for_ds21969_ALB_HAI)) {
  data_for_ds21969_ALB_HAI$weather <-
    aggregate_weather_monthly(data_for_ds21969_ALB_HAI$weather)
}

# ---- SCH ----
if ("weather" %in% names(data_for_ds21969_SCH)) {
  data_for_ds21969_SCH$weather <-
    aggregate_weather_monthly(data_for_ds21969_SCH$weather)
}


################################################################################
# Result: two lists
# data_for_ds21969_ALB_HAI
# data_for_ds21969_SCH
################################################################################

########################### DETREND ds21969 MONTHLY ##############################
###########################
# Detrending Function
###########################
detrend_ts <- function(df, col_name){
  # linear model: Column ~ Time (here year + month for monthly data)
  fit <- lm(df[[col_name]] ~ df$year + df$month)
  df[[col_name]] <- df[[col_name]] - fit$fitted.values
  return(df)
}

###########################
# ALB & HAI
###########################

data_for_ds21969_stationary_ALB_HAI <- list()

# ---------------- NDVI / NDMI / NIRv ----------------
datasets_ALB_HAI <- c("NDVI_ALB","NDMI_ALB","NIRv_ALB")
for(ds in datasets_ALB_HAI){
  vars <- ds21969_detrended_monthly %>%
    filter(dataset == ds, Exploratory %in% c("ALB","HAI")) %>%
    pull(variable) %>% unique()
  df <- data_for_ds21969_ALB_HAI[[ds]]
  for(v in vars){ df <- detrend_ts(df, v) }
  data_for_ds21969_stationary_ALB_HAI[[ds]] <- df
}

# ---------------- Weather ----------------
vars_weather <- ds21969_stationary_ALB_HAI_monthly %>%
  filter(dataset == "weather") %>%
  pull(variable) %>% unique()
data_for_ds21969_stationary_ALB_HAI$weather <- data_for_ds21969_ALB_HAI$weather %>%
  select(year, month, region, any_of(vars_weather))

# ---------------- ds21969 insects ----------------
families_ALB_HAI <- ds21969_stationary_ALB_HAI_monthly %>%
  filter(dataset == "ds21969") %>%
  pull(Family) %>% unique()

df_insects <- data_for_ds21969_ALB_HAI$ds21969 %>%
  filter(Family %in% families_ALB_HAI)

# Detrend for families from ds21969_detrended_monthly
families_detrended <- ds21969_detrended_monthly %>%
  filter(Exploratory %in% c("ALB","HAI")) %>%
  pull(Family) %>% unique()

for(fam in families_detrended){
  df_insects <- df_insects %>%
    group_by(Exploratory, Family) %>%
    mutate(NumberAdults = if_else(Family == fam,
                                  NumberAdults - lm(NumberAdults ~ year + month)$fitted.values,
                                  NumberAdults)) %>%
    ungroup()
}

# ---------------- Weather ----------------
# Stationary variables from stationarity_table
vars_weather <- ds21969_stationary_ALB_HAI_monthly %>%
  filter(dataset == "weather") %>%
  pull(variable) %>% unique()

# Additionally include the detrended variable from ds21969_detrended_monthly
vars_weather <- unique(c(vars_weather, "precipitation_radolan_rain_days"))

weather_df <- data_for_ds21969_ALB_HAI$weather %>%
  select(year, month, region, any_of(vars_weather))

# Detrend for the variable precipitation_radolan_rain_days
if("precipitation_radolan_rain_days" %in% names(weather_df)){
  weather_df <- detrend_ts(weather_df, "precipitation_radolan_rain_days")
}

data_for_ds21969_stationary_ALB_HAI$weather <- weather_df

###########################
# SCH
###########################

data_for_ds21969_stationary_SCH <- list()

# ---------------- Weather ----------------
vars_weather <- ds21969_stationary_SCH_monthly %>%
  filter(dataset == "weather") %>%
  pull(variable) %>% unique()
data_for_ds21969_stationary_SCH$weather <- data_for_ds21969_SCH$weather %>%
  select(year, month, region, any_of(vars_weather))

# ---------------- ds21969 insects ----------------
families_SCH <- ds21969_stationary_SCH_monthly %>%
  filter(dataset == "ds21969") %>%
  pull(Family) %>% unique()

df_insects <- data_for_ds21969_SCH$ds21969 %>%
  filter(Family %in% families_SCH)

families_detrended <- ds21969_detrended_monthly %>%
  filter(Exploratory == "SCH") %>%
  pull(Family) %>% unique()

for(fam in families_detrended){
  df_insects <- df_insects %>%
    group_by(Exploratory, Family) %>%
    mutate(NumberAdults = if_else(Family == fam,
                                  NumberAdults - lm(NumberAdults ~ year + month)$fitted.values,
                                  NumberAdults)) %>%
    ungroup()
}

data_for_ds21969_stationary_SCH$ds21969 <- df_insects

######################################################################
############## Build sub-lists of ds21969_monthly per region #########
######################################################################

#################### ALB #############################################
#NDVI/NDMI/NIRv
ndvi_alb <- data_for_ds21969_stationary_ALB_HAI$NDVI_ALB
ndmi_alb <- data_for_ds21969_stationary_ALB_HAI$NDMI_ALB
nirv_alb <- data_for_ds21969_stationary_ALB_HAI$NIRv_ALB

# 3. Weather
weather_alb <- data_for_ds21969_stationary_ALB_HAI$weather %>% filter(region == "ALB")

# 4. ds21969 for ALB
ds21969_alb <- data_for_ds21969_stationary_ALB_HAI$ds21969 %>% filter(Exploratory == "ALB")

# 5. Create sub-list
ds21969_monthly_ALB <- list(
  NDVI_ALB = ndvi_alb,
  NDMI_ALB = ndmi_alb,
  NIRv_ALB = nirv_alb,
  weather = weather_alb,
  ds21969 = ds21969_alb
)

#################### HAI ##########################################
# 3. Weather
weather_hai <- data_for_ds21969_stationary_ALB_HAI$weather %>% filter(region == "HAI")

# 4. ds21969 for HAI
ds21969_hai <- data_for_ds21969_stationary_ALB_HAI$ds21969 %>% filter(Exploratory == "HAI")

# 5. Create sub-list
ds21969_monthly_HAI <- list(
  weather = weather_hai,
  ds21969 = ds21969_hai
)

#################### SCH ##########################################
# 3. Weather
weather_sch <- data_for_ds21969_stationary_SCH$weather %>% filter(region == "SCH")

# 4. ds21969 for SCH
ds21969_sch <- data_for_ds21969_stationary_SCH$ds21969 %>% filter(Exploratory == "SCH")

# 5. Create sub-list
ds21969_monthly_SCH <- list(
  weather = weather_sch,
  ds21969 = ds21969_sch
)

#####################################################################################
######### GRANGER TEST DS21969 monthly ##############################################
########################## ALB ######################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_ALB$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  df <- ds21969_monthly_ALB$ds21969 %>% filter(Family == fam)
  
  if(nrow(df) == 0) return(NULL)
  
  # --- use NumberAdults ---
  df %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(NumberAdults, na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
}

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  if(is.null(insect_df) || is.null(env_df)) return(NULL)
  
  # Ensure month is integer
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% select(year, month, NumberAdults_use),
    env_df %>% select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}
# -----------------------------
# Test NDVI
# -----------------------------
results_ndvi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB$NDVI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDVI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDVI", EnvColumn = "mean_NDVI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NDMI
# -----------------------------
results_ndmi <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB$NDMI
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NDMI")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NDMI", EnvColumn = "mean_NDMI") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Test NIRv
# -----------------------------
results_nirv <- map_dfr(families, function(fam) {
  insect_ts <- get_insect_ts_monthly(fam)
  if(is.null(insect_ts)) return(NULL)
  
  env_ts <- ds21969_monthly_ALB$NIRv
  
  ts_list <- align_ts_monthly(insect_ts, env_ts, "mean_NIRv")
  if(is.null(ts_list)) return(NULL)
  
  res <- granger_safe(ts_list$insect, ts_list$env, lags)
  
  res %>%
    mutate(Family = fam, EnvDataset = "NIRv", EnvColumn = "mean_NIRv") %>%
    select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
})

# -----------------------------
# Weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_ALB$weather)[
  sapply(ds21969_monthly_ALB$weather, is.numeric) &
    !(names(ds21969_monthly_ALB$weather) %in% c("year","month"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_ALB$weather %>%
    select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    if(is.null(insect_ts)) return(NULL)
    
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    if(is.null(ts_list)) return(NULL)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(Family = fam, EnvDataset = "weather", EnvColumn = varname) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# Combine all results
# -----------------------------
results_ds21969_monthly <- bind_rows(
  results_ndvi,
  results_ndmi,
  results_nirv,
  results_weather
)

# -----------------------------
# Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "./tables/granger_test/results_ds21969_monthly_ALB_2nd_round.csv", 
  row.names = FALSE
)

str(ds21969_monthly_ALB)
#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## HAI ######################################################
#####################################################################################

# -----------------------------
# Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_HAI$ds21969$Family)
lags <- 1:3

# -----------------------------
# Create insect time series dataframe for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  df <- ds21969_monthly_HAI$ds21969 %>% filter(Family == fam)
  if(nrow(df) == 0) return(NULL)
  
  # --- prefer detrended if exists ---
  has_detrended <- "NumberAdults_detrended" %in% names(df) && any(!is.na(df$NumberAdults_detrended))
  has_raw <- "NumberAdults" %in% names(df) && any(!is.na(df$NumberAdults))
  
  if(!has_detrended && !has_raw) return(NULL)
  
  value_col <- if(has_detrended) "NumberAdults_detrended" else "NumberAdults"
  
  df %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(.data[[value_col]], na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
}

# -----------------------------
# Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  if(is.null(insect_df) || is.null(env_df)) return(NULL)
  
  insect_df <- insect_df %>% mutate(month = as.integer(month))
  env_df <- env_df %>% mutate(month = as.integer(month))
  
  df <- inner_join(
    insect_df %>% select(year, month, NumberAdults_use),
    env_df %>% select(year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env    = df[[env_col]][ok]
  )
}

# -----------------------------
# Safe Granger test with checks
# -----------------------------
granger_safe <- function(x, y, lags = 1) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}

# -----------------------------
# Weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_HAI$weather)[
  sapply(ds21969_monthly_HAI$weather, is.numeric) &
    !(names(ds21969_monthly_HAI$weather) %in% c("year","month"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_df <- ds21969_monthly_HAI$weather %>%
    select(year, month, !!sym(varname)) %>%
    rename(env_value = !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    if(is.null(insect_ts)) return(NULL)
    
    ts_list <- align_ts_monthly(insect_ts, env_df, "env_value")
    if(is.null(ts_list)) return(NULL)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(Family = fam, EnvDataset = "weather", EnvColumn = varname) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# Combine all results
# -----------------------------
results_ds21969_monthly <- bind_rows(
  results_weather
)

# -----------------------------
# Create causality column
# -----------------------------
results_ds21969_monthly <- results_ds21969_monthly %>%
  mutate(causality = case_when(
    is.na(p_value) ~ "no_test",
    p_value < 0.05 ~ "causal",
    TRUE ~ "non-causal"
  ))

# -----------------------------
# Check results
# -----------------------------
head(results_ds21969_monthly)

# -----------------------------
# Save table as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly, 
  "./tables/granger_test/results_ds21969_monthly_HAI_2nd_round.csv", 
  row.names = FALSE
)

#####################################################################################
#####################################################################################
######### GRANGER TEST DS21969 ######################################################
########################## SCH ######################################################

# -----------------------------
# 1. Family list & lags
# -----------------------------
families <- unique(ds21969_monthly_SCH$ds21969$Family)
lags <- 1:3

# -----------------------------
# 2. Create insect time series for monthly data
# -----------------------------
get_insect_ts_monthly <- function(fam) {
  ds <- ds21969_monthly_SCH$ds21969 %>%
    filter(Family == fam) %>%
    mutate(NumberAdults_use = if("NumberAdults_detrended" %in% names(.)) NumberAdults_detrended else NumberAdults) %>%
    group_by(year, month) %>%
    summarise(NumberAdults_use = sum(NumberAdults_use, na.rm = TRUE), .groups = "drop") %>%
    arrange(year, month)
  
  ds
}

# -----------------------------
# 3. Align time series by year + month
# -----------------------------
align_ts_monthly <- function(insect_df, env_df, env_col) {
  df <- inner_join(
    select(insect_df, year, month, NumberAdults_use),
    select(env_df, year, month, !!sym(env_col)),
    by = c("year", "month")
  )
  
  ok <- !is.na(df$NumberAdults_use) & !is.na(df[[env_col]])
  
  list(
    insect = df$NumberAdults_use[ok],
    env = df[[env_col]][ok]
  )
}

# -----------------------------
# 4. Safe Granger test
# -----------------------------
granger_safe <- function(x, y, lags = 1:3) {
  map_dfr(lags, function(lag) {
    if(length(x) < lag + 2 || length(y) < lag + 2 || var(x) == 0 || var(y) == 0) {
      tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_)
    } else {
      tryCatch({
        res <- grangertest(x ~ y, order = lag)
        tibble(Lag = lag, F_stat = res$F[2], p_value = res$`Pr(>F)`[2])
      }, error = function(e) tibble(Lag = lag, F_stat = NA_real_, p_value = NA_real_))
    }
  })
}


# -----------------------------
# 7. Test weather variables
# -----------------------------
weather_vars <- names(ds21969_monthly_SCH$weather)[
  sapply(ds21969_monthly_SCH$weather, is.numeric) &
    !(names(ds21969_monthly_SCH$weather) %in% c("year","month","region","plotID","datetime"))
]

results_weather <- map_dfr(weather_vars, function(varname) {
  env_ts <- ds21969_monthly_SCH$weather %>%
    select(year, month, !!sym(varname))
  
  map_dfr(families, function(fam) {
    insect_ts <- get_insect_ts_monthly(fam)
    ts_list <- align_ts_monthly(insect_ts, env_ts, varname)
    
    res <- granger_safe(ts_list$insect, ts_list$env, lags)
    
    res %>%
      mutate(
        Family = fam,
        EnvDataset = "weather",
        EnvColumn = varname
      ) %>%
      select(Family, EnvDataset, EnvColumn, Lag, F_stat, p_value)
  })
})

# -----------------------------
# 8. Combine all results and add causality column
# -----------------------------
results_ds21969_monthly_SCH <- bind_rows(
  results_weather
) %>%
  mutate(
    causality = case_when(
      is.na(p_value) ~ "no_test",
      p_value < 0.05 ~ "causal",
      TRUE ~ "non-causal"
    )
  )

# -----------------------------
# 9. Save results as CSV
# -----------------------------
write.csv(
  results_ds21969_monthly_SCH,
  "./tables/granger_test/results_ds21969_monthly_SCH_2nd_round.csv",
  row.names = FALSE
)

